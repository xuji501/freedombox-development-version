#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 卸载静态路由模块，恢复到安装前的状态。
#
# 用法：sudo bash rollback.sh [备份目录]
#
# 不传备份目录时自动使用 /root/freedombox-routes-module-backup 下最新的一份。
#
# 卸载顺序是有讲究的：先停服务、删 unit，再删恢复脚本，最后才动路由清单。
# 否则 systemd 可能在半途用残留脚本重新加回路由。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/routes
ENABLED_DIR=/etc/freedombox/modules-enabled
CONFIG_DIR=/etc/freedombox-routes
APPLY_DIR=/usr/lib/freedombox-routes
UNIT_FILE=/etc/systemd/system/freedombox-routes.service
SERVICE=freedombox-routes
BACKUP_ROOT=/root/freedombox-routes-module-backup

BACKUP_DIR=${1:-}
if [ -z "$BACKUP_DIR" ]; then
    BACKUP_DIR=$(ls -1d "$BACKUP_ROOT"/*/ 2>/dev/null | sort | tail -1)
    BACKUP_DIR=${BACKUP_DIR%/}
fi

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

echo "=============================================="
echo " FreedomBox 静态路由模块卸载"
echo "=============================================="

echo ""
echo "== 1/6 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR" ]; then
    echo "使用备份目录：$BACKUP_DIR"
else
    echo "未找到备份目录，将按「全新安装」处理（不还原任何旧文件）"
    BACKUP_DIR=''
fi

echo ""
echo "== 2/6 停止并移除服务 =="
systemctl stop "$SERVICE" 2>/dev/null || true
systemctl disable "$SERVICE" 2>/dev/null || true
rm -f "$UNIT_FILE"
systemctl daemon-reload 2>/dev/null || true
echo "已停止服务并删除 unit"

echo ""
echo "== 3/6 删除开机恢复脚本 =="
rm -rf "$APPLY_DIR"
echo "已删除 $APPLY_DIR"

echo ""
echo "== 4/6 清理 OSPF 配置 =="
# 只摘掉带标记的那一段，并关掉 ospfd；/etc/frr/frr.conf 里其余内容原样保留。
if [ -f /etc/frr/frr.conf ]; then
    python3 - <<'PYEOF'
import os
import subprocess

BEGIN = '! >>> freedombox-ospf begin (managed by Plinth, do not edit) >>>'
END = '! <<< freedombox-ospf end <<<'
PATH = '/etc/frr/frr.conf'
DAEMONS = '/etc/frr/daemons'

try:
    with open(PATH, encoding='utf-8') as handle:
        text = handle.read()
except OSError:
    raise SystemExit(0)

if BEGIN not in text:
    print('  frr.conf 中没有 OSPF 标记块，跳过')
else:
    kept = []
    inside = False
    for line in text.splitlines():
        if line.strip() == BEGIN:
            inside = True
            continue
        if line.strip() == END:
            inside = False
            continue
        if not inside:
            kept.append(line)
    while kept and not kept[-1].strip():
        kept.pop()

    with open(PATH, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(kept) + '\n')
    print('  已从 frr.conf 中移除 OSPF 标记块')

try:
    with open(DAEMONS, encoding='utf-8') as handle:
        lines = handle.read().splitlines()
    for index, line in enumerate(lines):
        if line.strip().startswith('ospfd='):
            lines[index] = 'ospfd=no'
            break
    with open(DAEMONS, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(lines) + '\n')
    print('  已把 /etc/frr/daemons 中的 ospfd 关回 no')
except OSError:
    pass

subprocess.run(['systemctl', 'restart', 'frr'], capture_output=True)
PYEOF
else
    echo "  未找到 /etc/frr/frr.conf，跳过"
fi

if [ -n "$BACKUP_DIR" ] && [ -f "$BACKUP_DIR/frr.conf" ]; then
    cp -a "$BACKUP_DIR/frr.conf" /etc/frr/frr.conf
    echo "已还原安装前的 frr.conf"
fi
if [ -n "$BACKUP_DIR" ] && [ -f "$BACKUP_DIR/frr-daemons" ]; then
    cp -a "$BACKUP_DIR/frr-daemons" /etc/frr/daemons
    echo "已还原安装前的 frr daemons"
fi
systemctl restart frr 2>/dev/null || true
echo "frr 状态：$(systemctl is-active frr 2>/dev/null || echo 未安装)"

echo ""
echo "== 5/6 处理路由清单 =="
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/config" ]; then
    rm -rf "$CONFIG_DIR"
    cp -a "$BACKUP_DIR/config" "$CONFIG_DIR"
    echo "已恢复安装前的路由清单"
else
    # 已生效的路由会随重启自然消失；要立即清掉请手工 ip route del。
    if [ -f "$CONFIG_DIR/routes.json" ]; then
        python3 - <<'PYEOF'
import json
try:
    with open('/etc/freedombox-routes/routes.json') as handle:
        routes = (json.load(handle).get('routes') or [])
except Exception:
    routes = []
for item in routes:
    print('  仍在生效（重启后消失）：{} {}'.format(
        item.get('family'), item.get('destination')))
PYEOF
    fi
    rm -rf "$CONFIG_DIR"
    echo "已删除 $CONFIG_DIR"
fi

echo ""
echo "== 6/6 移除模块代码与启用标记 =="
rm -f "$ENABLED_DIR/routes"
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/module" ]; then
    rm -rf "$MODULE_DIR"
    cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
    echo "已恢复原有模块目录"
else
    rm -rf "$MODULE_DIR"
    echo "已移除模块目录"
fi

if [ -n "$BACKUP_DIR" ] && [ -f "$BACKUP_DIR/enabled-routes" ]; then
    cp -a "$BACKUP_DIR/enabled-routes" "$ENABLED_DIR/routes"
    echo "已恢复原有启用标记"
fi

systemctl restart plinth 2>/dev/null || true
sleep 3

echo ""
echo "== 卸载结果 =="
echo "Plinth 状态：$(systemctl is-active plinth 2>/dev/null || echo 未知)"
echo "服务状态：$(systemctl is-active "$SERVICE" 2>/dev/null || echo 已移除)"
echo ""
echo "IPv4 默认路由：$(ip -4 route show default | head -1)"
echo "IPv6 默认路由：$(ip -6 route show default | head -1)"
echo ""
echo "提示：卸载不会删除已经生效的非默认路由，"
echo "      如需立即清除请手工执行 ip route del，否则重启后自然消失。"
echo "=============================================="
