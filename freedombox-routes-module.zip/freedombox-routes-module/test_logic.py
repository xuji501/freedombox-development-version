"""Local logic tests for the static routes module with plinth stubbed out."""

import json
import pathlib
import sys
import tempfile
import types

plinth = types.ModuleType('plinth')
action_utils = types.ModuleType('plinth.action_utils')
for name in ('service_enable', 'service_disable', 'service_start',
             'service_stop', 'service_try_restart', 'service_restart',
             'service_daemon_reload'):
    setattr(action_utils, name, lambda *a, **k: None)
actions = types.ModuleType('plinth.actions')
actions.privileged = lambda func: func
plinth.action_utils = action_utils
plinth.actions = actions
sys.modules['plinth'] = plinth
sys.modules['plinth.action_utils'] = action_utils
sys.modules['plinth.actions'] = actions

sys.path.insert(0, str(pathlib.Path(__file__).parent / 'files'))
import privileged  # noqa: E402

WORK = pathlib.Path(tempfile.mkdtemp(prefix='fbx-routes-'))
privileged.CONFIG_DIR = WORK
privileged.ROUTES_PATH = WORK / 'routes.json'
privileged.APPLY_SCRIPT_PATH = str(WORK / 'apply.py')
privileged.UNIT_PATH = str(WORK / 'routes.service')
privileged._devices = lambda: ['ens32', 'ens34', 'tun0']

print('=' * 60)
print('测试 1：ip route 输出解析')
print('=' * 60)
cases = [
    ('default via 10.10.173.1 dev ens32 proto static metric 100',
     {'destination': 'default', 'gateway': '10.10.173.1',
      'device': 'ens32', 'metric': '100', 'proto': 'static'}),
    ('172.16.19.0/24 dev ens34 proto kernel scope link src 172.16.19.1 '
     'metric 101',
     {'destination': '172.16.19.0/24', 'gateway': '', 'device': 'ens34',
      'metric': '101', 'proto': 'kernel'}),
    ('10.10.0.2 dev wg0 scope link',
     {'destination': '10.10.0.2', 'gateway': '', 'device': 'wg0',
      'metric': '', 'proto': ''}),
]
for line, expected in cases:
    row = privileged._parse_route_line(line)
    print(' ', row)
    assert row == expected, f'{line} -> {row}'

assert privileged._parse_route_line('') == {}
print('[通过] 默认路由、直连网段、点对点路由都能正确解析')

print()
print('=' * 60)
print('测试 2：命令拼装')
print('=' * 60)
route = {'family': 'ipv4', 'destination': '192.168.50.0/24',
         'gateway': '172.16.19.254', 'device': '', 'metric': 0}
assert privileged._route_arguments(route, 'replace') == [
    'ip', '-4', 'route', 'replace', '192.168.50.0/24',
    'via', '172.16.19.254']

route6 = {'family': 'ipv6', 'destination': 'fd00:50::/64',
          'gateway': 'fd00:19::1', 'device': 'ens34', 'metric': 200}
assert privileged._route_arguments(route6, 'del') == [
    'ip', '-6', 'route', 'del', 'fd00:50::/64',
    'via', 'fd00:19::1', 'dev', 'ens34', 'metric', '200']
print('  IPv4:', privileged._route_arguments(route, 'replace'))
print('  IPv6:', privileged._route_arguments(route6, 'del'))
print('[通过] -4/-6 与 via/dev/metric 组合正确')

print()
print('=' * 60)
print('测试 3：路由校验')
print('=' * 60)
good = privileged._validate_route(
    {'family': 'ipv4', 'destination': '192.168.50.5/24',
     'gateway': '172.16.19.254', 'device': '', 'metric': 0}, [])
print('  规范化结果:', good)
assert good['destination'] == '192.168.50.0/24', '网段应规范化为网络地址'
assert good['gateway'] == '172.16.19.254'

bad_cases = [
    ('默认路由', {'family': 'ipv4', 'destination': '0.0.0.0/0',
                  'gateway': '10.10.173.1', 'device': '', 'metric': 0}),
    ('IPv6 默认路由', {'family': 'ipv6', 'destination': '::/0',
                       'gateway': 'fd00::1', 'device': '', 'metric': 0}),
    ('网段格式错', {'family': 'ipv4', 'destination': '192.168.50.0/33',
                    'gateway': '172.16.19.254', 'device': '', 'metric': 0}),
    ('缺少前缀', {'family': 'ipv4', 'destination': '192.168.50.0',
                  'gateway': '172.16.19.254', 'device': '', 'metric': 0}),
    ('协议不符', {'family': 'ipv4', 'destination': 'fd00:50::/64',
                  'gateway': '172.16.19.254', 'device': '', 'metric': 0}),
    ('网关格式错', {'family': 'ipv4', 'destination': '192.168.50.0/24',
                    'gateway': 'not-an-ip', 'device': '', 'metric': 0}),
    ('网关协议不符', {'family': 'ipv4', 'destination': '192.168.50.0/24',
                      'gateway': 'fd00::1', 'device': '', 'metric': 0}),
    ('网卡不存在', {'family': 'ipv4', 'destination': '192.168.50.0/24',
                    'gateway': '', 'device': 'eth9', 'metric': 0}),
    ('网关和网卡都空', {'family': 'ipv4', 'destination': '192.168.50.0/24',
                        'gateway': '', 'device': '', 'metric': 0}),
    ('跃点为负', {'family': 'ipv4', 'destination': '192.168.50.0/24',
                  'gateway': '172.16.19.254', 'device': '', 'metric': -1}),
]
for label, case in bad_cases:
    try:
        privileged._validate_route(case, [])
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label} 本应被拒绝')

try:
    privileged._validate_route(
        {'family': 'ipv4', 'destination': '192.168.50.0/24',
         'gateway': '172.16.19.254', 'device': '', 'metric': 0},
        [{'family': 'ipv4', 'destination': '192.168.50.0/24'}])
except ValueError as error:
    print(f'  [拒绝] 重复网段: {error}')
else:
    raise AssertionError('重复网段本应被拒绝')
print('[通过] 九类非法输入与重复网段全部拦截')

print()
print('=' * 60)
print('测试 4：配置文件读写')
print('=' * 60)
assert privileged.read_routes() == []
privileged._write_routes([{'id': 'abc', 'family': 'ipv4',
                           'destination': '192.168.50.0/24',
                           'gateway': '172.16.19.254', 'device': '',
                           'metric': 0, 'created': 1}])
saved = privileged.read_routes()
print('  读回:', saved)
assert len(saved) == 1 and saved[0]['destination'] == '192.168.50.0/24'

privileged.ROUTES_PATH.write_text('{ broken', encoding='utf-8')
assert privileged.read_routes() == [], '配置文件损坏时应返回空列表'
privileged.ROUTES_PATH.write_text(
    json.dumps({'routes': [{'family': 'ipv4'}, {'destination': 'x'},
                           {'family': 'ipv4',
                            'destination': '10.1.0.0/16'}]}),
    encoding='utf-8')
assert len(privileged.read_routes()) == 1, '不完整的条目应被丢弃'
print('[通过] 缺失/损坏/半成品条目都不会导致异常')

print()
print('=' * 60)
print('测试 5：开机恢复脚本')
print('=' * 60)
compile(privileged.APPLY_SCRIPT, 'apply.py', 'exec')
assert 'route' in privileged.APPLY_SCRIPT and 'replace' in privileged.APPLY_SCRIPT
assert '/etc/freedombox-routes/routes.json' in privileged.APPLY_SCRIPT
assert 'plinth' not in privileged.APPLY_SCRIPT, \
    '开机脚本不能依赖 Plinth，否则 Plinth 故障时路由不会恢复'
assert 'RemainAfterExit=yes' in privileged.UNIT_CONTENT, \
    'oneshot 必须 RemainAfterExit，否则开机后状态会显示为 inactive'
assert 'Type=oneshot' in privileged.UNIT_CONTENT
assert 'ExecStart=/usr/bin/python3 /usr/lib/freedombox-routes/apply.py' \
    in privileged.UNIT_CONTENT, 'unit 应调用上面的开机脚本'
assert 'After=network-online.target' in privileged.UNIT_CONTENT, \
    '必须等网络就绪后再加路由，否则网关还不存在'
print('  unit 关键行:')
for line in privileged.UNIT_CONTENT.splitlines():
    if line.startswith(('Type=', 'RemainAfterExit=', 'ExecStart=', 'After=')):
        print('   ', line)
print('[通过] 脚本语法有效且不依赖 Plinth，unit 在联网后调用它')

print()
print('=' * 60)
print('测试 6：添加路由并写入配置')
print('=' * 60)
privileged._write_routes([])
calls = []
state = {'break_after_apply': False}


def fake_run(arguments):
    """Record the command and report success."""
    calls.append(list(arguments))
    return types.SimpleNamespace(stdout='', stderr='', returncode=0)


IPV4_PATH = '8.8.8.8 via 10.10.173.1 dev ens32 src 10.10.173.19'


def fake_probe_path(family):
    """Return the fake path to the Internet, optionally broken once applied.

    The live box has no IPv6 default route, so an empty IPv6 path mirrors
    reality and also exercises the "nothing to lose" branch.
    """
    applied = any('replace' in item for item in calls)
    if state['break_after_apply'] and applied:
        return ''

    return IPV4_PATH if family == 'ipv4' else ''


privileged._run = fake_run
privileged._probe_path = fake_probe_path

route = privileged.add_route('ipv4', '192.168.50.0/24', '172.16.19.254',
                             '', 0)
print('  返回:', route)
assert route['destination'] == '192.168.50.0/24'
assert route['id'], '应生成唯一 id'
assert len(privileged.read_routes()) == 1
assert any('replace' in item for item in calls)
print('  命令:', [c for c in calls if 'replace' in c])

print()
print('测试 7：路由会导致断网时自动撤销')
print()
privileged._write_routes([])
calls.clear()
state['break_after_apply'] = True
try:
    privileged.add_route('ipv4', '10.0.0.0/8', '10.10.173.1', '', 0)
except ValueError as error:
    print('  [撤销]', error)
else:
    raise AssertionError('会断网的路由本应被撤销')

assert any('del' in item for item in calls), '撤销时必须真正删除内核路由'
assert privileged.read_routes() == [], '撤销后不能写进配置文件'
print('  命令:', [c for c in calls if 'del' in c])
print('[通过] 应用后发现失去连通性，立即删除且不保存')

print()
print('测试 7b：改写外网路径同样要撤销')
print()
# 真实场景：把 VPN 隧道所在的 /24 指到 LAN 网关，隧道随即失效，
# 但内核里「仍然有路由」，只有比对路径才看得出来。
privileged._write_routes([])
calls.clear()
state['break_after_apply'] = False


def fake_probe_path_rewritten(family):
    """Return a different path once the route is in place."""
    if family != 'ipv4':
        return ''
    applied = any('replace' in item for item in calls)
    if applied:
        return '8.8.8.8 via 10.10.173.1 dev ens32 src 10.10.173.19 metric 50'
    return IPV4_PATH


privileged._probe_path = fake_probe_path_rewritten
try:
    privileged.add_route('ipv4', '10.10.10.0/24', '10.10.173.1', '', 0)
except ValueError as error:
    print('  [撤销]', error)
    assert '改写' in str(error), '应说明是路径被改写而不是彻底没有路由'
else:
    raise AssertionError('改写外网路径的路由本应被撤销')

assert any('del' in item for item in calls)
assert privileged.read_routes() == []
print('[通过] 路由仍在但出口被换掉时也能识别并撤销')

privileged._probe_path = fake_probe_path

print()
print('=' * 60)
print('测试 8：删除路由')
print('=' * 60)
state['break_after_apply'] = False
calls.clear()
route = privileged.add_route('ipv4', '192.168.60.0/24', '172.16.19.254',
                             'ens34', 100)
assert len(privileged.read_routes()) == 1
privileged.delete_route(route['id'])
assert privileged.read_routes() == []
assert any('del' in item for item in calls)
try:
    privileged.delete_route(route['id'])
except ValueError as error:
    print('  [拒绝] 重复删除:', error)
else:
    raise AssertionError('删除不存在的路由本应报错')
print('[通过] 删除同时清理内核与配置文件，重复删除有提示')

print()
print('=' * 60)
print('测试 9：网络分区的标签栏')
print('=' * 60)
# submenu.py 只用到 Django 的两个小接口，桩掉就能在本地验证。
django = types.ModuleType('django')
django_urls = types.ModuleType('django.urls')
django_utils = types.ModuleType('django.utils')
django_translation = types.ModuleType('django.utils.translation')


class NoReverseMatch(Exception):
    """Stand-in for django.urls.NoReverseMatch."""


ROUTES = {
    'networks:index': '/plinth/sys/networks/',
    'ipv6:index': '/plinth/sys/ipv6/',
    'routes:index': '/plinth/sys/routes/',
}


def fake_reverse(name, args=None, kwargs=None):
    """Resolve only the names the test knows about."""
    if name not in ROUTES:
        raise NoReverseMatch(name)
    return ROUTES[name]


django_urls.NoReverseMatch = NoReverseMatch
django_urls.reverse = fake_reverse
django_translation.gettext_lazy = lambda text: text
django.utils = django_utils
django_utils.translation = django_translation
sys.modules['django'] = django
sys.modules['django.urls'] = django_urls
sys.modules['django.utils'] = django_utils
sys.modules['django.utils.translation'] = django_translation

import submenu  # noqa: E402

Request = types.SimpleNamespace

tabs = submenu.entries(Request(path='/plinth/sys/routes/'))
print('  /plinth/sys/routes/ 的标签栏：')
for tab in tabs:
    print('   ', tab['text'], tab['url'], '← 当前' if tab['active'] else '')
assert [tab['text'] for tab in tabs] == ['网络', 'IPv6 网络', '静态路由']
assert [tab['active'] for tab in tabs] == [False, False, True], \
    '只有当前页对应的标签高亮'

tabs = submenu.entries(Request(path='/plinth/sys/networks/'))
assert [tab['active'] for tab in tabs] == [True, False, False], \
    '在 Networks 页上应高亮「网络」'
print('  /plinth/sys/networks/ 高亮：', tabs[0]['text'])

# 某个模块没装时，它的标签应当自动消失，而不是抛异常。
ROUTES.pop('ipv6:index')
tabs = submenu.entries(Request(path='/plinth/sys/routes/'))
assert [tab['text'] for tab in tabs] == ['网络', '静态路由']
print('  未安装 IPv6 模块时的标签栏：', [tab['text'] for tab in tabs])
ROUTES['ipv6:index'] = '/plinth/sys/ipv6/'

# install() 必须真的把标签栏塞进 Networks 页，而且只能包一层。
views_module = types.ModuleType('plinth.modules.networks.views')


class FakeNetworksView:
    """Minimal stand-in for plinth.modules.networks.views.NetworksAppView."""

    request = Request(path='/plinth/sys/networks/')
    original_calls = 0

    def get_context_data(self, **kwargs):
        type(self).original_calls += 1
        return {'menu_items': []}


views_module.NetworksAppView = FakeNetworksView
networks_module = types.ModuleType('plinth.modules.networks')
networks_module.views = views_module
modules_module = types.ModuleType('plinth.modules')
modules_module.networks = networks_module
plinth.modules = modules_module
sys.modules['plinth.modules'] = modules_module
sys.modules['plinth.modules.networks'] = networks_module
sys.modules['plinth.modules.networks.views'] = views_module

submenu.install()
submenu.install()  # 第二个模块重复安装时不能再包一层
context = FakeNetworksView().get_context_data()
assert [tab['text'] for tab in context['subsubmenu']] == \
    ['网络', 'IPv6 网络', '静态路由'], 'Networks 页应拿到完整标签栏'
assert FakeNetworksView.original_calls == 1, 'install() 只能包装一次'
assert FakeNetworksView._freedombox_network_submenu is True
print('  Networks 页上下文已注入标签栏，且只包装一次')
print('[通过] 标签顺序、高亮、缺模块降级与幂等安装都正确')

print()
print('全部测试通过')
