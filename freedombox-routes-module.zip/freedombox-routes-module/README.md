# FreedomBox 静态路由模块

给 Plinth 增加一个独立的静态路由管理页面，位置在「系统 → 网络 → 静态路由」。

解决的问题：NetworkManager 的连接配置里也能写静态路由，但那类路由跟着连接走，
连接一断就没了，也没法表达「与任何连接都无关、只要开机就要在」的路由。
本模块自己维护一份路由清单，用 `ip-route(8)` 下发，并在开机时由一个 systemd
oneshot 单元自动恢复。

## 安装

```bash
sudo bash install.sh
```

安装脚本共 9 步，任一步失败都会自动回滚。它会：

1. 检查 root、freedombox 包、`ip` 命令、网卡列表
2. 备份现有模块目录、启用标记、路由清单、当前 IPv4/IPv6 路由表
3. 部署模块代码到 `/usr/lib/python3/dist-packages/plinth/modules/routes/`
4. 逐个 `py_compile` 做语法检查
5. 写入启用标记 `/etc/freedombox/modules-enabled/routes`
6. 导入检查（模块、表单字段、路由校验、开机脚本语法、模板加载）
7. 重启 Plinth 并确认存活
8. 首次初始化：生成路由清单、开机脚本、systemd unit，启用并启动服务
9. 验证文件权限、服务状态，独立跑一遍开机脚本，确认默认路由没被动过

## 卸载

```bash
sudo bash rollback.sh              # 自动用最新备份
sudo bash rollback.sh /root/freedombox-routes-module-backup/20261027-153000
```

卸载顺序是先停服务、删 unit，再删恢复脚本，最后才动路由清单 —— 否则 systemd
可能在中途用残留脚本把路由又加回来。

注意：卸载**不会**删除已经生效的非默认路由。它们会随重启自然消失；要立即清掉
得手工 `ip route del`。

## 文件清单

| 路径 | 作用 | 权限 |
| --- | --- | --- |
| `/usr/lib/python3/dist-packages/plinth/modules/routes/` | 模块代码 | 755 / 644 |
| `/etc/freedombox/modules-enabled/routes` | 启用标记 | 644 |
| `/etc/freedombox-routes/routes.json` | 路由清单 | 644 |
| `/usr/lib/freedombox-routes/apply.py` | 开机恢复脚本 | 755 |
| `/etc/systemd/system/freedombox-routes.service` | oneshot 单元 | 644 |

路由清单是 0644，因为页面渲染时要读它；里面只有网段和网关，不含凭据。

## 页面结构

页面分三块，从上到下：

1. **添加静态路由** —— 协议（IPv4/IPv6 单选）、目标网段（CIDR）、下一跳网关、
   出接口（下拉，含「自动选择」）、跃点（可选）
2. **本页面管理的路由** —— 只有本模块添加的路由，每行带「删除」按钮
3. **系统当前路由表** —— 内核里全部 IPv4 + IPv6 路由，只读，
   属于本模块的条目标记为「本页面管理」

第三块是刻意加的：只看自己管理的路由，很容易忘记系统里已经有一条更具体的路由
在抢流量，出了问题也无从判断。

## 安全边界

这些限制都写在 `_validate_route()` 里，是硬性拦截，不是提示：

| 输入 | 结果 | 原因 |
| --- | --- | --- |
| `0.0.0.0/0`、`::/0` | 拒绝 | 默认路由改错会直接断网，只允许命令行手工操作 |
| `192.168.50.0`（无前缀） | 拒绝 | `ipaddress` 会当成 `/32` 主机路由，与用户意图几乎总是不符 |
| 网段与所选协议不符 | 拒绝 | 例如选了 IPv4 却填 `fd00:50::/64` |
| 网关与网段协议不符 | 拒绝 | 例如 IPv4 网段配 IPv6 网关 |
| 网卡不存在 | 拒绝 | 拿 `ip -o link show` 的实际结果比对 |
| 网关和出接口都空 | 拒绝 | 这样的路由无法生效 |
| 跃点不在 0～4294967295 | 拒绝 | 内核的取值范围 |
| 同协议下重复网段 | 拒绝 | 避免两条配置互相覆盖，让人误判 |

**断网自愈**：`add_route()` 在下发路由**之前**先用 `ip route get` 记下本机到
外网走的路径（IPv4 记 `8.8.8.8`，IPv6 记 `2001:4860:4860::8888`），下发后
**再记一次并比对**。如果原来通、现在不通，或者出口被换到了别的网卡/网关，立刻
`ip route del` 撤销，并且**不写入配置文件**，同时在页面上报错：

> 这条路由改写了本机访问外网所走的 IPv4 路径，已撤销，未保存。请检查目标网段
> 是否覆盖了本机自己的地址、上游网关，或者 VPN 隧道所在的网段。

这里必须比对**路径**而不是「有没有路由」：`ip route replace` 永远不会删掉已有
路由，所以「加一条路由后 `ip route get` 失败」这种判断几乎永远不会成立。真正
危险的场景是把 VPN 隧道所在的网段（比如 `10.10.10.0/24`）指到 LAN 网关 ——
内核里路由照样存在，隧道却断了，只有比对出口才能发现。

如果某一路由族本来就没有出口（比如纯 IPv4 的内网机器没有 IPv6 默认路由），
这一族的检查会被跳过，不会误报。

## 开机恢复

`freedombox-routes.service` 是 `Type=oneshot` + `RemainAfterExit=yes`：

```ini
[Unit]
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/bin/python3 /usr/lib/freedombox-routes/apply.py

[Install]
WantedBy=multi-user.target
```

`After=network-online.target` 是必须的：网关地址要等网络起来才存在，早于它执行
`ip route replace` 会失败。

`apply.py` 刻意**不 import Plinth**，只用标准库。这样即使 Plinth 崩了、正在升级、
或者被临时禁用，开机时路由照样恢复。它逐条 `replace`，单条失败只跳过不中断，
所以重复执行是幂等的。

## 已知边界

- **只管非默认路由**。默认路由交给 NetworkManager 和上游，本页面拒绝修改。
- **不处理策略路由**（`ip rule`、多路由表）。需要的话得手工配。
- **不做持久化到 NetworkManager**。路由不绑定连接，这是设计目标，但也意味着
  连接切换（比如 WAN 换网卡）时路由会短暂失效，直到下次开机或手工重新下发。
- **断网自愈只探测两个固定地址**（`8.8.8.8` 和 `2001:4860:4860::8888`）。
  如果本机本来就不通外网（纯内网环境），这个保护不会触发 —— 因为探测一开始
  就是不通的，无从比较。
- **跃点留空表示不指定**，交给内核选默认值（通常是 0）。

## 排错

```bash
# 看服务有没有跑过、退出码是多少
systemctl status freedombox-routes

# 手工触发一次恢复，看有没有报错
sudo /usr/bin/python3 /usr/lib/freedombox-routes/apply.py

# 看当前路由清单
cat /etc/freedombox-routes/routes.json

# 看内核实际路由表
ip -4 route show
ip -6 route show
```

如果页面报「添加路由失败」，把 `ip route replace ...` 手工执行一遍，
通常能直接看到内核给的原因（`Nexthop has invalid gateway`、`Network is
unreachable` 之类）。
