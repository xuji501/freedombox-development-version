# SPDX-License-Identifier: AGPL-3.0-or-later
"""Pure helpers for the OSPF page of the static routes app.

Nothing in here touches the system: every function takes plain dictionaries and
returns plain values, so the rules that decide what ends up in FRR's
configuration file can be tested without root, without FRR and without a
network.

The vocabulary follows RouterOS, because that is what the administrators of
these boxes already know:

===============  =========================================================
RouterOS         here
===============  =========================================================
instance         global settings (router-id, redistribute, distance)
area             area (default / stub / nssa)
interface        interface (network type, cost, priority, timers, auth)
neighbor         neighbour table, read only, straight from FRR
===============  =========================================================

OSPFv2 (IPv4) only.  OSPFv3 is a different daemon with a different
configuration language, and pretending the two are one page would produce a
form whose half the fields silently do nothing.
"""

import ipaddress

#: Marker lines that fence the block this app owns inside /etc/frr/frr.conf.
#: Everything outside the fence belongs to somebody else and is copied back
#: untouched, so a hand written or RouteWeb generated configuration survives.
BEGIN_MARKER = '! >>> freedombox-ospf begin (managed by Plinth, do not edit) >>>'
END_MARKER = '! <<< freedombox-ospf end <<<'

AREA_TYPES = ('default', 'stub', 'nssa')
NETWORK_TYPES = ('broadcast', 'point-to-point', 'non-broadcast',
                 'point-to-multipoint')
AUTH_TYPES = ('none', 'simple', 'md5')
ORIGINATE_MODES = ('none', 'conditional', 'always')

DEFAULT_GLOBAL = {
    'enabled': False,
    'router_id': '',
    'redistribute_connected': True,
    'redistribute_static': False,
    'redistribute_kernel': False,
    'default_originate': 'none',
    'distance': 110,
    'log_adjacency': True,
}

#: Defaults that make a freshly added interface behave like RouterOS does.
DEFAULT_INTERFACE = {
    'network_type': 'broadcast',
    'cost': 10,
    'priority': 1,
    'hello': 10,
    'dead': 40,
    'passive': False,
    'auth': 'none',
    'auth_key': '',
}


def normalize_area_id(text: str) -> str:
    """Return the area id in dotted quad form.

    FRR prints and accepts ``0.0.0.1``; people type ``1``.  Both mean the same
    area, and storing them in different forms would let the same area be added
    twice.
    """
    value = (text or '').strip()
    if not value:
        raise ValueError('区域 ID 不能为空，骨干区域请填 0 或 0.0.0.0')

    if value.isdigit():
        number = int(value)
        if number > 4294967295:
            raise ValueError('区域 ID 超出范围，最大为 4294967295')
        return str(ipaddress.IPv4Address(number))

    try:
        return str(ipaddress.IPv4Address(value))
    except ValueError as exception:
        raise ValueError(
            '区域 ID 格式不正确：{}。可以写成 0、1 这样的整数，'
            '也可以写成 0.0.0.1 这样的点分形式。'.format(value)) from exception


def normalize_area(area: dict) -> dict:
    """Validate one area and return it in canonical form."""
    area_id = normalize_area_id(area.get('id'))
    area_type = (area.get('type') or 'default').strip()
    if area_type not in AREA_TYPES:
        raise ValueError('区域类型只能是 default、stub 或 nssa')

    no_summary = bool(area.get('no_summary'))
    if no_summary and area_type == 'default':
        raise ValueError('只有 stub 或 nssa 区域才能设置「不发汇总路由」')

    return {'id': area_id, 'type': area_type, 'no_summary': no_summary}


def normalize_interface(interface: dict, known_areas: list[str],
                        known_devices: list[str]) -> dict:
    """Validate one interface entry and return it in canonical form."""
    name = (interface.get('interface') or '').strip()
    if not name:
        raise ValueError('请选择要运行 OSPF 的接口')
    if known_devices and name not in known_devices:
        raise ValueError('接口 {} 不存在'.format(name))

    area = normalize_area_id(interface.get('area'))
    if known_areas and area not in known_areas:
        raise ValueError('区域 {} 还没有添加，请先在上方添加该区域'.format(area))

    network_type = (interface.get('network_type') or 'broadcast').strip()
    if network_type not in NETWORK_TYPES:
        raise ValueError('网络类型不在支持范围内')

    def _number(key: str, minimum: int, maximum: int, label: str) -> int:
        raw = interface.get(key)
        if raw in (None, ''):
            return int(DEFAULT_INTERFACE[key])
        try:
            value = int(raw)
        except (TypeError, ValueError) as exception:
            raise ValueError('{} 必须是整数'.format(label)) from exception
        if value < minimum or value > maximum:
            raise ValueError(
                '{} 必须在 {} 到 {} 之间'.format(label, minimum, maximum))
        return value

    cost = _number('cost', 1, 65535, 'Cost')
    priority = _number('priority', 0, 255, '优先级')
    hello = _number('hello', 1, 65535, 'Hello 间隔')
    dead = _number('dead', 1, 65535, 'Dead 间隔')
    if dead <= hello:
        raise ValueError(
            'Dead 间隔必须大于 Hello 间隔。默认的 10 / 40 适合绝大多数网络。')

    auth = (interface.get('auth') or 'none').strip()
    if auth not in AUTH_TYPES:
        raise ValueError('认证方式不在支持范围内')

    auth_key = (interface.get('auth_key') or '').strip()
    if auth == 'none':
        auth_key = ''
    elif not auth_key:
        raise ValueError('选择了认证就必须填写密钥')
    elif len(auth_key) > 64:
        raise ValueError('认证密钥最长 64 个字符')
    elif any(character.isspace() for character in auth_key):
        raise ValueError('认证密钥不能包含空格')

    return {
        'interface': name,
        'area': area,
        'network_type': network_type,
        'cost': cost,
        'priority': priority,
        'hello': hello,
        'dead': dead,
        'passive': bool(interface.get('passive')),
        'auth': auth,
        'auth_key': auth_key,
    }


def normalize_global(values: dict) -> dict:
    """Validate the instance level settings."""
    router_id = (values.get('router_id') or '').strip()
    if router_id:
        try:
            router_id = str(ipaddress.IPv4Address(router_id))
        except ValueError as exception:
            raise ValueError(
                'Router ID 必须是 IPv4 地址形式，例如 10.10.173.19；'
                '留空则由系统自动选举。') from exception

    originate = (values.get('default_originate') or 'none').strip()
    if originate not in ORIGINATE_MODES:
        raise ValueError('默认路由注入方式不在支持范围内')

    try:
        distance = int(values.get('distance') or 110)
    except (TypeError, ValueError) as exception:
        raise ValueError('管理距离必须是整数') from exception
    if distance < 1 or distance > 255:
        raise ValueError('管理距离必须在 1 到 255 之间')

    return {
        'enabled': bool(values.get('enabled')),
        'router_id': router_id,
        'redistribute_connected': bool(values.get('redistribute_connected')),
        'redistribute_static': bool(values.get('redistribute_static')),
        'redistribute_kernel': bool(values.get('redistribute_kernel')),
        'default_originate': originate,
        'distance': distance,
        'log_adjacency': bool(values.get('log_adjacency', True)),
    }


def build_fragment(config: dict) -> str:
    """Render the FRR configuration block for *config*.

    Returns an empty string when OSPF is disabled, which is how the caller
    knows to drop the block entirely instead of writing a no-op one.
    """
    global_settings = config.get('global') or DEFAULT_GLOBAL
    if not global_settings.get('enabled'):
        return ''

    areas = config.get('areas') or []
    interfaces = config.get('interfaces') or []
    if not interfaces:
        raise ValueError(
            '至少要为一块网卡启用 OSPF，否则路由器不会与任何邻居建立关系。'
            '如果要移除最后一块网卡，请先关闭 OSPF。')

    lines = ['router ospf']

    router_id = global_settings.get('router_id') or ''
    if router_id:
        lines.append(' ospf router-id {}'.format(router_id))

    if global_settings.get('log_adjacency', True):
        lines.append(' log-adjacency-changes')

    for key, keyword in (('redistribute_connected', 'connected'),
                         ('redistribute_static', 'static'),
                         ('redistribute_kernel', 'kernel')):
        if global_settings.get(key):
            lines.append(' redistribute {}'.format(keyword))

    originate = global_settings.get('default_originate') or 'none'
    if originate == 'always':
        lines.append(' default-information originate always')
    elif originate == 'conditional':
        lines.append(' default-information originate')

    distance = int(global_settings.get('distance') or 110)
    lines.append(' distance ospf external {} inter-area {} intra-area {}'.format(
        distance, distance, distance))

    for area in areas:
        suffix = ' no-summary' if area.get('no_summary') else ''
        if area['type'] == 'stub':
            lines.append(' area {} stub{}'.format(area['id'], suffix))
        elif area['type'] == 'nssa':
            lines.append(' area {} nssa{}'.format(area['id'], suffix))

    for interface in interfaces:
        if interface.get('passive'):
            lines.append(' passive-interface {}'.format(interface['interface']))

    lines.append('!')

    for interface in interfaces:
        lines.append('interface {}'.format(interface['interface']))
        lines.append(' ip ospf area {}'.format(interface['area']))
        if interface['network_type'] != 'broadcast':
            lines.append(' ip ospf network {}'.format(
                interface['network_type']))
        lines.append(' ip ospf cost {}'.format(interface['cost']))
        lines.append(' ip ospf priority {}'.format(interface['priority']))
        lines.append(' ip ospf hello-interval {}'.format(interface['hello']))
        lines.append(' ip ospf dead-interval {}'.format(interface['dead']))

        if interface['auth'] == 'simple':
            lines.append(' ip ospf authentication')
            lines.append(' ip ospf authentication-key {}'.format(
                interface['auth_key']))
        elif interface['auth'] == 'md5':
            lines.append(' ip ospf authentication message-digest')
            lines.append(' ip ospf message-digest-key 1 md5 {}'.format(
                interface['auth_key']))

        lines.append('!')

    return '\n'.join(lines)


def strip_block(text: str) -> str:
    """Remove the fenced block from *text*, keeping everything else."""
    lines = text.splitlines()
    kept = []
    inside = False
    for line in lines:
        if line.strip() == BEGIN_MARKER:
            inside = True
            continue
        if line.strip() == END_MARKER:
            inside = False
            continue
        if not inside:
            kept.append(line)

    # Collapse the blank lines the removal may have left behind.
    while kept and not kept[-1].strip():
        kept.pop()

    return '\n'.join(kept)


def insert_block(text: str, fragment: str) -> str:
    """Return *text* with *fragment* fenced at the end of the file."""
    base = strip_block(text)
    if not fragment:
        return base + '\n' if base else ''

    lines = [base] if base else []
    lines.append(BEGIN_MARKER)
    lines.append(fragment)
    lines.append(END_MARKER)
    return '\n'.join(lines) + '\n'


def has_block(text: str) -> bool:
    """Return whether *text* already carries our fenced block."""
    return any(line.strip() == BEGIN_MARKER for line in text.splitlines())


def has_foreign_ospf(text: str) -> bool:
    """Return whether *text* configures OSPF outside our fenced block.

    A file written by hand, or by another tool, must not be extended: FRR
    would end up with two overlapping OSPF stanzas and disabling OSPF from
    this page would leave the other one running.
    """
    for line in strip_block(text).splitlines():
        stripped = line.strip()
        if stripped.startswith('router ospf') or stripped.startswith('ip ospf'):
            return True

    return False


def enable_daemon(daemons_text: str, name: str, enabled: bool) -> str:
    """Turn one ``name=yes|no`` line of /etc/frr/daemons on or off."""
    wanted = '{}={}'.format(name, 'yes' if enabled else 'no')
    lines = daemons_text.splitlines()
    replaced = False
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('{}='.format(name)):
            lines[index] = wanted
            replaced = True
            break

    if not replaced:
        lines.append(wanted)

    return '\n'.join(lines) + '\n'
