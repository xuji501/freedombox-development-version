# SPDX-License-Identifier: AGPL-3.0-or-later
"""URLs for the static routes module."""

from django.urls import re_path

from . import views

urlpatterns = [
    re_path(r'^sys/routes/$', views.RoutesAppView.as_view(), name='index'),
    re_path(r'^sys/routes/delete/$', views.RouteDeleteView.as_view(),
            name='delete'),
    re_path(r'^sys/routes/ospf/$', views.OspfAppView.as_view(), name='ospf'),
    re_path(r'^sys/routes/ospf/action/$', views.OspfActionView.as_view(),
            name='ospf_action'),
]
