# SPDX-License-Identifier: AGPL-3.0-or-later
"""Django form for adding a static route."""

import logging

from django import forms

from . import privileged

logger = logging.getLogger(__name__)


class RouteForm(forms.Form):
    """Destination, next hop and interface of a new route."""

    family = forms.ChoiceField(
        label='协议',
        choices=[('ipv4', 'IPv4'), ('ipv6', 'IPv6')],
        widget=forms.RadioSelect, initial='ipv4')

    destination = forms.CharField(
        label='目标网段',
        widget=forms.TextInput(attrs={'placeholder': '192.168.50.0/24'}),
        help_text='CIDR 写法。例如 192.168.50.0/24 表示整个网段，'
                  '10.1.2.3/32 表示单个地址。不允许填写默认路由 0.0.0.0/0。')

    gateway = forms.CharField(
        label='下一跳网关', required=False,
        widget=forms.TextInput(attrs={'placeholder': '172.16.19.254'}),
        help_text='数据包交给谁转发。通常是与本机直连的网段里的某个地址。')

    device = forms.ChoiceField(
        label='出接口', required=False,
        help_text='留空则由系统根据网关自动选择。')

    metric = forms.IntegerField(
        label='跃点（可选）', required=False, min_value=0,
        max_value=4294967295,
        help_text='数值越小优先级越高，留空表示使用系统默认值。')

    def __init__(self, *args, **kwargs):
        """Populate the interface list from the live system."""
        super().__init__(*args, **kwargs)
        self.fields['device'].choices = self._device_choices()

    @staticmethod
    def _device_choices():
        """Return the interfaces as (value, label) pairs."""
        try:
            devices = privileged.get_devices()
        except Exception:
            logger.exception('Unable to list network interfaces')
            devices = []

        return [('', '自动选择')] + [(name, name) for name in devices]

    def clean(self):
        """Require at least one way to reach the next hop."""
        cleaned = super().clean()
        if cleaned.get('destination') and not cleaned.get('gateway') \
           and not cleaned.get('device'):
            raise forms.ValidationError(
                '请至少填写「下一跳网关」或选择一个「出接口」，'
                '否则这条路由无法生效。')

        return cleaned
