# SPDX-License-Identifier: AGPL-3.0-or-later
"""FreedomBox app to manage static routes and OSPF."""

from django.utils.translation import gettext_lazy as _

from plinth import app as app_module
from plinth import menu

from . import manifest, privileged, submenu

_description = [
    _('静态路由告诉系统：访问某个网段时应该走哪个网关或哪个网卡。'
      '当目标网络不在本机直连的网段里、又不该走默认路由时，就需要手工指定。'),
    _('OSPF 动态路由让本机与同一区域内的其他路由器自动交换网段信息，'
      '网络拓扑变化时无需逐台修改。它基于系统自带的 FRR，'
      '配置项参照 RouterOS 的实例、区域、接口三段式设计。'),
    _('这里配置的静态路由保存在本机，开机时自动恢复，不依赖具体的网络连接。'
      '默认路由不允许在这里修改，以免一条误操作让整台机器失去连通性。'),
]


class RoutesApp(app_module.App):
    """FreedomBox app for static routes and OSPF."""

    app_id = 'routes'

    _version = 2

    def __init__(self) -> None:
        """Create components for the app."""
        super().__init__()

        info = app_module.Info(app_id=self.app_id, version=self._version,
                               name=_('路由管理'), icon='fa-random',
                               description=_description, tags=manifest.tags)
        self.add(info)

        # Plinth only renders two levels of menu (the sections of the System
        # page and the cards inside them), so an item whose parent is the
        # Networks card would never be drawn anywhere.  Stay a sibling of the
        # Networks card instead, and add the shared tab bar to the Networks
        # page in post_init().
        menu_item = menu.Menu('menu-routes', info.name, info.icon, info.tags,
                              'routes:index', parent_url_name='system:system',
                              order=24)
        self.add(menu_item)

    def post_init(self):
        """Add the shared tab bar to the Networks page."""
        submenu.install()

    def setup(self, old_version):
        """Install the configuration file, helper and unit."""
        super().setup(old_version)
        privileged.setup()
        if not old_version:
            self.enable()

    def uninstall(self):
        """Remove the routes and the boot time helper."""
        super().uninstall()
        privileged.uninstall()
