# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tags for the static routes app."""

from django.utils.translation import gettext_lazy as _

tags = [_('网络'), _('路由'), _('OSPF'), _('系统')]
