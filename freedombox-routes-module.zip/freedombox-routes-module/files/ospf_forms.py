# SPDX-License-Identifier: AGPL-3.0-or-later
"""Django forms for the OSPF page.

The three forms are deliberately separate: the instance settings, the areas and
the interface list are edited independently, and mixing them into one form
would make every save rewrite all of them.
"""

import logging

from django import forms

from . import ospf_config

logger = logging.getLogger(__name__)

NETWORK_TYPE_CHOICES = [
    ('broadcast', '广播（broadcast，以太网默认）'),
    ('point-to-point', '点到点（point-to-point，隧道与串口）'),
    ('non-broadcast', '非广播（non-broadcast，需手工配邻居）'),
    ('point-to-multipoint', '点到多点（point-to-multipoint）'),
]

AUTH_CHOICES = [
    ('none', '不认证'),
    ('simple', '明文密码'),
    ('md5', 'MD5 摘要'),
]

ORIGINATE_CHOICES = [
    ('none', '不注入'),
    ('conditional', '本机有默认路由时注入'),
    ('always', '始终注入'),
]


class OspfGlobalForm(forms.Form):
    """Instance level settings, the RouterOS ``instance`` tab."""

    enabled = forms.BooleanField(
        label='启用 OSPF', required=False,
        help_text='勾选并保存后才会启动 ospfd 并向邻居发送报文。')

    router_id = forms.CharField(
        label='Router ID', required=False,
        widget=forms.TextInput(attrs={'placeholder': '10.10.173.19'}),
        help_text='本机在 OSPF 域内的唯一标识，写成 IPv4 地址形式。'
                  '留空则由系统自动选举（通常取最大的环回或接口地址）。')

    redistribute_connected = forms.BooleanField(
        label='重分发直连网段', required=False, initial=True,
        help_text='把本机所有直连网段当作外部路由通告出去。'
                  '多网段组网时通常需要开启。')

    redistribute_static = forms.BooleanField(
        label='重分发静态路由', required=False,
        help_text='把「静态路由」页面里配置的路由通告给邻居。')

    redistribute_kernel = forms.BooleanField(
        label='重分发内核路由', required=False,
        help_text='把内核路由表里的其他路由通告出去。与上一项同时开启时容易重复，'
                  '一般二选一。')

    default_originate = forms.ChoiceField(
        label='默认路由注入', choices=ORIGINATE_CHOICES, initial='none',
        help_text='让本机成为 OSPF 域内的出口网关。'
                  '「始终注入」不需要本机先有默认路由，适合双出口场景。')

    distance = forms.IntegerField(
        label='管理距离', initial=110, min_value=1, max_value=255,
        help_text='OSPF 路由的可信度，数值越小越优先。'
                  'Cisco 与 RouterOS 的默认值都是 110。')

    log_adjacency = forms.BooleanField(
        label='记录邻居状态变化', required=False, initial=True,
        help_text='邻居建立或断开时写入日志，排障时很有用。')


class OspfAreaForm(forms.Form):
    """One area, the RouterOS ``area`` tab."""

    area_id = forms.CharField(
        label='区域 ID',
        widget=forms.TextInput(attrs={'placeholder': '0'}),
        help_text='骨干区域填 0 或 0.0.0.0，其他区域可以填 1、2 这样的整数，'
                  '也可以写成 0.0.0.1。')

    area_type = forms.ChoiceField(
        label='区域类型',
        choices=[('default', '普通区域（default）'),
                 ('stub', '末梢区域（stub）'),
                 ('nssa', '非完全末梢区域（nssa）')],
        initial='default',
        help_text='末梢区域不接收外部路由，可减少区域内路由表规模。'
                  '不确定时保持普通区域。')

    no_summary = forms.BooleanField(
        label='不发汇总路由（no-summary）', required=False,
        help_text='仅对 stub / nssa 有效。勾选后连区域间汇总路由也不下发，'
                  '成为完全末梢区域。')

    def clean_area_id(self):
        """Normalise the id so that 1 and 0.0.0.1 cannot both be added."""
        return ospf_config.normalize_area_id(self.cleaned_data.get('area_id'))


class OspfInterfaceChoiceMixin:
    """Populate the interface and area choices from the live system."""

    def __init__(self, *args, devices=None, areas=None, **kwargs):
        """Accept pre-fetched choices so the page only queries the system once."""
        super().__init__(*args, **kwargs)

        if devices is None or areas is None:
            from . import privileged  # local import: avoid a cycle at import

            try:
                data = privileged.get_ospf()
            except Exception:
                logger.exception('Unable to read the OSPF configuration')
                data = {'devices': [], 'areas': []}
            devices = devices if devices is not None else data['devices']
            areas = areas if areas is not None else data['areas']

        self.fields['interface'].choices = [
            (name, name) for name in devices
        ] or [('', '没有可用接口')]

        area_choices = [(item['id'], item['id']) for item in areas]
        self.fields['area'].choices = area_choices or [('', '请先添加区域')]


class OspfInterfaceForm(OspfInterfaceChoiceMixin, forms.Form):
    """One interface, the RouterOS ``interface`` tab."""

    interface = forms.ChoiceField(label='接口', help_text='运行 OSPF 的网卡。')

    area = forms.ChoiceField(label='所属区域')

    network_type = forms.ChoiceField(
        label='网络类型', choices=NETWORK_TYPE_CHOICES, initial='broadcast',
        help_text='以太网与 GRE 以外的隧道保持广播；'
                  'GRE、WireGuard 这类点对点链路应选「点到点」，'
                  '否则会等待一个永远不会出现的 DR 选举。')

    cost = forms.IntegerField(
        label='Cost', initial=10, min_value=1, max_value=65535,
        help_text='链路开销，数值越小越优先。默认按 10^8 / 带宽 计算，'
                  '手工填写时通常千兆填 10、百兆填 100。')

    priority = forms.IntegerField(
        label='优先级', initial=1, min_value=0, max_value=255,
        help_text='DR / BDR 选举权重，越大越容易被选中，0 表示不参与选举。')

    hello = forms.IntegerField(
        label='Hello 间隔（秒）', initial=10, min_value=1, max_value=65535,
        help_text='发送 Hello 报文的时间间隔。同一网段内所有路由器必须一致。')

    dead = forms.IntegerField(
        label='Dead 间隔（秒）', initial=40, min_value=1, max_value=65535,
        help_text='超过这个时间收不到 Hello 就认为邻居失效。'
                  '通常为 Hello 间隔的 4 倍。')

    passive = forms.BooleanField(
        label='被动接口', required=False,
        help_text='只把该网段通告出去，不在这块网卡上收发 OSPF 报文。'
                  '面向终端的接口应该勾选。')

    auth = forms.ChoiceField(
        label='认证方式', choices=AUTH_CHOICES, initial='none',
        help_text='同一网段内所有路由器必须使用相同的认证方式与密钥。')

    auth_key = forms.CharField(
        label='认证密钥', required=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'},
                                   render_value=False),
        help_text='最长 64 个字符，不能包含空格。'
                  '保存后不会再显示，需要更换时请删除该条目重新添加。')
