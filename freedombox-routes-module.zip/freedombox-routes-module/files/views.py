# SPDX-License-Identifier: AGPL-3.0-or-later
"""Views for the static routes app."""

import logging

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect
from django.urls import NoReverseMatch, reverse
from django.views.generic import View

from plinth.views import AppView

from . import privileged, submenu
from .forms import RouteForm
from .ospf_forms import (OspfAreaForm, OspfGlobalForm, OspfInterfaceForm)

logger = logging.getLogger(__name__)


def _module_url(name: str, fallback: str) -> str:
    """Resolve a URL of this module, tolerating a missing namespace."""
    try:
        return reverse('routes:{}'.format(name))
    except NoReverseMatch:
        return fallback


def _index_url() -> str:
    """Return the URL of the app page."""
    return _module_url('index', '/plinth/sys/routes/')


def _ospf_url() -> str:
    """Return the URL of the OSPF page."""
    return _module_url('ospf', '/plinth/sys/routes/ospf/')


def _route_tabs(request) -> list:
    """Return the 静态路由 / OSPF switch shown on both pages.

    The entries carry an icon so the two halves of this app are told apart at a
    glance, and they are rendered as Bootstrap tabs by the two templates.
    """
    return [
        {'url': _index_url(), 'text': '静态路由', 'icon': 'fa-map-signs',
         'active': request.path.rstrip('/') == _index_url().rstrip('/')},
        {'url': _ospf_url(), 'text': 'OSPF 动态路由', 'icon': 'fa-exchange',
         'active': request.path.startswith(_ospf_url().rstrip('/'))},
    ]


class RoutesAppView(AppView):
    """Show the managed routes and the live routing table."""

    app_id = 'routes'
    template_name = 'routes.html'
    form_class = RouteForm

    def get_context_data(self, **kwargs):
        """Expose the saved routes and the kernel's current table."""
        context = super().get_context_data(**kwargs)

        try:
            data = privileged.get_routes()
        except Exception:
            logger.exception('Unable to read the routing table')
            data = {'managed': [], 'system': [], 'devices': []}

        context['managed_routes'] = data['managed']
        context['system_routes'] = data['system']
        context['subsubmenu'] = submenu.entries(self.request)
        context['route_tabs'] = _route_tabs(self.request)
        context['delete_url'] = _module_url('delete', '/plinth/sys/routes/delete/')
        return context

    def form_valid(self, form):
        """Apply the new route and save it."""
        data = form.cleaned_data
        try:
            route = privileged.add_route(
                data['family'], data['destination'],
                data.get('gateway') or '', data.get('device') or '',
                int(data.get('metric') or 0))
        except Exception as exception:
            logger.exception('Unable to add the route')
            messages.error(self.request, '添加失败：{}'.format(exception))
            return self.form_invalid(form)

        messages.success(
            self.request,
            '已添加路由：{} 经由 {}。'.format(
                route['destination'],
                route['gateway'] or route['device'] or '自动'))
        return super().form_valid(form)


class RouteDeleteView(LoginRequiredMixin, View):
    """Delete one managed route."""

    def post(self, request):
        """Remove the route identified by its id."""
        route_id = (request.POST.get('route_id') or '').strip()
        try:
            route = privileged.delete_route(route_id)
            messages.success(request,
                             '已删除路由：{}。'.format(route['destination']))
        except Exception as exception:
            logger.exception('Unable to delete the route')
            messages.error(request, '删除失败：{}'.format(exception))

        return redirect(_index_url())

    def get(self, request):
        """Only POST is meaningful, so send the browser back to the page."""
        return redirect(_index_url())


# --------------------------------------------------------------------------- #
# OSPF
# --------------------------------------------------------------------------- #


class OspfAppView(AppView):
    """Instance settings, areas, interfaces and the live neighbour table."""

    app_id = 'routes'
    template_name = 'ospf.html'
    form_class = OspfAreaForm

    def _data(self):
        """Return the OSPF state, tolerating a broken configuration."""
        try:
            return privileged.get_ospf()
        except Exception:
            logger.exception('Unable to read the OSPF configuration')
            return {
                'global': dict(privileged.ospf_config.DEFAULT_GLOBAL),
                'areas': [],
                'interfaces': [],
                'neighbors': [],
                'devices': [],
                'frr_installed': False,
                'frr_active': False,
                'ospfd_running': False,
            }

    def get_context_data(self, **kwargs):
        """Expose the configuration and the two secondary forms."""
        context = super().get_context_data(**kwargs)
        data = self._data()

        context['ospf'] = data
        context['global_form'] = OspfGlobalForm(initial=data['global'])
        context['interface_form'] = OspfInterfaceForm(
            devices=data['devices'], areas=data['areas'])
        context['subsubmenu'] = submenu.entries(self.request)
        context['route_tabs'] = _route_tabs(self.request)
        context['action_url'] = _module_url(
            'ospf_action', '/plinth/sys/routes/ospf/action/')
        context['index_url'] = _index_url()
        context['ospf_url'] = _ospf_url()
        return context

    def form_valid(self, form):
        """Add the area described by the form."""
        data = form.cleaned_data
        try:
            area = privileged.add_ospf_area(
                area_id=data['area_id'], area_type=data['area_type'],
                no_summary=bool(data.get('no_summary')))
        except Exception as exception:
            logger.exception('Unable to add the OSPF area')
            messages.error(self.request, '添加区域失败：{}'.format(exception))
            return self.form_invalid(form)

        messages.success(self.request,
                         '已添加区域 {}。'.format(area['id']))
        return redirect(_ospf_url())


class OspfActionView(LoginRequiredMixin, View):
    """Save the instance settings, add an interface, or delete a row."""

    def post(self, request):
        """Dispatch on the ``action`` field posted by the page."""
        action = (request.POST.get('action') or '').strip()
        handler = {
            'global': self._save_global,
            'interface': self._add_interface,
            'area_delete': self._delete_area,
            'interface_delete': self._delete_interface,
        }.get(action)

        if not handler:
            messages.error(request, '未知操作：{}'.format(action))
            return redirect(_ospf_url())

        try:
            handler(request)
        except Exception as exception:
            logger.exception('Unable to run the OSPF action')
            messages.error(request, '操作失败：{}'.format(exception))

        return redirect(_ospf_url())

    def get(self, request):
        """Only POST is meaningful, so send the browser back to the page."""
        return redirect(_ospf_url())

    @staticmethod
    def _errors(form) -> str:
        """Flatten a form's errors into one readable line."""
        parts = []
        for field, errors in form.errors.items():
            label = form.fields[field].label if field in form.fields else field
            parts.append('{}：{}'.format(label, '；'.join(errors)))
        return '；'.join(parts)

    def _save_global(self, request):
        """Write the instance level settings."""
        form = OspfGlobalForm(request.POST)
        if not form.is_valid():
            messages.error(request, '保存失败：{}'.format(self._errors(form)))
            return

        data = form.cleaned_data
        privileged.save_ospf_global(
            enabled=bool(data.get('enabled')),
            router_id=data.get('router_id') or '',
            redistribute_connected=bool(data.get('redistribute_connected')),
            redistribute_static=bool(data.get('redistribute_static')),
            redistribute_kernel=bool(data.get('redistribute_kernel')),
            default_originate=data.get('default_originate') or 'none',
            distance=int(data.get('distance') or 110),
            log_adjacency=bool(data.get('log_adjacency')))

        messages.success(
            request,
            '已保存 OSPF 设置，{}。'.format(
                'ospfd 已启动' if data.get('enabled') else 'ospfd 已停止'))

    def _add_interface(self, request):
        """Attach one interface to an area."""
        form = OspfInterfaceForm(request.POST)
        if not form.is_valid():
            messages.error(request, '添加接口失败：{}'.format(self._errors(form)))
            return

        data = form.cleaned_data
        privileged.add_ospf_interface(
            interface=data['interface'], area=data['area'],
            network_type=data['network_type'], cost=int(data['cost']),
            priority=int(data['priority']), hello=int(data['hello']),
            dead=int(data['dead']), passive=bool(data.get('passive')),
            auth=data.get('auth') or 'none',
            auth_key=data.get('auth_key') or '')

        messages.success(request,
                         '已把接口 {} 加入区域 {}。'.format(
                             data['interface'], data['area']))

    def _delete_area(self, request):
        """Remove one area."""
        area = (request.POST.get('area_id') or '').strip()
        privileged.delete_ospf_area(area)
        messages.success(request, '已删除区域 {}。'.format(area))

    def _delete_interface(self, request):
        """Detach one interface."""
        interface = (request.POST.get('interface') or '').strip()
        privileged.delete_ospf_interface(interface)
        messages.success(request, '已从 OSPF 中移除接口 {}。'.format(interface))
