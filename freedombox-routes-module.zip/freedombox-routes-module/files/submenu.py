# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tab bar shared by the network related pages.

Plinth draws only two levels of menu: the sections of the System page and the
cards inside a section.  An item nested under a card -- ``networks:index`` for
instance -- is never drawn anywhere, so the page it points to cannot be found
by clicking around in the web interface.

This module builds the missing navigation by hand.  ``entries()`` returns the
tab bar for this module's own pages; ``install()`` adds the very same tab bar
to the Networks page through the ``subsubmenu`` context variable that
``app.html`` already knows how to render.  No file shipped by Plinth is
modified.
"""

import logging

from django.urls import NoReverseMatch, reverse
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)

#: Pages listed in the tab bar, in display order.  A page whose URL cannot be
#: resolved (its module is not installed) is simply skipped.
PAGES = (
    ('networks:index', _('网络'), 'fa-signal'),
    ('ipv6:index', _('IPv6 网络'), 'fa-globe'),
    ('routes:index', _('路由管理'), 'fa-random'),
    ('gre:index', _('GRE 隧道'), 'fa-road'),
)

#: Marker set on the patched view class, so that the second module installing
#: the same tab bar does not wrap the method twice.
PATCH_FLAG = '_freedombox_network_submenu'


def _label(icon: str, text):
    """Return a label with its icon, marked safe for the tab bar template.

    ``subsubmenu.html`` shipped by Plinth escapes ``urlitem.text``, so the
    markup has to be flagged safe here or the icon would be printed literally.
    The strings involved are literals from this file and translations of them,
    never anything supplied by a request.
    """
    return mark_safe('<span class="fa {}" aria-hidden="true"></span> {}'
                     .format(icon, text))


def entries(request):
    """Return the tab bar entries for *request*."""
    items = []
    for url_name, label, icon in PAGES:
        try:
            url = reverse(url_name)
        except NoReverseMatch:
            continue

        items.append({
            'url': url,
            'text': _label(icon, label),
            'active': request.path.startswith(url),
        })

    return items


def install():
    """Show the tab bar on the Networks page as well."""
    try:
        from plinth.modules.networks.views import NetworksAppView
    except Exception:  # pylint: disable=broad-except
        logger.exception('Unable to import the Networks view')
        return

    if getattr(NetworksAppView, PATCH_FLAG, False):
        return

    original = NetworksAppView.get_context_data

    def get_context_data(self, *args, **kwargs):
        context = original(self, *args, **kwargs)
        if self.request is not None:
            context.setdefault('subsubmenu', entries(self.request))
        return context

    NetworksAppView.get_context_data = get_context_data
    setattr(NetworksAppView, PATCH_FLAG, True)
    logger.info('Added the network tab bar to the Networks page')
