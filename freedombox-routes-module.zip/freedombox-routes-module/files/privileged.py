# SPDX-License-Identifier: AGPL-3.0-or-later
"""Manage static routes on FreedomBox.

NetworkManager can carry static routes inside a connection profile, but those
disappear with the connection and cannot express a route that has to survive
independently of it.  This app keeps its own list, applies it with ip-route(8)
and restores it at boot through a small systemd oneshot unit.
"""

import ipaddress
import json
import pathlib
import shutil
import subprocess
import time
import uuid

from plinth import action_utils
from plinth.actions import privileged

from . import ospf_config

CONFIG_DIR = pathlib.Path('/etc/freedombox-routes')
ROUTES_PATH = CONFIG_DIR / 'routes.json'
OSPF_PATH = CONFIG_DIR / 'ospf.json'

FRR_CONF_PATH = pathlib.Path('/etc/frr/frr.conf')
FRR_DAEMONS_PATH = pathlib.Path('/etc/frr/daemons')

APPLY_SCRIPT_PATH = '/usr/lib/freedombox-routes/apply.py'
UNIT_PATH = '/etc/systemd/system/freedombox-routes.service'
SERVICE_NAME = 'freedombox-routes'

FAMILIES = ('ipv4', 'ipv6')

UNIT_CONTENT = '''[Unit]
Description=FreedomBox static routes
Documentation=man:ip-route(8)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/bin/python3 {script}

[Install]
WantedBy=multi-user.target
'''.format(script=APPLY_SCRIPT_PATH)

# Kept free of Plinth imports so that a broken or upgrading Plinth cannot stop
# the routes from being restored at boot.
APPLY_SCRIPT = '''#!/usr/bin/python3
"""Re-apply the static routes saved by the FreedomBox routes app."""

import json
import subprocess

ROUTES_PATH = '/etc/freedombox-routes/routes.json'


def main():
    """Apply every saved route, ignoring individual failures."""
    try:
        with open(ROUTES_PATH, encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return

    for route in data.get('routes') or []:
        if not isinstance(route, dict) or not route.get('destination'):
            continue

        arguments = ['ip', '-6' if route.get('family') == 'ipv6' else '-4',
                     'route', 'replace', route['destination']]
        if route.get('gateway'):
            arguments += ['via', route['gateway']]
        if route.get('device'):
            arguments += ['dev', route['device']]
        if route.get('metric'):
            arguments += ['metric', str(route['metric'])]

        subprocess.run(arguments, capture_output=True, text=True, check=False)


main()
'''


def _run(arguments: list[str]):
    """Run a command and capture its output."""
    try:
        return subprocess.run(arguments, capture_output=True, text=True,
                              check=False)
    except OSError:
        return subprocess.CompletedProcess(arguments, 1, '', 'not found')


def read_routes() -> list[dict]:
    """Return the saved routes, skipping malformed entries.

    Safe to call from unprivileged code: the file is world readable.
    """
    try:
        data = json.loads(ROUTES_PATH.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []

    if not isinstance(data, dict):
        return []

    routes = []
    for item in data.get('routes') or []:
        if not isinstance(item, dict):
            continue
        if not isinstance(item.get('destination'), str):
            continue
        if item.get('family') not in FAMILIES:
            continue

        routes.append({
            'id': str(item.get('id') or ''),
            'family': item['family'],
            'destination': item['destination'],
            'gateway': item.get('gateway') or '',
            'device': item.get('device') or '',
            'metric': int(item.get('metric') or 0),
            'created': int(item.get('created') or 0),
        })

    return routes


def _write_routes(routes: list[dict]):
    """Persist the route list atomically."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    path = ROUTES_PATH
    temporary = path.with_suffix('.json.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        json.dump({'version': 1, 'routes': routes}, handle,
                  ensure_ascii=False, indent=2)
        handle.write('\n')
    temporary.chmod(0o644)
    temporary.replace(path)


def _route_arguments(route: dict, action: str) -> list[str]:
    """Build the ip-route command for one route."""
    arguments = ['ip', '-6' if route['family'] == 'ipv6' else '-4', 'route',
                 action, route['destination']]
    if route['gateway']:
        arguments += ['via', route['gateway']]
    if route['device']:
        arguments += ['dev', route['device']]
    if route['metric']:
        arguments += ['metric', str(route['metric'])]

    return arguments


def _devices() -> list[str]:
    """Return the network interfaces present on the system."""
    process = _run(['ip', '-o', 'link', 'show'])
    names = []
    for line in process.stdout.splitlines():
        parts = line.split(':')
        if len(parts) >= 2:
            names.append(parts[1].strip().split('@')[0])

    return sorted(set(names))


def _probe_path(family: str) -> str:
    """Return the path the kernel currently picks for a well known address.

    An empty string means there is no route at all.  Comparing this string
    before and after applying a route is how the app notices that it just
    redirected (or destroyed) the box's way to the Internet: merely asking
    whether *a* route exists is useless, because adding a route never removes
    one.
    """
    target = '2001:4860:4860::8888' if family == 'ipv6' else '8.8.8.8'
    process = _run(['ip', '-6' if family == 'ipv6' else '-4', 'route', 'get',
                    target])
    if process.returncode != 0:
        return ''

    return process.stdout.strip()


def _probe(family: str) -> bool:
    """Return whether a route to a well known address exists."""
    return bool(_probe_path(family))


def _connectivity_problem(before: dict) -> str:
    """Describe how the route just applied damaged connectivity, if it did.

    Returns an empty string when nothing got worse.
    """
    for family in FAMILIES:
        previous = before.get(family) or ''
        if not previous:
            # This box had no route of that family to begin with, so a change
            # here proves nothing.  Keeps the guard from firing on IPv6-less
            # boxes and on pure internal networks.
            continue

        current = _probe_path(family)
        label = 'IPv6' if family == 'ipv6' else 'IPv4'
        if not current:
            return '让本机失去了到外网的 {} 路由'.format(label)
        if current != previous:
            return '改写了本机访问外网所走的 {} 路径'.format(label)

    return ''


def _validate_route(route: dict, existing: list[dict]):
    """Check one route and return it in normalised form."""
    family = route['family']
    if family not in FAMILIES:
        raise ValueError('协议只能是 IPv4 或 IPv6')

    text = route['destination'].strip()
    if '/' not in text:
        # Without a prefix ipaddress would silently make it a /32 host route,
        # which is almost never what someone typing a network means.
        raise ValueError(
            '目标网段需要写明前缀长度，例如 192.168.50.0/24；'
            '只写 192.168.50.0 会被当成单个地址。')

    try:
        network = ipaddress.ip_network(text, strict=False)
    except ValueError as exception:
        raise ValueError(
            '目标网段格式不正确：{}（应写成 192.168.50.0/24 这样的形式）'.format(
                route['destination'])) from exception

    if network.prefixlen == 0:
        raise ValueError(
            '不允许通过本页面修改默认路由（{}/0），'
            '那会直接影响本机上网。请改用 ip route 手工操作。'.format(
                '::' if family == 'ipv6' else '0.0.0.0'))

    expected_version = 6 if family == 'ipv6' else 4
    if network.version != expected_version:
        raise ValueError(
            '目标网段 {} 与所选协议 {} 不一致'.format(network, family))

    gateway = (route.get('gateway') or '').strip()
    if gateway:
        try:
            address = ipaddress.ip_address(gateway)
        except ValueError as exception:
            raise ValueError(
                '网关地址格式不正确：{}'.format(gateway)) from exception
        if address.version != expected_version:
            raise ValueError(
                '网关 {} 与目标网段 {} 的协议不一致'.format(gateway, network))
        gateway = str(address)

    device = (route.get('device') or '').strip()
    if device and device not in _devices():
        raise ValueError('网卡 {} 不存在'.format(device))

    if not gateway and not device:
        raise ValueError('必须填写下一跳网关或出接口，至少填一个')

    metric = int(route.get('metric') or 0)
    if metric < 0 or metric > 4294967295:
        raise ValueError('跃点必须是 0 到 4294967295 之间的整数')

    destination = str(network)
    for item in existing:
        if item['family'] == family and item['destination'] == destination:
            raise ValueError(
                '已经存在一条到 {} 的路由，请先删除再添加'.format(destination))

    return {
        'family': family,
        'destination': destination,
        'gateway': gateway,
        'device': device,
        'metric': metric,
    }


def _parse_route_line(line: str) -> dict:
    """Turn one line of ip-route output into a readable row."""
    tokens = line.split()
    if not tokens:
        return {}

    row = {
        'destination': tokens[0],
        'gateway': '',
        'device': '',
        'metric': '',
        'proto': '',
    }

    for index, token in enumerate(tokens):
        following = tokens[index + 1] if index + 1 < len(tokens) else ''
        if token == 'via' and following:
            row['gateway'] = following
        elif token == 'dev' and following:
            row['device'] = following
        elif token == 'metric' and following:
            row['metric'] = following
        elif token == 'proto' and following:
            row['proto'] = following

    return row


def _system_routes(family: str) -> list[dict]:
    """Return the kernel's current routes for one family."""
    process = _run(['ip', '-6' if family == 'ipv6' else '-4', 'route',
                    'show'])
    rows = []
    for line in process.stdout.splitlines():
        row = _parse_route_line(line)
        if row:
            rows.append(row)

    return rows


def _write_apply_script():
    """Install the helper that restores the routes at boot."""
    path = pathlib.Path(APPLY_SCRIPT_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(APPLY_SCRIPT, encoding='utf-8')
    path.chmod(0o755)


def _write_unit():
    """Install the systemd unit that runs the helper at boot."""
    path = pathlib.Path(UNIT_PATH)
    path.write_text(UNIT_CONTENT, encoding='utf-8')
    path.chmod(0o644)
    action_utils.service_daemon_reload()


@privileged
def setup():
    """Create the configuration file, helper and unit."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not ROUTES_PATH.exists():
        _write_routes([])

    _write_apply_script()
    _write_unit()
    action_utils.service_enable(SERVICE_NAME)
    action_utils.service_start(SERVICE_NAME)


@privileged
def get_devices() -> list[str]:
    """Return the interfaces a route can be bound to."""
    return _devices()


@privileged
def get_routes() -> dict:
    """Return the managed routes, the live route table and the interfaces."""
    managed = read_routes()
    managed_keys = {
        (item['family'], item['destination'])
        for item in managed
    }

    system = []
    for family in FAMILIES:
        for row in _system_routes(family):
            row['family'] = family
            row['managed'] = (family, row['destination']) in managed_keys
            system.append(row)

    return {
        'managed': managed,
        'system': system,
        'devices': _devices(),
    }


@privileged
def add_route(family: str, destination: str, gateway: str,
              device: str, metric: int) -> dict:
    """Validate, save and apply a new route.

    The route is applied before it is trusted: if the box loses its way to the
    Internet because of it, the change is undone immediately instead of
    waiting for someone to notice.
    """
    routes = read_routes()
    route = _validate_route({
        'family': family,
        'destination': destination,
        'gateway': gateway,
        'device': device,
        'metric': metric,
    }, routes)

    had = {family: _probe_path(family) for family in FAMILIES}

    process = _run(_route_arguments(route, 'replace'))
    if process.returncode != 0:
        raise ValueError('添加路由失败：{}'.format(
            process.stderr.strip() or process.stdout.strip()))

    problem = _connectivity_problem(had)
    if problem:
        _run(_route_arguments(route, 'del'))
        raise ValueError(
            '这条路由{}，已撤销，未保存。请检查目标网段是否覆盖了本机自己的地址、'
            '上游网关，或者 VPN 隧道所在的网段。'.format(problem))

    route['id'] = uuid.uuid4().hex
    route['created'] = int(time.time())
    routes.append(route)
    _write_routes(routes)
    return route


@privileged
def delete_route(route_id: str) -> dict:
    """Remove a managed route from the kernel and from the saved list."""
    routes = read_routes()
    target = None
    for item in routes:
        if item['id'] == route_id:
            target = item
            break

    if not target:
        raise ValueError('没有找到这条路由，可能已经被删除')

    _run(_route_arguments(target, 'del'))
    _write_routes([item for item in routes if item['id'] != route_id])
    return target


@privileged
def uninstall():
    """Remove every managed route and the boot time helper."""
    uninstall_ospf()

    for route in read_routes():
        _run(_route_arguments(route, 'del'))

    action_utils.service_disable(SERVICE_NAME)
    try:
        pathlib.Path(UNIT_PATH).unlink()
    except OSError:
        pass

    try:
        pathlib.Path(APPLY_SCRIPT_PATH).unlink()
    except OSError:
        pass

    action_utils.service_daemon_reload()
    for directory in (CONFIG_DIR, pathlib.Path(APPLY_SCRIPT_PATH).parent):
        try:
            directory.rmdir()
        except OSError:
            pass


# --------------------------------------------------------------------------- #
# OSPF (FRR)
#
# FRR is the only OSPF implementation Debian ships, and it is already installed
# on these boxes with every daemon switched off.  Two consequences shape the
# code below:
#
# * /etc/frr/frr.conf may belong to somebody else (a hand written file, or a
#   RouteWeb generated one), so this app owns a fenced block and copies the
#   rest of the file back verbatim.  Overwriting the whole file would silently
#   delete another administrator's BGP sessions.
# * A configuration FRR refuses to load leaves the box with no routing daemon
#   at all.  Every write is therefore followed by a restart and a liveness
#   check, and a failure puts the previous file back before the error reaches
#   the user.
# --------------------------------------------------------------------------- #


def read_ospf() -> dict:
    """Return the saved OSPF configuration, filled in with defaults."""
    config = {
        'global': dict(ospf_config.DEFAULT_GLOBAL),
        'areas': [],
        'interfaces': [],
    }

    try:
        data = json.loads(OSPF_PATH.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return config

    if not isinstance(data, dict):
        return config

    stored = data.get('global') or {}
    if isinstance(stored, dict):
        for key, value in ospf_config.DEFAULT_GLOBAL.items():
            if key in stored:
                config['global'][key] = stored[key]

    for item in data.get('areas') or []:
        if not isinstance(item, dict) or not item.get('id'):
            continue
        try:
            area = ospf_config.normalize_area(item)
        except ValueError:
            continue
        config['areas'].append(area)

    for item in data.get('interfaces') or []:
        if not isinstance(item, dict) or not item.get('interface'):
            continue
        merged = dict(ospf_config.DEFAULT_INTERFACE)
        merged.update({key: value for key, value in item.items()
                       if key in merged})
        merged['interface'] = item['interface']
        merged['area'] = item.get('area') or '0.0.0.0'
        try:
            interface = ospf_config.normalize_interface(
                merged, [], [])
        except ValueError:
            continue
        config['interfaces'].append(interface)

    return config


def _write_ospf(config: dict):
    """Persist the OSPF configuration.  Contains MD5 keys, hence 0600."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    temporary = OSPF_PATH.with_suffix('.json.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        json.dump(config, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
    temporary.chmod(0o600)
    temporary.replace(OSPF_PATH)


def _frr_active() -> bool:
    """Return whether the FRR service is running."""
    process = _run(['systemctl', 'is-active', 'frr'])
    return process.stdout.strip() == 'active'


def _ospfd_running() -> bool:
    """Return whether the OSPF daemon itself is up."""
    return _run(['pgrep', '-x', 'ospfd']).returncode == 0


def _restart_frr(timeout: float = 12.0) -> bool:
    """Restart FRR and wait for it, clearing systemd's start rate limit first.

    A configuration FRR rejects makes systemd retry the unit five times in ten
    seconds and then refuse further starts with ``start-limit-hit``.  Without
    ``reset-failed`` the service would stay dead even after the previous
    configuration is put back, so the reset is not optional.
    """
    _run(['systemctl', 'reset-failed', 'frr'])
    _run(['systemctl', 'restart', 'frr'])

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _frr_active():
            return True
        time.sleep(0.5)

    return _frr_active()


def _wait_for_ospfd(timeout: float = 6.0) -> bool:
    """Give watchfrr a moment to fork ospfd before declaring failure."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _ospfd_running():
            return True
        time.sleep(0.5)

    return _ospfd_running()


def _journal_tail(lines: int = 12) -> str:
    """Return the last lines of the FRR journal, for error messages."""
    process = _run(['journalctl', '-u', 'frr', '-n', str(lines),
                    '--no-pager', '-o', 'cat'])
    return process.stdout.strip()


# --------------------------------------------------------------------------- #
# firewalld
#
# OSPF is IP protocol 89 and Debian's firewalld ships no service definition for
# it, so without a hand written one every Hello is dropped and the neighbour
# stays in Init forever — the symptom looks like a broken OSPF configuration
# rather than a firewall problem.  The service is added to the zone each OSPF
# interface already belongs to; the zone assignment itself is left alone,
# because moving an interface between zones would silently change what else it
# is allowed to do.
# --------------------------------------------------------------------------- #

OSPF_SERVICE_NAME = 'freedombox-ospf'
OSPF_SERVICE_PATH = pathlib.Path(
    '/etc/firewalld/services/freedombox-ospf.xml')
OSPF_FIREWALL_PATH = CONFIG_DIR / 'firewall.json'
OSPF_SERVICE_XML = '''<?xml version="1.0" encoding="utf-8"?>
<service>
  <short>OSPF</short>
  <description>OSPF 动态路由协议（IP 协议号 89）。由 FreedomBox 路由管理模块写入，\
供加入 OSPF 的接口使用。</description>
  <protocol value="89"/>
</service>
'''


def _firewalld_active() -> bool:
    """Return whether firewalld is managing the packet filter."""
    return _run(['systemctl', 'is-active',
                 'firewalld']).stdout.strip() == 'active'


def _ensure_ospf_service() -> bool:
    """Install the OSPF service definition, returning True when it changed."""
    wanted = OSPF_SERVICE_XML
    try:
        if OSPF_SERVICE_PATH.read_text(encoding='utf-8') == wanted:
            return False
    except OSError:
        pass

    OSPF_SERVICE_PATH.parent.mkdir(parents=True, exist_ok=True)
    OSPF_SERVICE_PATH.write_text(wanted, encoding='utf-8')
    OSPF_SERVICE_PATH.chmod(0o644)
    return True


def _zone_of(interface: str) -> str:
    """Return the zone an interface belongs to, empty when it has none."""
    zone = _run(['firewall-cmd',
                 '--get-zone-of-interface=' + interface]).stdout.strip()
    return '' if zone in ('', 'no zone') else zone


def _read_firewall() -> list[str]:
    """Return the zones this app added the OSPF service to."""
    try:
        data = json.loads(OSPF_FIREWALL_PATH.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []

    zones = data.get('zones') if isinstance(data, dict) else None
    return [zone for zone in zones or [] if isinstance(zone, str) and zone]


def _write_firewall(zones: list[str]):
    """Remember which zones this app touched."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with OSPF_FIREWALL_PATH.open('w', encoding='utf-8') as handle:
        json.dump({'zones': zones}, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
    OSPF_FIREWALL_PATH.chmod(0o600)


def _apply_firewall(config: dict):
    """Let exactly the zones carrying OSPF interfaces accept protocol 89."""
    if not _firewalld_active():
        return

    changed = _ensure_ospf_service()
    if changed:
        # firewalld only reads /etc/firewalld/services at load time, so the
        # reload has to happen before --add-service can validate the name.
        _run(['firewall-cmd', '--reload'])

    wanted = set()
    if config['global'].get('enabled'):
        for item in config['interfaces']:
            if item.get('passive'):
                continue

            zone = _zone_of(item['interface'])
            if not zone:
                zone = _run(['firewall-cmd',
                             '--get-default-zone']).stdout.strip()
            if zone:
                wanted.add(zone)

    previous = set(_read_firewall())
    for zone in previous - wanted:
        _run(['firewall-cmd', '--permanent', '--zone=' + zone,
              '--remove-service=' + OSPF_SERVICE_NAME])
        changed = True

    # Ask firewalld itself rather than trusting our own bookkeeping: a previous
    # run may have recorded a zone whose --add-service never actually landed.
    for zone in wanted:
        if _run(['firewall-cmd', '--permanent', '--zone=' + zone,
                 '--query-service=' + OSPF_SERVICE_NAME]).returncode:
            _run(['firewall-cmd', '--permanent', '--zone=' + zone,
                  '--add-service=' + OSPF_SERVICE_NAME])
            changed = True

    _write_firewall(sorted(wanted))
    if changed:
        _run(['firewall-cmd', '--reload'])

    missing = [zone for zone in sorted(wanted)
               if _run(['firewall-cmd', '--permanent', '--zone=' + zone,
                        '--query-service=' + OSPF_SERVICE_NAME]).returncode]
    if missing:
        raise ValueError(
            '无法在防火墙区域 {} 中放通 OSPF（IP 协议 89），'
            '邻居将一直停在 Init 状态。请手工执行 '
            'firewall-cmd --permanent --zone={} --add-service={} 后重试。'
            .format('、'.join(missing), missing[0], OSPF_SERVICE_NAME))


def _apply_ospf(config: dict):
    """Write the fenced block into frr.conf and reload FRR.

    Raises ValueError with the daemon's own complaint when FRR refuses to come
    back, after putting the previous files in place.
    """
    fragment = ospf_config.build_fragment(config)

    try:
        previous_conf = FRR_CONF_PATH.read_text(encoding='utf-8')
    except OSError:
        previous_conf = ''

    try:
        previous_daemons = FRR_DAEMONS_PATH.read_text(encoding='utf-8')
    except OSError as exception:
        raise ValueError(
            '找不到 /etc/frr/daemons，FRR 似乎没有安装完整：{}'.format(
                exception)) from exception

    wanted_daemons = ospf_config.enable_daemon(
        previous_daemons, 'ospfd', config['global'].get('enabled', False))

    if fragment and not ospf_config.has_block(previous_conf) \
            and ospf_config.has_foreign_ospf(previous_conf):
        raise ValueError(
            'frr.conf 里已经有一份不是本模块写入的 OSPF 配置。'
            '为避免两份配置互相覆盖，请先手工清理 /etc/frr/frr.conf 中的 '
            'OSPF 相关段落再保存。')

    # Before the configuration lands: opening protocol 89 is harmless on its
    # own, while doing it afterwards would leave frr.conf rewritten even when
    # the firewall step failed.
    _apply_firewall(config)

    FRR_CONF_PATH.write_text(
        ospf_config.insert_block(previous_conf, fragment), encoding='utf-8')
    try:
        FRR_CONF_PATH.chmod(0o640)
        shutil.chown(str(FRR_CONF_PATH), user='frr', group='frr')
    except (OSError, LookupError):
        pass

    if wanted_daemons != previous_daemons:
        FRR_DAEMONS_PATH.write_text(wanted_daemons, encoding='utf-8')

    problem = ''
    if not _restart_frr():
        problem = 'FRR 服务没有启动'
    elif config['global'].get('enabled') and not _wait_for_ospfd():
        problem = 'FRR 已启动，但 ospfd 没有运行'

    if problem:
        FRR_CONF_PATH.write_text(previous_conf, encoding='utf-8')
        FRR_DAEMONS_PATH.write_text(previous_daemons, encoding='utf-8')
        recovered = _restart_frr()
        detail = _journal_tail()
        note = '' if recovered else (
            '\n回退之后 FRR 仍未能启动，请在命令行执行 '
            'systemctl reset-failed frr && systemctl start frr 恢复。')
        raise ValueError(
            '{}，配置已回退到修改前。FRR 的报错：\n{}{}'.format(
                problem, detail or '（日志为空）', note))


def _looks_like_ipv4(text) -> bool:
    """Return whether *text* can be parsed as an IPv4 address."""
    try:
        ipaddress.IPv4Address(str(text))
    except ValueError:
        return False

    return True


def _ospf_neighbors() -> list[dict]:
    """Return the live neighbour table as reported by FRR.

    FRR keys the neighbour list by the peer's router id and puts one entry per
    interface under it.  The field names moved between releases (``nbrPriority``
    versus ``priority``, ``ifaceAddress`` versus ``nbrAddress``), so both are
    accepted here rather than pinning the module to one FRR version.
    """
    if not _ospfd_running():
        return []

    process = _run(['vtysh', '-c', 'show ip ospf neighbor json'])
    if process.returncode != 0 or not process.stdout.strip():
        return []

    try:
        data = json.loads(process.stdout)
    except ValueError:
        return []

    found = []

    def walk(node, router_id=''):
        if isinstance(node, dict):
            if 'nbrState' in node:
                found.append((router_id, node))
                return
            for key, value in node.items():
                walk(value, key if _looks_like_ipv4(key) else router_id)
        elif isinstance(node, list):
            for value in node:
                walk(value, router_id)

    walk(data)

    neighbors = []
    for router_id, item in found:
        neighbors.append({
            'router_id': item.get('routerId') or router_id
            or item.get('nbrAddress') or '?',
            'address': item.get('nbrAddress') or item.get('ifaceAddress') or '?',
            'interface': (item.get('ifaceName') or '?').split(':')[0],
            'state': item.get('nbrState') or '?',
            'priority': item.get('priority', item.get('nbrPriority', '')),
            'uptime': _format_duration(item.get('upTimeInMsec'))
            or str(item.get('upTime') or ''),
            'dead_time': _format_duration(
                item.get('deadTimeMsecs')
                or item.get('routerDeadIntervalTimerDueMsec'))
            or str(item.get('deadTime') or ''),
        })

    neighbors.sort(key=lambda row: (row['interface'], row['address']))
    return neighbors


def _format_duration(milliseconds) -> str:
    """Render a millisecond count as hh:mm:ss."""
    try:
        total = int(milliseconds) // 1000
    except (TypeError, ValueError):
        return ''

    if total < 0:
        return ''
    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)
    return '{:02d}:{:02d}:{:02d}'.format(hours, minutes, seconds)


@privileged
def get_ospf() -> dict:
    """Return everything the OSPF page needs to render.

    Authentication keys are deliberately left out: they would end up in the
    HTML, in the browser cache and in any screenshot of the page.
    """
    config = read_ospf()
    interfaces = []
    for item in config['interfaces']:
        row = dict(item)
        row['has_key'] = bool(item.get('auth_key'))
        row.pop('auth_key', None)
        interfaces.append(row)

    return {
        'global': config['global'],
        'areas': config['areas'],
        'interfaces': interfaces,
        'neighbors': _ospf_neighbors(),
        'devices': _devices(),
        'frr_installed': FRR_DAEMONS_PATH.exists(),
        'frr_active': _frr_active(),
        'ospfd_running': _ospfd_running(),
    }


@privileged
def save_ospf_global(enabled: bool, router_id: str,
                     redistribute_connected: bool, redistribute_static: bool,
                     redistribute_kernel: bool, default_originate: str,
                     distance: int, log_adjacency: bool) -> dict:
    """Update the instance level settings and reload FRR."""
    config = read_ospf()
    config['global'] = ospf_config.normalize_global({
        'enabled': enabled,
        'router_id': router_id,
        'redistribute_connected': redistribute_connected,
        'redistribute_static': redistribute_static,
        'redistribute_kernel': redistribute_kernel,
        'default_originate': default_originate,
        'distance': distance,
        'log_adjacency': log_adjacency,
    })

    _apply_ospf(config)
    _write_ospf(config)
    return config['global']


@privileged
def add_ospf_area(area_id: str, area_type: str, no_summary: bool) -> dict:
    """Add one area."""
    config = read_ospf()
    area = ospf_config.normalize_area({
        'id': area_id,
        'type': area_type,
        'no_summary': no_summary,
    })

    if any(item['id'] == area['id'] for item in config['areas']):
        raise ValueError('区域 {} 已经存在'.format(area['id']))

    config['areas'].append(area)
    _apply_ospf(config)
    _write_ospf(config)
    return area


@privileged
def delete_ospf_area(area_id: str) -> dict:
    """Remove one area, refusing when interfaces still belong to it."""
    config = read_ospf()
    area = ospf_config.normalize_area_id(area_id)

    used = [item['interface'] for item in config['interfaces']
            if item['area'] == area]
    if used:
        raise ValueError(
            '区域 {} 里还有接口 {}，请先把这些接口从该区域移走'.format(
                area, '、'.join(used)))

    remaining = [item for item in config['areas'] if item['id'] != area]
    if len(remaining) == len(config['areas']):
        raise ValueError('区域 {} 不存在'.format(area))

    config['areas'] = remaining
    _apply_ospf(config)
    _write_ospf(config)
    return {'id': area}


@privileged
def add_ospf_interface(interface: str, area: str, network_type: str,
                       cost: int, priority: int, hello: int, dead: int,
                       passive: bool, auth: str, auth_key: str) -> dict:
    """Attach one interface to an area."""
    config = read_ospf()

    if any(item['interface'] == interface for item in config['interfaces']):
        raise ValueError(
            '接口 {} 已经配置过，请先删除原条目'.format(interface))

    entry = ospf_config.normalize_interface({
        'interface': interface,
        'area': area,
        'network_type': network_type,
        'cost': cost,
        'priority': priority,
        'hello': hello,
        'dead': dead,
        'passive': passive,
        'auth': auth,
        'auth_key': auth_key,
    }, [item['id'] for item in config['areas']], _devices())

    config['interfaces'].append(entry)
    _apply_ospf(config)
    _write_ospf(config)

    row = dict(entry)
    row.pop('auth_key', None)
    return row


@privileged
def delete_ospf_interface(interface: str) -> dict:
    """Detach one interface from OSPF."""
    config = read_ospf()
    remaining = [item for item in config['interfaces']
                 if item['interface'] != interface]
    if len(remaining) == len(config['interfaces']):
        raise ValueError('接口 {} 没有在 OSPF 中配置过'.format(interface))

    config['interfaces'] = remaining
    _apply_ospf(config)
    _write_ospf(config)
    return {'interface': interface}


@privileged
def uninstall_ospf():
    """Drop the fenced block and switch ospfd off again."""
    config = read_ospf()
    config['global']['enabled'] = False
    try:
        _apply_ospf(config)
    except ValueError:
        # FRR refusing to start without our block is not a reason to keep the
        # block around; the file has already been rolled back, so just remove
        # it by hand.
        try:
            FRR_CONF_PATH.write_text(
                ospf_config.strip_block(
                    FRR_CONF_PATH.read_text(encoding='utf-8')),
                encoding='utf-8')
        except OSError:
            pass

    try:
        OSPF_PATH.unlink()
    except OSError:
        pass
