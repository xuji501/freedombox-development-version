#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 部署包共用的日志、断言与状态判定函数。
# 由 deploy.sh / verify.sh / uninstall.sh 通过 source 引入。

# ---------------------------------------------------------------------------
# 颜色与日志
# ---------------------------------------------------------------------------
_C_RESET='\033[0m'
_C_INFO='\033[36m'
_C_OK='\033[32m'
_C_WARN='\033[33m'
_C_ERR='\033[31m'
_C_DIM='\033[2m'

LOG_FILE=${LOG_FILE:-/dev/null}

# 同时输出到终端（带颜色）和日志文件（纯文本）。
_emit() {
    local level=$1 color=$2
    shift 2
    printf '%s %s\n' "$level" "$*" >>"$LOG_FILE"
    if [ -t 1 ]; then
        printf "${color}%s${_C_RESET} %s\n" "$level" "$*"
    else
        printf '%s %s\n' "$level" "$*"
    fi
}

info() { _emit "[信息]" "$_C_INFO" "$*"; }
ok()   { _emit "[完成]" "$_C_OK" "$*"; }
warn() { _emit "[注意]" "$_C_WARN" "$*"; }
err()  { _emit "[错误]" "$_C_ERR" "$*"; }
step() { _emit "[步骤]" "$_C_DIM" "$*"; }

die() {
    err "$*"
    exit 1
}

hr() {
    local line='------------------------------------------------------------'
    printf '%s\n' "$line" >>"$LOG_FILE"
    [ -t 1 ] && printf "${_C_DIM}%s${_C_RESET}\n" "$line" || printf '%s\n' "$line"
}

banner() {
    local text=$1
    hr
    info "$text"
    hr
}

# ---------------------------------------------------------------------------
# 断言
# ---------------------------------------------------------------------------
require_root() {
    [ "$(id -u)" -eq 0 ] || die "必须以 root 权限运行：sudo bash $0"
}

have_cmd() {
    command -v "$1" >/dev/null 2>&1
}

require_cmd() {
    have_cmd "$1" || die "缺少命令 $1${2:+（$2）}"
}

# ---------------------------------------------------------------------------
# 步骤状态判定
# ---------------------------------------------------------------------------
PLINTH_LIB=/usr/lib/python3/dist-packages/plinth
ENABLED_DIR=/etc/freedombox/modules-enabled

# 返回 0 表示该步骤已经部署过。
step_installed() {
    case "$1" in
        base)
            # 本步骤的目标状态就是「freedombox 已安装」，用 dpkg 判断最可靠。
            dpkg -s freedombox >/dev/null 2>&1
            ;;
        firstboot)
            [ -f /etc/freedombox-custom/firstboot-done ]
            ;;
        dhcp)
            [ -f "$ENABLED_DIR/dhcp" ] && [ -f "$PLINTH_LIB/modules/dhcp/views.py" ]
            ;;
        ipv6)
            [ -f "$ENABLED_DIR/ipv6" ] && [ -f "$PLINTH_LIB/modules/ipv6/views.py" ]
            ;;
        routes)
            [ -f "$ENABLED_DIR/routes" ] && [ -f "$PLINTH_LIB/modules/routes/views.py" ]
            ;;
        gre)
            [ -f "$ENABLED_DIR/gre" ] && [ -f "$PLINTH_LIB/modules/gre/views.py" ]
            ;;
        openvpn)
            [ -x /usr/lib/freedombox-openvpn/ovpn-auth.py ] \
                && [ -f /etc/openvpn/freedombox-auth/users.json ]
            ;;
        branding)
            grep -q 'plinth-branding:start' \
                "$PLINTH_LIB/templates/base.html" 2>/dev/null
            ;;
        fixes)
            grep -q 'plinth-fix-404:start' "$PLINTH_LIB/views.py" 2>/dev/null
            ;;
        *)
            return 1
            ;;
    esac
}

# ---------------------------------------------------------------------------
# 全局快照（与各子安装器的自有备份相互独立，作为最后一道保险）
# ---------------------------------------------------------------------------
GLOBAL_BACKUP_ROOT=/var/backups/freedombox-custom

global_snapshot() {
    local stamp=$1
    local dir="$GLOBAL_BACKUP_ROOT/$stamp"
    mkdir -p "$dir"

    local -a files=(
        "$PLINTH_LIB/templates/base.html"
        "$PLINTH_LIB/views.py"
    )
    local -a dirs=(
        "$PLINTH_LIB/modules/openvpn"
        "$ENABLED_DIR"
        /etc/freedombox-custom
        /etc/freedombox-dhcp
        /etc/freedombox-ipv6
        /etc/freedombox-routes
        /etc/freedombox-gre
        /usr/lib/freedombox-dhcp
        /usr/lib/freedombox-ipv6
        /usr/lib/freedombox-routes
        /usr/lib/freedombox-gre
        /usr/lib/freedombox-openvpn
        /etc/openvpn/freedombox-auth
        /etc/frr
        /etc/firewalld
    )

    local path
    for path in "${files[@]}"; do
        [ -f "$path" ] && cp -a "$path" "$dir/" 2>/dev/null
    done
    for path in "${dirs[@]}"; do
        if [ -e "$path" ]; then
            local name
            name=$(echo "$path" | sed 's#^/#__#; s#/#_#g')
            cp -a "$path" "$dir/$name" 2>/dev/null
        fi
    done
    # systemd 单元与 sysctl 也留一份，便于人工比对。
    mkdir -p "$dir/systemd" "$dir/sysctl"
    cp -a /etc/systemd/system/freedombox-*.service "$dir/systemd/" 2>/dev/null
    cp -a /etc/sysctl.d/99-freedombox-*.conf "$dir/sysctl/" 2>/dev/null

    echo "$dir"
}

latest_backup() {
    local root=$1
    [ -d "$root" ] || return 1
    ls -1d "$root"/*/ 2>/dev/null | sort | tail -1 | sed 's#/$##'
}
