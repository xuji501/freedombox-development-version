"""应用 deploy.conf 里那些「会改动网络」的附加配置。

deploy.sh 在装完模块之后调用本脚本。默认情况下模块只装不启用——启用 DHCP
会把内网网卡切成静态地址、启用 IPv6 内网会打开转发与路由通告，两者都会改变
机器在网络里的行为，必须由部署者显式要求才会执行。

用法（必须以 root 运行，且工作目录在 /usr/lib/python3/dist-packages）：

    python3 postconfig.py --dhcp-enable
    python3 postconfig.py --ipv6-prefix fd12:3456:7890::/64
    python3 postconfig.py --ipv6-enable-lan
"""

import argparse
import ipaddress
import sys

from plinth import web_framework

web_framework.init()


def dhcp_enable() -> int:
    """把 DHCP 设置里的 enabled 打开并应用。"""
    from plinth.modules.dhcp import privileged

    previous = privileged.read_settings()
    settings = dict(previous)

    if not settings.get('interface'):
        detected = privileged._detect_defaults()
        print('自动探测到的网络参数：', detected)
        for key, value in detected.items():
            settings.setdefault(key, value)
            if not settings.get(key):
                settings[key] = value

    if not settings.get('interface'):
        print('未能确定内网网卡，请在 DHCP 页面上手动选择', file=sys.stderr)
        return 1

    settings['enabled'] = True
    privileged._write_settings(settings)
    print('正在应用 DHCP 配置（网卡 {}）...'.format(settings['interface']))
    privileged._apply(settings, previous)
    print('DHCP 已启用：网卡 {}，地址池 {} - {}'.format(
        settings['interface'], settings.get('range_start'),
        settings.get('range_end')))
    return 0


def ipv6_set_prefix(prefix: str) -> int:
    """替换内网 ULA 前缀并重新生成 RA / NAT66 / sysctl 文件。"""
    from plinth.modules.ipv6 import privileged

    try:
        network = ipaddress.IPv6Network(prefix, strict=False)
    except ValueError:
        print('前缀格式不合法：{}'.format(prefix), file=sys.stderr)
        return 1

    if network.prefixlen != 64:
        print('内网前缀必须是 /64，收到 /{}'.format(network.prefixlen),
              file=sys.stderr)
        return 1

    previous = privileged.read_settings()
    settings = dict(previous)
    settings['prefix'] = str(network)
    privileged._write_settings(settings)
    privileged._write_generated_files(settings)
    print('IPv6 内网前缀已设为', settings['prefix'])
    return 0


def ipv6_enable_lan() -> int:
    """打开内网 IPv6：转发、路由通告、NAT66。"""
    from plinth.modules.ipv6 import privileged

    previous = privileged.read_settings()
    settings = dict(previous)
    settings['lan_enabled'] = True
    privileged._write_settings(settings)
    privileged._write_generated_files(settings)
    print('正在应用 IPv6 内网配置...')
    privileged._apply(settings, previous)
    print('IPv6 内网已启用：前缀 {}，内网网卡 {}'.format(
        settings.get('prefix'), settings.get('lan_device')))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dhcp-enable', action='store_true',
                        help='启用 DHCP 服务')
    parser.add_argument('--ipv6-prefix', default='',
                        help='设置 IPv6 内网 ULA 前缀（/64）')
    parser.add_argument('--ipv6-enable-lan', action='store_true',
                        help='启用 IPv6 内网路由通告与 NAT66')
    args = parser.parse_args()

    if args.ipv6_prefix:
        if ipv6_set_prefix(args.ipv6_prefix):
            return 1

    if args.ipv6_enable_lan:
        if ipv6_enable_lan():
            return 1

    if args.dhcp_enable:
        if dhcp_enable():
            return 1

    return 0


if __name__ == '__main__':
    sys.exit(main())
