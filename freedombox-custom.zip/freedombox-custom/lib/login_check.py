"""用部署时生成的管理员账号真实登录一次 Plinth。

verify.sh 用它证明「装完即可登录」不是一句空话：不只是登录页能打开，而是
账号密码确实能通过 LDAP 认证，并且能进入需要登录才能看的页面。

只依赖标准库。这里刻意不用 http.cookiejar，而是自己从 Set-Cookie 里取
name=value 再塞进请求头——Plinth 下发的 csrftoken 带 SameSite=Lax，
cookiejar 在这条链路上会把它丢掉，POST 时服务端就报「CSRF cookie not set」。

退出码：
    0  登录成功且能访问受保护页面
    1  登录失败（取不到 token、凭据被拒、或受保护页面仍跳登录页）

用法（root）：
    python3 lib/login_check.py [https://127.0.0.1/plinth]
"""

import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

DEFAULT_BASE = 'https://127.0.0.1/plinth'
CREDENTIALS = '/root/freedombox-admin-password.txt'

REDIRECT_CODES = (301, 302, 303, 307, 308)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """不让 urllib 自动跟随 302。

    登录成功与否就看那一跳：成功是 302 到首页，密码错则停在登录页返回 200。
    自动跟随会把这两种情况都变成 200，反而判断不了。
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def build_opener():
    """返回一个忽略自签证书、不自动跟随重定向的 opener。"""
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return urllib.request.build_opener(
        urllib.request.HTTPSHandler(context=context), _NoRedirect())


def read_credentials():
    """从部署时写下的凭据文件里读用户名与密码。"""
    username = password = ''
    with open(CREDENTIALS, encoding='utf-8') as handle:
        for line in handle:
            line = line.strip()
            if line.startswith('username='):
                username = line.split('=', 1)[1]
            elif line.startswith('password='):
                password = line.split('=', 1)[1]
    return username, password


def parse_cookies(headers):
    """把响应头里的 Set-Cookie 收成 name -> value 的字典。"""
    cookies = {}
    for header in headers.get_all('Set-Cookie') or []:
        pair = header.split(';', 1)[0].strip()
        if '=' in pair:
            name, value = pair.split('=', 1)
            cookies[name.strip()] = value.strip()
    return cookies


def cookie_header(cookies):
    """把 cookie 字典拼成请求头用的字符串。"""
    return '; '.join('{}={}'.format(name, value)
                     for name, value in cookies.items())


def fetch_login_form(opener, login_url, attempts=10, delay=3):
    """反复取登录页，直到拿到 CSRF token。

    部署刚结束时 apache 与 plinth 可能还在启动，第一次请求经常拿到 503
    或者 Plinth 的「正在初始化」页。此时直接判定登录失败是误报，所以要重试。

    返回 (token, cookies, 说明)。
    """
    reason = ''
    for index in range(attempts):
        if index:
            time.sleep(delay)

        try:
            response = opener.open(login_url, timeout=20)
            html = response.read().decode('utf-8', 'replace')
            cookies = parse_cookies(response.headers)
        except urllib.error.HTTPError as error:
            reason = 'HTTP {}'.format(error.code)
            continue
        except Exception as error:  # pylint: disable=broad-except
            reason = str(error)
            continue

        match = re.search(r'name="csrfmiddlewaretoken"\s+value="([^"]+)"',
                          html)
        if match:
            return match.group(1), cookies, ''

        snippet = re.sub(r'\s+', ' ', html).strip()[:160]
        reason = '页面里没有 csrfmiddlewaretoken（{} 字节）：{}'.format(
            len(html), snippet)

    return '', {}, reason


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_BASE
    base = base.rstrip('/')

    try:
        username, password = read_credentials()
    except OSError as error:
        print('读取凭据文件失败：{}'.format(error))
        return 1

    if not username or not password:
        print('凭据文件里没有用户名或密码：{}'.format(CREDENTIALS))
        return 1

    login_url = base + '/accounts/login/'
    opener = build_opener()

    token, cookies, reason = fetch_login_form(opener, login_url)
    if not token:
        print('取不到登录表单的 CSRF token：{}'.format(reason))
        return 1

    payload = urllib.parse.urlencode({
        'username': username,
        'password': password,
        'csrfmiddlewaretoken': token,
    }).encode()
    request = urllib.request.Request(
        login_url, data=payload,
        headers={'Cookie': cookie_header(cookies), 'Referer': login_url})

    # 登录成功时 Django 返回 302 跳首页；密码错则 200 停在登录页。
    try:
        response = opener.open(request, timeout=20)
        print('登录失败：仍停留在登录页（HTTP {}），账号 {} 的密码可能不对'
              .format(response.status, username))
        return 1
    except urllib.error.HTTPError as error:
        if error.code not in REDIRECT_CODES:
            detail = ''
            try:
                detail = re.sub(
                    r'\s+', ' ',
                    error.read().decode('utf-8', 'replace'))[:240]
            except Exception:  # pylint: disable=broad-except
                pass
            print('登录请求被拒：HTTP {} {}'.format(error.code, detail))
            return 1

        location = error.headers.get('Location', '')
        cookies.update(parse_cookies(error.headers))

    print('账号 {} 登录成功（跳转到 {}）'.format(username, location or '首页'))

    # 再用会话 cookie 访问一个必须登录才能看的页面，确认会话真的生效。
    request = urllib.request.Request(base + '/sys/',
                                     headers={'Cookie': cookie_header(cookies)})
    try:
        response = opener.open(request, timeout=20)
        body = response.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as error:
        if error.code in REDIRECT_CODES:
            print('会话未生效：访问 /sys/ 被重定向到 {}'.format(
                error.headers.get('Location', '')))
            return 1
        print('访问 /sys/ 失败：HTTP {}'.format(error.code))
        return 1

    title = re.search(r'<title>([^<]*)</title>', body)
    print('/sys/ 可访问：{}'.format(
        re.sub(r'\s+', ' ', title.group(1)).strip() if title else 'HTTP 200'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
