#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 为 FreedomBox 的 OpenVPN 模块增加账号管理（用户名/密码）与服务器设置。
#
# 用法：sudo bash install.sh
#
# 安装内容：
#   /usr/lib/python3/dist-packages/plinth/modules/openvpn/  模块代码
#   /usr/lib/freedombox-openvpn/ovpn-auth.py               独立的凭据校验脚本
#   /etc/openvpn/freedombox-auth/users.json                独立账号库（0600）
#
# 两种部署场景，脚本自动判定：
#   upgrade —— 机器上已有 /etc/openvpn/server/freedombox.conf（官方 OpenVPN
#              已配置过）。只做增量改造，绝不重新生成证书与防火墙。
#   fresh   —— 全新机器，官方 OpenVPN 从未启用。此时需要完成一次完整初始化
#              （生成 CA/服务端证书、写服务端配置、放行防火墙），否则
#              openvpn-server@freedombox 起不来。
#
# 可用环境变量（不设置则用下面的默认值）：
#   FBX_OVPN_PORT       服务端端口，默认沿用现有配置，否则 1194
#   FBX_OVPN_AUTH_MODE  cert 或 cert+pw；全新部署默认 cert+pw，升级默认沿用 cert
#
# 任何一步失败都会自动回滚到安装前的状态。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/openvpn
AUTH_SCRIPT_DIR=/usr/lib/freedombox-openvpn
AUTH_STORE_DIR=/etc/openvpn/freedombox-auth
OPENVPN_CONFIG=/etc/openvpn/server/freedombox.conf
OPENVPN_SETTINGS=/etc/openvpn/server/freedombox-settings.json
BACKUP_ROOT=/root/freedombox-openvpn-users-backup
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
SOURCE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
DESIRED_PORT="${FBX_OVPN_PORT:-}"
DESIRED_AUTH_MODE="${FBX_OVPN_AUTH_MODE:-}"

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

rollback() {
    echo "正在回滚..." >&2

    if [ -d "$BACKUP_DIR/module" ]; then
        rm -rf "$MODULE_DIR"
        cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
        echo "已恢复原有模块目录" >&2
    fi

    if [ -f "$BACKUP_DIR/freedombox.conf" ]; then
        cp -a "$BACKUP_DIR/freedombox.conf" "$OPENVPN_CONFIG"
        echo "已恢复 OpenVPN 服务端配置" >&2
    else
        # fresh 场景下这个文件是本次新建的，回滚时应当移除。
        rm -f "$OPENVPN_CONFIG"
    fi

    if [ -f "$BACKUP_DIR/freedombox-settings.json" ]; then
        cp -a "$BACKUP_DIR/freedombox-settings.json" "$OPENVPN_SETTINGS"
    else
        rm -f "$OPENVPN_SETTINGS"
    fi

    # 独立账号库与校验脚本是本次新增的。账号库若在安装前就存在（重装场景），
    # 说明里面已经有用户创建的账号，必须原样还原而不是删掉。
    if [ -d "$BACKUP_DIR/auth-store" ]; then
        rm -rf "$AUTH_STORE_DIR"
        cp -a "$BACKUP_DIR/auth-store" "$AUTH_STORE_DIR"
        echo "已恢复原有账号库" >&2
    else
        rm -rf "$AUTH_STORE_DIR"
    fi

    rm -rf "$AUTH_SCRIPT_DIR"

    systemctl restart plinth 2>/dev/null || true
    systemctl try-restart openvpn-server@freedombox 2>/dev/null || true
    echo "回滚完成" >&2
}

echo "=============================================="
echo " FreedomBox OpenVPN 账号管理模块安装"
echo "=============================================="

echo ""
echo "== 1/9 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
[ -f "$SOURCE_DIR/files/privileged.py" ] || fail "在 $SOURCE_DIR/files 下找不到模块源文件"
dpkg -s freedombox >/dev/null 2>&1 || fail "未检测到 freedombox 软件包"
echo "freedombox 版本：$(dpkg-query -W -f='${Version}' freedombox)"
[ -x /usr/sbin/openvpn ] || fail "未找到 /usr/sbin/openvpn，请先安装 openvpn 软件包"
echo "openvpn：$(openvpn --version 2>/dev/null | head -1)"

if [ -f "$OPENVPN_CONFIG" ]; then
    DEPLOY_MODE=upgrade
else
    DEPLOY_MODE=fresh
fi

if [ "$DEPLOY_MODE" = fresh ]; then
    echo "部署场景：fresh（本机尚未配置过 FreedomBox 的 OpenVPN）"
    [ -x /usr/share/easy-rsa/easyrsa ] \
        || fail "未找到 /usr/share/easy-rsa/easyrsa，请先安装 easy-rsa 软件包"
    echo "easy-rsa：已就绪"
else
    echo "部署场景：upgrade（检测到现有 $OPENVPN_CONFIG）"
fi
systemctl list-unit-files 'openvpn-server@.service' >/dev/null 2>&1 \
    || fail "未找到 openvpn-server@.service"

echo ""
echo "== 2/9 备份现有状态 =="
mkdir -p "$BACKUP_DIR"
if [ -d "$MODULE_DIR" ]; then
    cp -a "$MODULE_DIR" "$BACKUP_DIR/module"
    echo "已备份现有模块目录"
fi
if [ -f "$OPENVPN_CONFIG" ]; then
    cp -a "$OPENVPN_CONFIG" "$BACKUP_DIR/freedombox.conf"
    echo "已备份服务端配置"
fi
[ -f "$OPENVPN_SETTINGS" ] && \
    cp -a "$OPENVPN_SETTINGS" "$BACKUP_DIR/freedombox-settings.json"
if [ -f /etc/openvpn/auth/users.json ]; then
    cp -a /etc/openvpn/auth/users.json "$BACKUP_DIR/legacy-users.json"
    echo "已备份 RouteWeb 账号库（仅用于迁移参考）"
fi
if [ -d "$AUTH_STORE_DIR" ]; then
    cp -a "$AUTH_STORE_DIR" "$BACKUP_DIR/auth-store"
    echo "已备份现有 FreedomBox 账号库（重装时保留已创建的账号）"
fi
echo "备份目录：$BACKUP_DIR"

echo ""
echo "== 3/9 部署模块文件 =="
mkdir -p "$MODULE_DIR/templates"
install -m 644 "$SOURCE_DIR/files/privileged.py" \
    "$MODULE_DIR/privileged.py" || fail "复制 privileged.py 失败"
install -m 644 "$SOURCE_DIR/files/forms.py" \
    "$MODULE_DIR/forms.py" || fail "复制 forms.py 失败"
install -m 644 "$SOURCE_DIR/files/views.py" \
    "$MODULE_DIR/views.py" || fail "复制 views.py 失败"
install -m 644 "$SOURCE_DIR/files/urls.py" \
    "$MODULE_DIR/urls.py" || fail "复制 urls.py 失败"
install -m 644 "$SOURCE_DIR/files/templates/openvpn.html" \
    "$MODULE_DIR/templates/openvpn.html" || fail "复制模板失败"
# __init__.py 携带 _version = 6。它决定 Plinth 是否重跑 setup，全新机器上
# 必须一并部署，否则模块版本停留在官方值，账号功能不会被初始化。
install -m 644 "$SOURCE_DIR/files/__init__.py" \
    "$MODULE_DIR/__init__.py" || fail "复制 __init__.py 失败"
rm -rf "$MODULE_DIR/__pycache__"
chown -R root:root "$MODULE_DIR"
echo "已部署到 $MODULE_DIR"

echo ""
echo "== 4/9 语法检查 =="
for file in "$MODULE_DIR"/*.py; do
    if ! python3 -m py_compile "$file"; then
        rollback
        fail "语法错误：$file"
    fi
done
echo "全部 Python 文件语法正确"

echo ""
echo "== 5/9 导入与表单检查 =="
CHECK_SCRIPT=$(mktemp /tmp/ovpn-check-XXXXXX.py)
cat > "$CHECK_SCRIPT" <<'PYEOF'
# web_framework.init() configures Django itself, so django.setup() must not
# be called beforehand.
from plinth import web_framework

web_framework.init()

from plinth.modules.openvpn import forms, privileged, views  # noqa: E402

assert views.OpenVPNAppView.app_id == 'openvpn'
assert views.OpenVPNAppView.form_class is forms.OpenVPNSettingsForm

form = forms.OpenVPNSettingsForm()
for field in ('port', 'auth_mode'):
    assert field in form.fields, f'缺少表单字段 {field}'

for name in ('VPNUserAddForm', 'VPNUserPasswordForm'):
    assert hasattr(forms, name), f'缺少表单 {name}'

for action in ('get_users', 'add_user', 'set_user_password',
               'set_user_disabled', 'delete_user', 'get_account_profile'):
    assert callable(getattr(privileged, action)), f'缺少动作 {action}'

assert privileged.AUTH_SCRIPT_PATH == '/usr/lib/freedombox-openvpn/ovpn-auth.py'

from django.template.loader import get_template  # noqa: E402
template = get_template('openvpn.html')
print('模板来源：', template.origin.name)
print('模块导入、表单字段与模板加载全部正常')
PYEOF

if ! python3 "$CHECK_SCRIPT"; then
    rm -f "$CHECK_SCRIPT"
    rollback
    fail "导入检查未通过，已回滚"
fi
rm -f "$CHECK_SCRIPT"

echo ""
echo "== 6/9 初始化设置文件 =="
# 认证方式的兜底默认值随部署场景不同：
#   fresh   —— 本模块存在的意义就是账号管理，纯证书模式下账号功能形同虚设，
#              所以全新机器默认 cert+pw（与现网一致）。
#   upgrade —— 机器上已有服务端配置，默认不去改变它原有的认证行为。
if [ "$DEPLOY_MODE" = fresh ]; then
    DEFAULT_AUTH_MODE=cert+pw
else
    DEFAULT_AUTH_MODE=cert
fi

if [ -f "$OPENVPN_SETTINGS" ]; then
    echo "  $OPENVPN_SETTINGS 已存在，保留现有设置："
    cat "$OPENVPN_SETTINGS"
else
    # 端口优先用调用方指定的值；没指定就沿用现有服务端配置，最后才用 1194。
    CUR_PORT="$(awk '/^port /{print $2; exit}' "$OPENVPN_CONFIG" 2>/dev/null || true)"
    CUR_PORT="${DESIRED_PORT:-${CUR_PORT:-1194}}"
    AUTH_MODE="${DESIRED_AUTH_MODE:-$DEFAULT_AUTH_MODE}"
    case "$AUTH_MODE" in
        cert|cert+pw) ;;
        *) fail "FBX_OVPN_AUTH_MODE 只能是 cert 或 cert+pw，收到：$AUTH_MODE" ;;
    esac
    mkdir -p "$(dirname "$OPENVPN_SETTINGS")"
    cat > "$OPENVPN_SETTINGS" <<JSON
{
  "port": ${CUR_PORT},
  "auth_mode": "${AUTH_MODE}",
  "auth_script": "/usr/lib/freedombox-openvpn/ovpn-auth.py"
}
JSON
    chmod 644 "$OPENVPN_SETTINGS"
    echo "  已创建 $OPENVPN_SETTINGS（端口 ${CUR_PORT}，认证方式 ${AUTH_MODE}）"
fi

echo ""
echo "== 7/9 应用改造 =="
if [ "$DEPLOY_MODE" = fresh ]; then
    # 全新机器：需要生成 CA 与服务端证书、写服务端配置、放行防火墙。
    # 这一步等价于官方「安装 OpenVPN 应用」，只是换成了带账号管理的版本。
    echo "  执行完整初始化（生成证书、服务端配置与防火墙规则）..."
    (cd /usr/lib/python3/dist-packages && \
        timeout 300 python3 "$SOURCE_DIR/bootstrap.py")
    INIT_RC=$?
else
    # 已有配置：只做增量改造，不碰证书与防火墙。
    echo "  执行增量改造（账号库、校验脚本、服务端配置）..."
    (cd /usr/lib/python3/dist-packages && \
        timeout 120 python3 "$SOURCE_DIR/init_once.py")
    INIT_RC=$?
fi

if [ "$INIT_RC" -ne 0 ]; then
    rollback
    fail "初始化失败（退出码 $INIT_RC），已回滚"
fi

echo ""
echo "== 8/9 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if ! systemctl is-active --quiet plinth; then
    rollback
    fail "Plinth 未能启动，已回滚"
fi
echo "Plinth 运行正常"

echo ""
echo "== 9/9 验证 =="
[ -x /usr/lib/freedombox-openvpn/ovpn-auth.py ] || { rollback; fail "校验脚本未安装"; }
[ -f "$AUTH_STORE_DIR/users.json" ] || { rollback; fail "账号库未生成"; }

# 服务端配置里有没有 auth-user-pass-verify 行，完全由 settings 的 auth_mode
# 决定。这里按实际生效的模式去核对，而不是无条件要求该行存在——否则纯证书
# 部署会被误判成失败。
EFFECTIVE_AUTH_MODE=$(python3 - <<'PYEOF'
import json
try:
    with open('/etc/openvpn/server/freedombox-settings.json') as fh:
        print(json.load(fh).get('auth_mode', 'cert'))
except Exception:
    print('cert')
PYEOF
)
if [ "$EFFECTIVE_AUTH_MODE" = "cert+pw" ]; then
    grep -q 'auth-user-pass-verify /usr/lib/freedombox-openvpn/ovpn-auth.py' \
        "$OPENVPN_CONFIG" \
        || { rollback; fail "认证方式为 cert+pw，但服务端配置未指向新的校验脚本"; }
    echo "认证方式：cert+pw（已挂载用户名密码校验）"
else
    if grep -q 'auth-user-pass-verify' "$OPENVPN_CONFIG"; then
        rollback
        fail "认证方式为 cert，但服务端配置里仍残留 auth-user-pass-verify"
    fi
    echo "认证方式：cert（纯证书，未启用密码校验）"
fi

echo "校验脚本：$(ls -l /usr/lib/freedombox-openvpn/ovpn-auth.py | awk '{print $1, $3, $4}')"
echo "账号库权限：$(ls -l "$AUTH_STORE_DIR/users.json" | awk '{print $1, $3, $4}')"

# 用不存在的账号调用一次，必须返回非 0 而不是崩溃。
PROBE=$(mktemp /tmp/ovpn-probe-XXXXXX.txt)
printf 'definitely-not-a-user\nwhatever\n' > "$PROBE"
if /usr/lib/freedombox-openvpn/ovpn-auth.py "$PROBE"; then
    rm -f "$PROBE"
    rollback
    fail "校验脚本对不存在的账号返回了成功，行为异常"
fi
rm -f "$PROBE"
echo "校验脚本对未知账号正确返回拒绝"

if ! systemctl is-active --quiet openvpn-server@freedombox; then
    rollback
    fail "openvpn-server@freedombox 未能启动，已回滚"
fi

sleep 2
PORT=$(python3 - <<'PYEOF'
import json
try:
    with open('/etc/openvpn/server/freedombox-settings.json') as fh:
        print(json.load(fh).get('port', 1194))
except Exception:
    print(1194)
PYEOF
)
echo "OpenVPN 服务状态：$(systemctl is-active openvpn-server@freedombox)"
echo "监听端口：$(ss -lunp 2>/dev/null | grep -c ":$PORT " ) 个 UDP 套接字（端口 $PORT）"

echo ""
echo "== 安装结果 =="
echo "账号列表："
python3 - <<'PYEOF'
import json
with open('/etc/openvpn/freedombox-auth/users.json') as fh:
    data = json.load(fh)
if not data.get('users'):
    print('  （空）')
for user in data.get('users', []):
    state = '已禁用' if user.get('disabled') else '启用'
    print('  {:<20s} {}'.format(user.get('user', '?'), state))
PYEOF

echo ""
echo "访问 https://<本机地址>/plinth/apps/openvpn/ 管理账号。"
echo "回滚命令：sudo bash $SOURCE_DIR/rollback.sh $BACKUP_DIR"
echo "=============================================="
