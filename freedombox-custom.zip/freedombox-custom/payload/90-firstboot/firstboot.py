"""把 FreedomBox 首次启动向导一次性走完。

正常流程里，用户在浏览器里要过三步：
    1. 输入控制台打印的 wizard secret
    2. 建第一个管理员账号
    3. 选择是否启用 backports

这个脚本把三步全部做完，让机器装完就能直接用网页登录。

做法刻意贴着 Plinth 自己的实现走（见 plinth/modules/users/forms.py 的
FirstBootForm.save）：Django 用户 + LDAP/Linux 账号 + admin 组，两边都要建，
少一边就会出现「能登录但没权限」或「有 Linux 账号却登不进网页」。

必须以 root 运行，且工作目录在 /usr/lib/python3/dist-packages。
"""

import os
import sys

# 与 lib/postconfig.py 一致：用 Plinth 自己的引导流程初始化 Django。
# 直接 django.setup() 会漏掉 settings 的动态改写（数据库路径、INSTALLED_APPS 等）。
from plinth import web_framework

web_framework.init()

# web_framework.init() 之后才能安全 import 这些
from django.contrib.auth import models as auth_models  # noqa: E402

from plinth.modules import first_boot  # noqa: E402
from plinth.modules.users import privileged  # noqa: E402

# 已知的三个向导步骤。_get_steps() 在脚本环境里可能拿不到完整列表
# （它依赖 apps_post_init 收集各应用的 first_boot_steps），所以这里兜底。
KNOWN_STEPS = ('firstboot_welcome', 'users_firstboot', 'backports_wizard')


def _admin_users():
    """返回当前已在 admin 组的用户列表。"""
    try:
        return privileged.get_group_users('admin') or []
    except Exception:  # pylint: disable=broad-except
        return []


def ensure_ldap_ready():
    """确保 ldapscripts 配置、LDAP 目录结构与 nslcd 认证方式就绪。

    ``plinth --setup-no-install`` 是按应用顺序跑 setup 的，任何一个应用抛
    异常都会中断整轮。受限环境（容器、没有 netfilter 权限的机器）里
    firewall 应用经常失败，而 users 应用排在它后面，于是 ``ou=users``
    从未被创建，建账号时报 ``No such object (32)``。

    nslcd 也要一并补：preseed 阶段只把认证方式设成 none（匿名绑定），而
    匿名读不到 userPassword，网页登录会失败。这里改成 SASL EXTERNAL，
    与 FreedomBox 自己的做法一致。

    三个函数都是幂等的，重复调用没有副作用。
    """
    ready = True
    steps = (
        ('ldapscripts 配置', privileged._configure_ldapscripts),  # noqa: SLF001
        ('LDAP 目录结构', privileged._configure_ldap_structure),  # noqa: SLF001
        ('nslcd 认证方式', privileged._configure_ldap_authentication),  # noqa: SLF001
    )
    for name, func in steps:
        try:
            func()
            print('{}：就绪'.format(name))
        except Exception as error:  # pylint: disable=broad-except
            ready = False
            print('{}：失败（{}）'.format(name, error), file=sys.stderr)
    return ready


def create_admin(username, password):
    """建管理员：Django 用户 + LDAP 账号 + admin 组，缺一不可。"""
    existing = _admin_users()
    if existing:
        print('已存在管理员账号：{}，跳过创建'.format(', '.join(existing)))
        username = existing[0]
        return username

    user = auth_models.User.objects.filter(username=username).first()
    if user is None:
        user = auth_models.User.objects.create_user(username=username,
                                                    password=password)
        print('已创建 Django 用户：{}'.format(username))
    else:
        user.set_password(password)
        user.save()
        print('Django 用户已存在，已重置密码：{}'.format(username))

    # LDAP + Linux 账号。失败不直接退出：先看 admin 组里到底有没有人，
    # 没有才认定失败，避免把「已存在」这类正常情况当成错误。
    try:
        privileged.create_user(username, password)
        print('已创建 LDAP/Linux 账号：{}'.format(username))
    except Exception as error:  # pylint: disable=broad-except
        print('创建 LDAP 账号返回：{}'.format(error), file=sys.stderr)

    try:
        privileged.add_user_to_group(username, 'admin')
        print('已加入 admin 组')
    except Exception as error:  # pylint: disable=broad-except
        print('加入 admin 组返回：{}'.format(error), file=sys.stderr)

    # Django 侧的组是 LDAP 组的镜像，权限判断读的是这一份。
    group, _ = auth_models.Group.objects.get_or_create(name='admin')
    group.user_set.add(user)

    if username not in _admin_users():
        print('管理员账号创建后仍未出现在 admin 组，请检查 LDAP 是否就绪',
              file=sys.stderr)
        return None

    return username


def mark_wizard_done():
    """把向导的所有步骤标记为已完成。"""
    step_ids = list(KNOWN_STEPS)
    try:
        for step in first_boot._get_steps():  # pylint: disable=protected-access
            step_id = step.get('id')
            if step_id and step_id not in step_ids:
                step_ids.append(step_id)
    except Exception:  # pylint: disable=broad-except
        pass

    for step_id in step_ids:
        try:
            first_boot.mark_step_done(step_id)
            print('已标记向导步骤完成：{}'.format(step_id))
        except Exception as error:  # pylint: disable=broad-except
            print('标记 {} 失败：{}'.format(step_id, error), file=sys.stderr)

    # mark_step_done 在「没有剩余步骤」时会自己调 set_completed，
    # 但 _get_steps() 为空时不会触发，这里显式补一次。
    first_boot.set_completed()
    print('向导已标记为完成')


def main():
    username = os.environ.get('ADMIN_USER', 'admin')
    password = os.environ.get('ADMIN_PASSWORD', '')
    if not password:
        print('缺少 ADMIN_PASSWORD 环境变量', file=sys.stderr)
        return 2

    # 建账号依赖 LDAP 里的 ou=users，先确保结构在，再谈建人。
    ensure_ldap_ready()

    created = create_admin(username, password)
    if not created:
        return 1

    mark_wizard_done()
    print('完成：管理员 {}'.format(created))
    return 0


if __name__ == '__main__':
    sys.exit(main())
