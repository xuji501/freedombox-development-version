"""补跑因前一个应用失败而被截断的应用 setup。

``plinth --setup-no-install`` 是按应用顺序串行跑的，任何一个应用抛异常都会
中断整轮，排在它后面的应用全部停留在旧版本。受限环境（容器、没有 netfilter
权限的机器）里 firewall 应用经常失败，而 dhcp、ipv6、users 恰好都排在它
后面——它们正是本定制包依赖的应用：DHCP/IPv6 的服务单元由各自应用的
setup 创建，LDAP 目录结构与 nslcd 认证方式由 users 的 setup 建立。

这里改成按应用逐个补跑，每个应用单独 try/except，一个失败不影响其余。
已完成的应用会因为 ``needs_setup()`` 为假而直接跳过，所以重复调用没有副作用。

注意这里**不过滤 essential**：本包的 dhcp / ipv6 / routes / gre 是自定义
模块，没有 essential 标记，但只有它们的 setup 才会写 systemd 服务单元。

无论补跑结果如何都返回 0：部分应用失败通常是环境限制，不应该阻断后面的
建账号步骤；真正的致命问题会在建账号那一步暴露出来。

必须以 root 运行，且工作目录在 /usr/lib/python3/dist-packages。
"""

import sys

from plinth import web_framework

web_framework.init()

from plinth import app as app_module  # noqa: E402
from plinth import module_loader  # noqa: E402
from plinth import setup as setup_module  # noqa: E402

module_loader.load_modules()
app_module.apps_init()

# 本包自己加的四个模块。它们的 setup 会写 systemd 服务单元，是「模块装了
# 但服务不存在」的直接原因，所以不管版本记录如何都强制跑一次——四个模块
# 的 setup 都是幂等的，重复执行只是重写一遍配置与单元文件。
FORCE_APPS = ('dhcp', 'ipv6', 'routes', 'gre')


def main():
    """逐个补跑落后的应用。"""
    done = []
    failed = []

    # essential 的应用按版本记录补跑；自定义模块无条件强制跑。
    # 不碰其余非 essential 应用：它们大多是「没装包就不该配」的第三方
    # 应用，硬跑 setup 只会因为缺包刷一屏失败。
    for app in app_module.App.list():
        forced = app.app_id in FORCE_APPS
        if not forced:
            if not app.info.is_essential or not app.needs_setup():
                continue

        try:
            operation = setup_module.run_setup_on_app(
                app.app_id, allow_install=False)
            if operation:
                operation.join()
            done.append(app.app_id)
            print('{}：setup 完成{}'.format(
                app.app_id, '（强制）' if forced else ''))
        except Exception as error:  # pylint: disable=broad-except
            failed.append(app.app_id)
            print('{}：setup 失败（{}）'.format(app.app_id, error),
                  file=sys.stderr)

    print('补跑结果：成功 {} 个，失败 {} 个'.format(len(done), len(failed)))
    if failed:
        print('失败的应用：{}'.format(', '.join(failed)), file=sys.stderr)

    return 0


if __name__ == '__main__':
    sys.exit(main())
