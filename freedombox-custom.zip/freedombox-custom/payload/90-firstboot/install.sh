#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 步骤 9：把首次启动向导自动化，做到「装完即可登录」。
#
# 正常流程要人工在网页上过三步（wizard secret → 建管理员 → backports）。
# 这里全部代做：
#   1. 同步执行必备应用的 setup（配好 LDAP、nslcd、Apache 等）
#   2. 建管理员账号（Django 用户 + LDAP 账号 + admin 组）
#   3. 把向导各步骤标记完成
#
# 管理员账号与密码：
#   deploy.conf 里 ADMIN_USER / ADMIN_PASSWORD 可指定。
#   密码留空则自动生成 16 位随机串，写入 /root/freedombox-admin-password.txt
#   （权限 600），并在部署结束时打印出来。

set -uo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
STATE_DIR=/etc/freedombox-custom
MARK="$STATE_DIR/firstboot-done"
PW_FILE=/root/freedombox-admin-password.txt

ADMIN_USER=${ADMIN_USER:-admin}
ADMIN_PASSWORD=${ADMIN_PASSWORD:-}

log() { echo "[firstboot] $*"; }
die() { echo "[错误] $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "需要 root 权限"

dpkg -s freedombox >/dev/null 2>&1 || \
    die "freedombox 未安装，无法执行首次启动自动化（请先跑 base 步骤）"

mkdir -p "$STATE_DIR"
chmod 700 "$STATE_DIR"

# ---------------------------------------------------------------------------
# 管理员密码：优先用 deploy.conf，其次沿用上次生成的，最后随机生成
# ---------------------------------------------------------------------------
if [ -z "$ADMIN_PASSWORD" ] && [ -s "$PW_FILE" ]; then
    ADMIN_PASSWORD=$(sed -n 's/^password=//p' "$PW_FILE" | head -1)
fi
if [ -z "$ADMIN_PASSWORD" ]; then
    (LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom 2>/dev/null || true) \
        | head -c 16 >"$STATE_DIR/admin.pw.tmp"
    ADMIN_PASSWORD=$(cat "$STATE_DIR/admin.pw.tmp")
    rm -f "$STATE_DIR/admin.pw.tmp"
    [ -n "$ADMIN_PASSWORD" ] || die "生成管理员密码失败"
fi

umask 077
cat >"$PW_FILE" <<EOF
# FreedomBox 定制版 · 管理员账号（首次启动自动化生成）
username=$ADMIN_USER
password=$ADMIN_PASSWORD
url=https://<本机地址>/plinth/
EOF
chmod 600 "$PW_FILE"

# ---------------------------------------------------------------------------
# 1. 先停 plinth，避免与它启动时自带的后台 setup 线程抢同一批配置文件
# ---------------------------------------------------------------------------
log "暂停 plinth，独占执行应用 setup"
systemctl stop plinth 2>/dev/null || true

# 主机名解析兜底：最小化 Debian 的 /etc/hosts 只有 localhost，没有主机名，
# firewalld 经 sudo 跑 firewall-cmd 时会因解析不到主机名而失败（退出 111），
# 使 firewall 应用 setup 失败、Plinth 卡在「正在初始化」。补一条回环记录。
ensure_hosts_hostname() {
    local h
    h=$(cat /etc/hostname 2>/dev/null | head -1 | tr -d ' \t\r')
    [ -n "$h" ] || h=$(hostname 2>/dev/null | tr -d ' \t\r')
    [ -n "$h" ] || return 0
    grep -Eq "[[:space:]]${h}([[:space:]]|\$)" /etc/hosts 2>/dev/null && return 0
    if grep -q "^127.0.1.1[[:space:]]" /etc/hosts 2>/dev/null; then
        sed -i "s/^127.0.1.1[[:space:]].*/& ${h}/" /etc/hosts
    else
        printf '127.0.1.1\t%s\n' "$h" >>/etc/hosts
    fi
    log "已为 /etc/hosts 补主机名记录：$h"
}
ensure_hosts_hostname

# ---------------------------------------------------------------------------
# 2. 同步执行必备应用的 setup
#    --setup-no-install 表示只跑配置、不联网装包：离线机器上不能让它去 apt。
#    空参数即「全部必备应用」。
# ---------------------------------------------------------------------------
export DEBIAN_FRONTEND=noninteractive

log "执行必备应用 setup（不联网）"
setup_rc=0
if ! (cd /usr/lib/python3/dist-packages && plinth --setup-no-install) \
        2>&1 | tee -a "${LOG_FILE:-/dev/null}"; then
    setup_rc=1
fi
if [ "$setup_rc" -ne 0 ]; then
    # setup 是串行跑的，前一个应用抛异常会截断后面所有应用。firewall 在受限
    # 环境里经常失败，而 dhcp、ipv6、users 都排在它后面——DHCP/IPv6 的服务
    # 单元由各自应用的 setup 创建，LDAP 结构与 nslcd 认证方式由 users 创建。
    # 所以这里按应用逐个补跑一遍，各自独立失败。
    log "整轮 setup 有应用失败，逐个补跑落后的应用"
    (cd /usr/lib/python3/dist-packages && \
        python3 "$HERE/setup_rest.py") 2>&1 | tee -a "${LOG_FILE:-/dev/null}"
fi

# ---------------------------------------------------------------------------
# 3. 建管理员 + 标记向导完成
# ---------------------------------------------------------------------------
log "创建管理员账号：$ADMIN_USER"
if ! (cd /usr/lib/python3/dist-packages && \
        ADMIN_USER="$ADMIN_USER" ADMIN_PASSWORD="$ADMIN_PASSWORD" \
        python3 "$HERE/firstboot.py") 2>&1 | tee -a "${LOG_FILE:-/dev/null}"; then
    systemctl start plinth 2>/dev/null || true
    die "管理员账号创建失败，请查看上面的输出"
fi

: >"$MARK"

# ---------------------------------------------------------------------------
# 4. 重新拉起 plinth（它会把 kvstore 里的完成状态读进来）
# ---------------------------------------------------------------------------
log "重启 plinth 使向导状态生效"
systemctl restart plinth

for _ in $(seq 1 60); do
    systemctl is-active --quiet plinth && break
    sleep 1
done
if ! systemctl is-active --quiet plinth; then
    die "plinth 未能启动，请执行 systemctl status plinth 查看原因"
fi

log "完成"
log "登录地址：https://<本机地址>/plinth/"
log "管理员账号：$ADMIN_USER"
log "管理员密码：见 $PW_FILE"
