#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 步骤 9 的回退。
#
# 这里只撤销「向导完成」这个标记，让下次打开网页时重新出现首次启动向导；
# 不删管理员账号 —— 删掉最后一个管理员会让人再也登不进 Plinth。
# 如确实要删账号，请先在网页上建一个新管理员，再删旧的。

set -uo pipefail

STATE_DIR=/etc/freedombox-custom
MARK="$STATE_DIR/firstboot-done"

rm -f "$MARK"

cat <<'EOF'
[提示] 已清除 firstboot 完成标记。
       下次打开网页会重新进入首次启动向导（需要输入 wizard secret，
       见 /var/lib/plinth/firstboot-wizard-secret）。
       管理员账号保留未动。
EOF

exit 0
