#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 在 FreedomBox（Plinth）所有页面底部加入定制版权信息。
#
#   FreedomBox 定制版，起点火箭开发 20261028，版本号 v1.0.1
#
# Plinth 的每个页面都继承 plinth/templates/base.html，因此只改这一处即可
# 覆盖首页、应用页、系统页、登录页和首次启动向导。
#
# 用法：
#   sudo bash install.sh          # 写入（幂等，可重复执行）
#   sudo bash rollback.sh         # 移除
#
# 注意：base.html 属于 freedombox deb 包的文件清单，apt upgrade freedombox
# 会把它还原成官方版本。升级后重新执行本脚本即可。

set -euo pipefail

BASE_TEMPLATE=/usr/lib/python3/dist-packages/plinth/templates/base.html
BACKUP_DIR=/root/freedombox-branding-backup
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
APPLY_SCRIPT=$SCRIPT_DIR/apply_footer.py

fail() {
    echo "错误：$1" >&2
    exit 1
}

[ "$(id -u)" -eq 0 ] || fail "请用 root 运行（sudo bash install.sh）"
[ -f "$BASE_TEMPLATE" ] || fail "找不到 $BASE_TEMPLATE，确认已安装 freedombox"
[ -f "$APPLY_SCRIPT" ] || fail "找不到 $APPLY_SCRIPT"

echo "== 1/4 备份原模板 =="
STAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$BACKUP_DIR/$STAMP"
cp -a "$BASE_TEMPLATE" "$BACKUP_DIR/$STAMP/base.html"
echo "已备份到 $BACKUP_DIR/$STAMP/base.html"

echo ""
echo "== 2/4 写入版权信息 =="
python3 "$APPLY_SCRIPT" install

echo ""
echo "== 3/4 校验模板语法 =="
cd /usr/lib/python3/dist-packages
python3 - <<'PY'
from plinth import cfg
cfg.read()

from plinth import web_framework
web_framework.init()
web_framework.post_init()

from django.template.loader import get_template
get_template('base.html')
print('base.html 解析正常')
PY

echo ""
echo "== 4/4 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if ! systemctl is-active --quiet plinth; then
    echo "Plinth 未能启动，正在回滚..." >&2
    cp -a "$BACKUP_DIR/$STAMP/base.html" "$BASE_TEMPLATE"
    systemctl restart plinth || true
    fail "已回滚到安装前的模板"
fi
echo "Plinth 运行正常"

echo ""
echo "== 结果 =="
CODE=$(curl -sk -o /tmp/branding-check.html -w '%{http_code}' \
    https://127.0.0.1/plinth/accounts/login/ 2>/dev/null || echo 000)
echo "登录页 HTTP $CODE"
if grep -q '起点火箭开发' /tmp/branding-check.html 2>/dev/null; then
    echo "页脚已生效："
    grep -o 'FreedomBox 定制版[^<]*' /tmp/branding-check.html | head -1
else
    echo "警告：登录页未检测到版权信息，请检查模板" >&2
fi
rm -f /tmp/branding-check.html
