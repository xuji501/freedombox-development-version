#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 移除 install.sh 写入的定制版权信息。
#
# 用法：
#   sudo bash rollback.sh                        # 只移除版权块
#   sudo bash rollback.sh /root/freedombox-branding-backup/20261028-120000
#                                                # 用指定备份整体还原

set -euo pipefail

BASE_TEMPLATE=/usr/lib/python3/dist-packages/plinth/templates/base.html
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
APPLY_SCRIPT=$SCRIPT_DIR/apply_footer.py

fail() {
    echo "错误：$1" >&2
    exit 1
}

[ "$(id -u)" -eq 0 ] || fail "请用 root 运行（sudo bash rollback.sh）"

if [ $# -ge 1 ]; then
    BACKUP=$1/base.html
    [ -f "$BACKUP" ] || fail "备份不存在：$BACKUP"
    cp -a "$BACKUP" "$BASE_TEMPLATE"
    echo "已从 $BACKUP 还原"
else
    [ -f "$APPLY_SCRIPT" ] || fail "找不到 $APPLY_SCRIPT"
    python3 "$APPLY_SCRIPT" uninstall
fi

echo ""
echo "重启 Plinth"
systemctl restart plinth
sleep 4

if systemctl is-active --quiet plinth; then
    echo "Plinth 运行正常，页脚已还原"
else
    fail "Plinth 未能启动，请检查 journalctl -u plinth"
fi
