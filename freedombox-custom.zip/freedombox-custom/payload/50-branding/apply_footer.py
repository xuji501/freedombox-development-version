"""Insert or remove the custom copyright line in Plinth's base template.

Every page served by Plinth inherits ``plinth/templates/base.html`` -- the
home page, the app pages, the system pages, the login page and the first
boot wizard all extend it directly or through a chain of templates.  Adding
the line once inside ``<footer>`` therefore covers every page.

The block is wrapped in marker comments so the script can be run again
after a ``freedombox`` package upgrade, which restores the original file.
"""

import os
import pathlib
import re
import sys

BASE_TEMPLATE = pathlib.Path(
    '/usr/lib/python3/dist-packages/plinth/templates/base.html')

MARKER_START = '    <!-- plinth-branding:start -->'
MARKER_END = '    <!-- plinth-branding:end -->'

DEFAULT_FOOTER_TEXT = 'FreedomBox 定制版，起点火箭开发 20261028，版本号 v1.0.1'

# 文案可由环境变量覆盖，便于部署包按客户改版权行而不改脚本。
FOOTER_TEXT = os.environ.get('PLINTH_FOOTER_TEXT') or DEFAULT_FOOTER_TEXT

FOOTER_BLOCK = '''{start}
    <div class="container plinth-copyright">
      <p class="text-muted small mb-0">
        {text}
      </p>
    </div>
{end}
'''.format(start=MARKER_START, end=MARKER_END, text=FOOTER_TEXT)

BLOCK_PATTERN = re.compile(
    re.escape(MARKER_START) + r'.*?' + re.escape(MARKER_END) + r'\n',
    re.DOTALL)


def remove(text: str) -> tuple[str, bool]:
    """Strip an existing block, returning the new text and whether it hit."""
    new_text, count = BLOCK_PATTERN.subn('', text)
    return new_text, bool(count)


def install() -> int:
    text = BASE_TEMPLATE.read_text(encoding='utf-8')

    if MARKER_START in text:
        text, _ = remove(text)
        print('已存在旧标记，先移除再重新写入')

    if '</footer>' not in text:
        print('未找到 </footer>，模板结构与预期不符', file=sys.stderr)
        return 1

    index = text.rindex('</footer>')
    line_start = text.rindex('\n', 0, index) + 1
    text = text[:line_start] + FOOTER_BLOCK + text[line_start:]

    BASE_TEMPLATE.write_text(text, encoding='utf-8')
    print('已写入版权信息 ->', BASE_TEMPLATE)
    return 0


def uninstall() -> int:
    text = BASE_TEMPLATE.read_text(encoding='utf-8')
    text, removed = remove(text)
    if not removed:
        print('未发现版权信息块，无需处理')
        return 0

    BASE_TEMPLATE.write_text(text, encoding='utf-8')
    print('已移除版权信息 ->', BASE_TEMPLATE)
    return 0


if __name__ == '__main__':
    action = sys.argv[1] if len(sys.argv) > 1 else 'install'
    sys.exit(uninstall() if action == 'uninstall' else install())
