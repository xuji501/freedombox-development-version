#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 为 FreedomBox 安装路由管理模块（静态路由 + OSPF 动态路由）。
#
# 用法：sudo bash install.sh
#
# 安装内容：
#   /usr/lib/python3/dist-packages/plinth/modules/routes/   模块代码（含 OSPF）
#   /etc/freedombox/modules-enabled/routes                  启用标记
#   /etc/freedombox-routes/routes.json                      路由清单（0644）
#   /usr/lib/freedombox-routes/apply.py                     开机恢复脚本（0755）
#   /etc/systemd/system/freedombox-routes.service           oneshot unit
#
# 注意：本模块会调用 ip-route(8) 改动内核路由表，但不会碰默认路由。
# 任何一步失败都会自动回滚到安装前的状态。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/routes
ENABLED_DIR=/etc/freedombox/modules-enabled
CONFIG_DIR=/etc/freedombox-routes
APPLY_DIR=/usr/lib/freedombox-routes
UNIT_FILE=/etc/systemd/system/freedombox-routes.service
SERVICE=freedombox-routes
BACKUP_ROOT=/root/freedombox-routes-module-backup
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
SOURCE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

rollback() {
    echo "正在回滚..." >&2

    systemctl stop "$SERVICE" 2>/dev/null || true
    systemctl disable "$SERVICE" 2>/dev/null || true
    rm -f "$UNIT_FILE"
    systemctl daemon-reload 2>/dev/null || true

    rm -rf "$APPLY_DIR"

    # 路由清单在重装场景下可能已有用户添加的路由，必须原样还原而不是删掉。
    if [ -d "$BACKUP_DIR/config" ]; then
        rm -rf "$CONFIG_DIR"
        cp -a "$BACKUP_DIR/config" "$CONFIG_DIR"
        echo "已恢复原有路由清单" >&2
    else
        rm -rf "$CONFIG_DIR"
    fi

    rm -f "$ENABLED_DIR/routes"

    if [ -d "$BACKUP_DIR/module" ]; then
        rm -rf "$MODULE_DIR"
        cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
        echo "已恢复原有模块目录" >&2
    else
        rm -rf "$MODULE_DIR"
        echo "已移除新模块目录" >&2
    fi

    if [ -f "$BACKUP_DIR/enabled-routes" ]; then
        cp -a "$BACKUP_DIR/enabled-routes" "$ENABLED_DIR/routes"
    fi

    systemctl restart plinth 2>/dev/null || true
    echo "回滚完成" >&2
}

echo "=============================================="
echo " FreedomBox 路由管理模块安装（静态路由 + OSPF）"
echo "=============================================="

echo ""
echo "== 1/9 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
[ -f "$SOURCE_DIR/files/privileged.py" ] || fail "在 $SOURCE_DIR/files 下找不到模块源文件"
dpkg -s freedombox >/dev/null 2>&1 || fail "未检测到 freedombox 软件包"
echo "freedombox 版本：$(dpkg-query -W -f='${Version}' freedombox)"
command -v ip >/dev/null || fail "未找到 ip 命令（iproute2）"
echo "iproute2：$(ip -V 2>/dev/null | head -1)"
[ -d /etc/systemd/system ] || fail "未找到 /etc/systemd/system"
echo "现有网卡：$(ip -o link show | awk -F': ' '{print $2}' | tr '\n' ' ')"

echo ""
echo "== 2/9 备份现有状态 =="
mkdir -p "$BACKUP_DIR"
if [ -d "$MODULE_DIR" ]; then
    cp -a "$MODULE_DIR" "$BACKUP_DIR/module"
    echo "已备份现有模块目录"
fi
if [ -f "$ENABLED_DIR/routes" ]; then
    cp -a "$ENABLED_DIR/routes" "$BACKUP_DIR/enabled-routes"
    echo "已备份现有启用标记"
fi
if [ -d "$CONFIG_DIR" ]; then
    cp -a "$CONFIG_DIR" "$BACKUP_DIR/config"
    echo "已备份现有路由清单（重装时保留已添加的路由）"
fi
ip -4 route show > "$BACKUP_DIR/routes-ipv4.txt" 2>/dev/null || true
ip -6 route show > "$BACKUP_DIR/routes-ipv6.txt" 2>/dev/null || true
echo "备份目录：$BACKUP_DIR"

echo ""
echo "== 3/9 部署模块文件 =="
mkdir -p "$MODULE_DIR/templates"
install -m 644 "$SOURCE_DIR/files/__init__.py"            "$MODULE_DIR/__init__.py"     || fail "复制 __init__.py 失败"
install -m 644 "$SOURCE_DIR/files/manifest.py"            "$MODULE_DIR/manifest.py"     || fail "复制 manifest.py 失败"
install -m 644 "$SOURCE_DIR/files/forms.py"               "$MODULE_DIR/forms.py"        || fail "复制 forms.py 失败"
install -m 644 "$SOURCE_DIR/files/views.py"               "$MODULE_DIR/views.py"        || fail "复制 views.py 失败"
install -m 644 "$SOURCE_DIR/files/urls.py"                "$MODULE_DIR/urls.py"         || fail "复制 urls.py 失败"
install -m 644 "$SOURCE_DIR/files/privileged.py"          "$MODULE_DIR/privileged.py"   || fail "复制 privileged.py 失败"
install -m 644 "$SOURCE_DIR/files/submenu.py"             "$MODULE_DIR/submenu.py"      || fail "复制 submenu.py 失败"
install -m 644 "$SOURCE_DIR/files/ospf_config.py"         "$MODULE_DIR/ospf_config.py"  || fail "复制 ospf_config.py 失败"
install -m 644 "$SOURCE_DIR/files/ospf_forms.py"          "$MODULE_DIR/ospf_forms.py"   || fail "复制 ospf_forms.py 失败"
install -m 644 "$SOURCE_DIR/files/templates/routes.html"  "$MODULE_DIR/templates/routes.html" || fail "复制静态路由模板失败"
install -m 644 "$SOURCE_DIR/files/templates/ospf.html"    "$MODULE_DIR/templates/ospf.html"   || fail "复制 OSPF 模板失败"
rm -rf "$MODULE_DIR/__pycache__"
chown -R root:root "$MODULE_DIR"
chmod 755 "$MODULE_DIR"
echo "已部署到 $MODULE_DIR"

echo ""
echo "== 4/9 语法检查 =="
for file in "$MODULE_DIR"/*.py; do
    if ! python3 -m py_compile "$file"; then
        rollback
        fail "语法错误：$file"
    fi
done
echo "全部 Python 文件语法正确"

echo ""
echo "== 5/9 启用模块 =="
mkdir -p "$ENABLED_DIR"
echo "plinth.modules.routes" > "$ENABLED_DIR/routes"
chmod 644 "$ENABLED_DIR/routes"
echo "已写入 $ENABLED_DIR/routes"

echo ""
echo "== 6/9 导入与表单检查 =="
CHECK_SCRIPT=$(mktemp /tmp/routes-check-XXXXXX.py)
cat > "$CHECK_SCRIPT" <<'PYEOF'
# web_framework.init() configures Django itself, so django.setup() must not
# be called beforehand.
from plinth import web_framework

web_framework.init()

from plinth.modules.routes import forms, privileged, views  # noqa: E402

assert views.RoutesAppView.app_id == 'routes'
assert views.RoutesAppView.form_class is forms.RouteForm

form = forms.RouteForm()
for field in ('family', 'destination', 'gateway', 'device', 'metric'):
    assert field in form.fields, f'缺少表单字段 {field}'

# 网卡下拉至少要有「自动选择」这一项。
assert form.fields['device'].choices[0][0] == ''

for action in ('setup', 'get_devices', 'get_routes', 'add_route',
               'delete_route', 'uninstall', 'get_ospf', 'save_ospf_global',
               'add_ospf_area', 'delete_ospf_area', 'add_ospf_interface',
               'delete_ospf_interface', 'uninstall_ospf'):
    assert callable(getattr(privileged, action)), f'缺少动作 {action}'

# OSPF 配置生成是纯函数，必须能在不碰系统的情况下算出 frr.conf 片段。
from plinth.modules.routes import ospf_config  # noqa: E402

assert ospf_config.normalize_area_id('1') == '0.0.0.1'
assert not ospf_config.has_block(''), '空配置本应判定为没有标记块'
assert ospf_config.has_foreign_ospf(
    'router ospf\n'), '未加标记的外来 OSPF 配置必须能被识别出来'

# 路由校验必须拒绝默认路由，这是本模块最重要的安全边界。
try:
    privileged._validate_route(
        {'family': 'ipv4', 'destination': '0.0.0.0/0',
         'gateway': '10.0.0.1', 'device': '', 'metric': 0}, [])
except ValueError:
    pass
else:
    raise AssertionError('默认路由本应被拒绝')

print('开机脚本语法检查：', end='')
compile(privileged.APPLY_SCRIPT, 'apply.py', 'exec')
print('通过')

from django.template.loader import get_template  # noqa: E402
for name in ('routes.html', 'ospf.html'):
    template = get_template(name)
    print('模板来源：', template.origin.name)
print('模块导入、表单字段、路由校验与模板加载全部正常')
PYEOF

if ! python3 "$CHECK_SCRIPT"; then
    rm -f "$CHECK_SCRIPT"
    rollback
    fail "导入检查未通过，已回滚"
fi
rm -f "$CHECK_SCRIPT"

echo ""
echo "== 7/9 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if ! systemctl is-active --quiet plinth; then
    rollback
    fail "Plinth 未能启动，已回滚"
fi
echo "Plinth 运行正常"

echo ""
echo "== 8/9 首次初始化 =="
# 生成路由清单、开机恢复脚本和 systemd unit，并启用服务。
# 不调用 app.setup()，避免走包管理组件（需要 Plinth 操作上下文）。
if [ -f "$CONFIG_DIR/routes.json" ] && [ -x "$APPLY_DIR/apply.py" ]; then
    echo "配置与脚本已存在，仅刷新脚本与 unit"
fi

(cd /usr/lib/python3/dist-packages && \
    timeout 120 python3 "$SOURCE_DIR/init_once.py")
INIT_RC=$?

if [ "$INIT_RC" -ne 0 ]; then
    rollback
    fail "首次初始化失败（退出码 $INIT_RC），已回滚"
fi

echo ""
echo "== 9/9 验证 =="
[ -f "$CONFIG_DIR/routes.json" ] || { rollback; fail "路由清单未生成"; }
[ -x "$APPLY_DIR/apply.py" ] || { rollback; fail "开机恢复脚本未安装"; }
[ -f "$UNIT_FILE" ] || { rollback; fail "systemd unit 未安装"; }
systemctl is-enabled --quiet "$SERVICE" || { rollback; fail "服务未设为开机启动"; }
systemctl is-active --quiet "$SERVICE" || { rollback; fail "服务未启动"; }

echo "路由清单：$(ls -l "$CONFIG_DIR/routes.json" | awk '{print $1, $3, $4}')"
echo "恢复脚本：$(ls -l "$APPLY_DIR/apply.py" | awk '{print $1, $3, $4}')"
echo "unit 文件：$(ls -l "$UNIT_FILE" | awk '{print $1, $3, $4}')"

# 开机脚本本身要能独立跑通：不依赖 Plinth，重复执行也无害。
if ! /usr/bin/python3 "$APPLY_DIR/apply.py"; then
    rollback
    fail "开机恢复脚本执行失败"
fi
echo "开机恢复脚本独立执行成功（当前无路由，属空操作）"

# 确认内核路由表仍可读，且默认路由没有被改动。
DEFAULT_V4=$(ip -4 route show default | head -1)
[ -n "$DEFAULT_V4" ] || { rollback; fail "IPv4 默认路由丢失，请立即检查网络"; }
echo "IPv4 默认路由：$DEFAULT_V4"

if systemctl is-enabled --quiet plinth; then
    CODE=$(curl -sk -o /dev/null -w '%{http_code}' \
        https://127.0.0.1/plinth/sys/routes/ 2>/dev/null || echo 000)
    echo "路由管理页面返回 HTTP $CODE（302 表示需要登录，属正常）"
fi

echo ""
echo "== 安装结果 =="
python3 - <<'PYEOF'
import json
try:
    with open('/etc/freedombox-routes/routes.json') as handle:
        data = json.load(handle)
except Exception:
    data = {}
routes = data.get('routes') or []
if not routes:
    print('已管理的路由：（空）')
for item in routes:
    print('  {:<6s} {:<20s} via {} dev {}'.format(
        item.get('family', '?'), item.get('destination', '?'),
        item.get('gateway') or '-', item.get('device') or 'auto'))
PYEOF

echo ""
echo "服务状态：$(systemctl is-active "$SERVICE") / 开机启动：$(systemctl is-enabled "$SERVICE")"
echo ""
echo "访问 https://<本机地址>/plinth/sys/routes/ 管理静态路由"
echo "访问 https://<本机地址>/plinth/sys/routes/ospf/ 配置 OSPF 动态路由"
echo "（入口在「系统 → 网络」菜单下）"
echo "回滚命令：sudo bash $SOURCE_DIR/rollback.sh $BACKUP_DIR"
echo "=============================================="
