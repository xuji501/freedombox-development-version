#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 为 freedombox 及其依赖预置 debconf 应答，保证 apt install 全程零交互。
#
# 会问问题的包主要有四个：
#   slapd          —— 建库时问域、组织名、管理员密码，不答就会卡住
#   nslcd          —— 问 LDAP URI 与认证方式
#   libnss-ldapd   —— 问要把哪些库接进 nsswitch
#   make-ssl-cert  —— 问证书里的主机名
#
# 域统一用 thisbox：Plinth 后续会把 LDAP 改写成 dc=thisbox，
# 这里先建成同样的后缀，避免两步不一致。

set -uo pipefail

STATE_DIR=/etc/freedombox-custom
PW_FILE="$STATE_DIR/ldap-admin.pw"

mkdir -p "$STATE_DIR"
chmod 700 "$STATE_DIR"

# slapd 的管理员密码随机生成一次并落盘；重跑时沿用，避免已建好的库对不上。
# 这里刻意不用 python3 —— 最小化安装的 Debian 上还没有它（python3 是
# freedombox 的依赖，要等本步骤装完才有），只用 coreutils 就能办到。
if [ ! -s "$PW_FILE" ]; then
    (LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom 2>/dev/null || true) \
        | head -c 24 >"$PW_FILE"
    if [ ! -s "$PW_FILE" ]; then
        echo "[错误] 生成 LDAP 管理员密码失败" >&2
        exit 1
    fi
    chmod 600 "$PW_FILE"
fi

LDAP_PW=$(cat "$PW_FILE")
FQDN=$(hostname -f 2>/dev/null || hostname)

PRESEED=$(mktemp /tmp/freedombox-custom-preseed.XXXXXX)
trap 'rm -f "$PRESEED"' EXIT

cat >"$PRESEED" <<EOF
# ---- slapd：不交互建库 ----
slapd slapd/no_configuration boolean false
slapd slapd/domain string thisbox
slapd shared/organization string FreedomBox
slapd slapd/backend select MDB
slapd slapd/password1 password $LDAP_PW
slapd slapd/password2 password $LDAP_PW
slapd slapd/internal/adminpw password $LDAP_PW
slapd slapd/internal/generated_adminpw password $LDAP_PW
slapd slapd/purge_database boolean false
slapd slapd/move_old_database boolean true

# ---- nslcd / libnss-ldapd ----
nslcd nslcd/ldap-uris string ldapi:///
nslcd nslcd/ldap-base string dc=thisbox
nslcd nslcd/ldap-auth-type select none
libnss-ldapd libnss-ldapd/nsswitch multiselect passwd, group, shadow

# ---- make-ssl-cert ----
make-ssl-cert make-ssl-cert/hostname string $FQDN
make-ssl-cert make-ssl-cert/title string FreedomBox

# ---- 其它会弹问题的包 ----
popularity-contest popularity-contest/participate boolean false
unattended-upgrades unattended-upgrades/enable_auto_updates boolean true
EOF

debconf-set-selections "$PRESEED" || {
    echo "[错误] debconf-set-selections 失败" >&2
    exit 1
}

count=$(grep -c '^[a-z]' "$PRESEED")
echo "  已预置 $count 条 debconf 应答（LDAP 管理员密码：$PW_FILE）"
