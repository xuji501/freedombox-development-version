#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 步骤 0：在裸 Debian 上装出完整 FreedomBox。
#
# 本包自带一份本地 apt 源（payload/00-base/repo），里面是 freedombox 及其
# 全部依赖的 458 个 deb 包（约 159MB，amd64 + all）。这一步把它们离线装上，
# 目标机不需要能访问任何 Debian 源。
#
# 版本钉定在 trixie 的 freedombox 25.9.3+deb13u1 —— 与本包开发验证时所用的
# 版本一致。不取 backports 的 26.x，因为本包改写的是 25.9.3 的 Plinth 内部
# 结构，跨大版本可能对不上。
#
# 除 freedombox 本体外，还一并装上后续步骤要用的工具：
#   dnsmasq-base  DHCP / IPv6 模块的地址分配后端
#   openvpn       OpenVPN 账号管理
#   easy-rsa      全新部署 OpenVPN 时签发证书
#   frr           OSPF 动态路由（可选功能，装上才能离线启用）
#   kmod          提供 modprobe；最小化 Debian 没有它，GRE 模块就没法按需加载

set -uo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
REPO="$HERE/repo"
LIST=/etc/apt/sources.list.d/freedombox-custom-local.list
STATE_DIR=/etc/freedombox-custom
MARK="$STATE_DIR/base-installed"
EXPECTED_DEBS=458

log() { echo "[base] $*"; }
die() { echo "[错误] $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "需要 root 权限"

mkdir -p "$STATE_DIR"
chmod 700 "$STATE_DIR"

# 已经装过就直接收工：本步骤的目标状态就是「freedombox 已安装」。
if dpkg -s freedombox >/dev/null 2>&1; then
    version=$(dpkg-query -W -f='${Version}' freedombox)
    log "freedombox 已安装（$version），本步跳过"
    : >"$MARK"
    exit 0
fi

# ---------------------------------------------------------------------------
# 前置校验：离线源必须完整，否则装到一半缺包会很麻烦
# ---------------------------------------------------------------------------
[ -f "$REPO/Packages.gz" ] || die "缺少离线源索引：$REPO/Packages.gz"

ndeb=$(find "$REPO/debs" -maxdepth 1 -name '*.deb' 2>/dev/null | wc -l)
[ "$ndeb" -ge "$EXPECTED_DEBS" ] || \
    die "离线源不完整：只有 $ndeb 个 deb 包，预期至少 $EXPECTED_DEBS 个"

# 本机架构必须是 amd64：离线源只打了 amd64 的包。
arch=$(dpkg --print-architecture)
[ "$arch" = "amd64" ] || \
    die "本离线源只适用于 amd64，当前系统是 $arch"

avail=$(df -Pk /usr 2>/dev/null | awk 'NR==2 {print int($4/1024)}')
if [ -n "$avail" ] && [ "$avail" -lt 1500 ]; then
    die "/usr 剩余空间只有 ${avail}MB，安装 freedombox 至少需要 1500MB"
fi

log "离线源完整：$ndeb 个 deb 包，$(du -sh "$REPO/debs" | cut -f1)"

# ---------------------------------------------------------------------------
# 1. 预置 debconf
# ---------------------------------------------------------------------------
log "预置 debconf 应答（slapd / nslcd / ssl-cert 等）"
bash "$HERE/preseed.sh" || die "debconf 预置失败"

# ---------------------------------------------------------------------------
# 2. 挂本地源
# ---------------------------------------------------------------------------
log "挂载离线 apt 源：$REPO"
printf 'deb [trusted=yes] file:%s ./\n' "$REPO" >"$LIST"
chmod 644 "$LIST"

# 只刷新这一个源。目标机可能完全没有外网，让 apt 去试其它源会长时间重试。
# Languages=none 避免 apt 去找不存在的翻译文件刷一屏警告。
APT_SCOPE=(-o "Dir::Etc::sourcelist=$LIST"
           -o Dir::Etc::sourceparts=/dev/null
           -o Acquire::Languages=none
           -o Acquire::Retries=0)

log "读取离线源索引"
if ! apt-get update "${APT_SCOPE[@]}" >/dev/null 2>&1; then
    die "离线源索引读取失败，请检查 $REPO/Packages.gz"
fi

# ---------------------------------------------------------------------------
# 3. 安装
# ---------------------------------------------------------------------------
log "开始安装（$ndeb 个包，需要几分钟，请勿中断）"

export DEBIAN_FRONTEND=noninteractive
set -o pipefail
apt-get install -y --no-install-recommends \
    "${APT_SCOPE[@]}" \
    -o Dpkg::Options::=--force-confdef \
    -o Dpkg::Options::=--force-confold \
    freedombox dnsmasq-base openvpn easy-rsa frr kmod \
    2>&1 | tee -a "${LOG_FILE:-/dev/null}"
rc=${PIPESTATUS[0]}

if [ "$rc" -ne 0 ]; then
    die "apt-get install 失败（退出码 $rc）"
fi
if ! dpkg -s freedombox >/dev/null 2>&1; then
    die "apt-get 报告成功，但 freedombox 仍未安装"
fi

version=$(dpkg-query -W -f='${Version}' freedombox)
log "freedombox 安装完成：$version"

# ---------------------------------------------------------------------------
# 3.5 主机名解析兜底
# ---------------------------------------------------------------------------
# 最小化 Debian（debootstrap）只写 127.0.0.1 localhost，不写主机名。
# firewalld 的 setup 会经 sudo 执行 firewall-cmd，sudo 解析不到主机名会报
# 「unable to resolve host」并以 111 退出，进而让 firewall 应用 setup 失败、
# Plinth 长期停在「正在初始化」页面。这里给主机名补一条回环记录，与
# debian-installer 的标准做法一致（127.0.1.1 <主机名>）。
#
# 仅在确实缺失时写入，已存在则不动，保证幂等。
ensure_hosts_hostname() {
    local h
    h=$(cat /etc/hostname 2>/dev/null | head -1 | tr -d ' \t\r')
    [ -n "$h" ] || h=$(hostname 2>/dev/null | tr -d ' \t\r')
    [ -n "$h" ] || return 0
    # 已经有该主机名（非 localhost）的行就跳过
    if grep -Eq "[[:space:]]${h}([[:space:]]|\$)" /etc/hosts 2>/dev/null; then
        return 0
    fi
    if grep -q "^127.0.1.1[[:space:]]" /etc/hosts 2>/dev/null; then
        sed -i "s/^127.0.1.1[[:space:]].*/& ${h}/" /etc/hosts
    else
        printf '127.0.1.1\t%s\n' "$h" >>/etc/hosts
    fi
    log "已为 /etc/hosts 补主机名记录：$h"
}
ensure_hosts_hostname

# ---------------------------------------------------------------------------
# 4. 收尾：撤掉本地源，避免包目录被删后 apt 一直报源不可用
# ---------------------------------------------------------------------------
cp -a "$LIST" "$STATE_DIR/local-repo.txt" 2>/dev/null || true
rm -f "$LIST"
cat >"$STATE_DIR/local-repo.txt" <<EOF
# 本次部署曾使用包内离线源。需要再次离线安装时，重新挂上即可：
#   echo "deb [trusted=yes] file:<本包目录>/payload/00-base/repo ./" \\
#       > /etc/apt/sources.list.d/freedombox-custom-local.list
#   apt-get update -o Dir::Etc::sourcelist=/etc/apt/sources.list.d/freedombox-custom-local.list \\
#                  -o Dir::Etc::sourceparts=/dev/null
# 源目录：$REPO
EOF

# freedombox 装好后 plinth 由 systemd 拉起，这里确认一下单元已注册。
if systemctl list-unit-files plinth.service >/dev/null 2>&1; then
    log "plinth.service 已注册"
else
    die "未找到 plinth.service，freedombox 安装不完整"
fi

: >"$MARK"
log "完成"
