#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 步骤 0 的回退。
#
# freedombox 是整套系统的基础：卸掉它会把 plinth、LDAP、Apache 配置一起带走，
# 并可能连带删除用户与数据。因此本步骤不提供自动回退，只做提示。
# 真要拆掉请用 apt purge freedombox 并自行承担后果。

set -uo pipefail

cat <<'EOF'
[提示] base 步骤（freedombox 本体）不支持自动回退。
       本包只会在未安装 freedombox 时执行安装；已安装的机器上该步骤本就不会运行。
       如确需卸载，请手动执行：
           sudo apt purge freedombox
       注意：purge 会连带删除 Plinth 配置、LDAP 数据与用户账号。
EOF

exit 0
