# SPDX-License-Identifier: AGPL-3.0-or-later
"""FreedomBox app to manage GRE tunnels."""

from django.utils.translation import gettext_lazy as _

from plinth import app as app_module
from plinth import menu

from . import manifest, privileged, submenu

_description = [
    _('GRE（通用路由封装）把一种协议的数据包装进另一种协议里传输，'
      '最常见的用法是在两个公网地址之间拉一条二层直达通道，'
      '让两端的内网像接在同一台交换机上一样互通。'),
    _('每条隧道需要填写对端的公网地址；本端地址留空时由内核按路由自动选择。'
      '隧道自己的 IP 地址填在「隧道地址」里，它和对端隧道地址应在同一个网段。'),
    _('GRE 本身不加密也不认证，只做封装。需要保密时请把业务跑在 GRE 之上的 '
      'IPsec 或 WireGuard 里，或者直接改用 OpenVPN。'),
]


class GreApp(app_module.App):
    """FreedomBox app for GRE tunnels."""

    app_id = 'gre'

    _version = 1

    def __init__(self) -> None:
        """Create components for the app."""
        super().__init__()

        info = app_module.Info(app_id=self.app_id, version=self._version,
                               name=_('GRE 隧道'), icon='fa-road',
                               description=_description, tags=manifest.tags)
        self.add(info)

        # Plinth only renders two levels of menu, so an item nested under the
        # Networks card would never be drawn.  Stay a sibling of it and add the
        # shared tab bar to the Networks page in post_init().
        menu_item = menu.Menu('menu-gre', info.name, info.icon, info.tags,
                              'gre:index', parent_url_name='system:system',
                              order=25)
        self.add(menu_item)

    def post_init(self):
        """Add the shared tab bar to the Networks page."""
        submenu.install()

    def setup(self, old_version):
        """Install the configuration file, helper and unit."""
        super().setup(old_version)
        privileged.setup()
        if not old_version:
            self.enable()

    def uninstall(self):
        """Remove the tunnels and the boot time helper."""
        super().uninstall()
        privileged.uninstall()
