# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tags for the GRE tunnel app."""

from django.utils.translation import gettext_lazy as _

tags = [_('网络'), _('隧道'), _('系统')]
