# SPDX-License-Identifier: AGPL-3.0-or-later
"""Django form for creating and editing a GRE tunnel."""

import logging

from django import forms

from . import privileged

logger = logging.getLogger(__name__)


class GreTunnelForm(forms.Form):
    """Everything the kernel needs to build one GRE interface."""

    tunnel_id = forms.CharField(widget=forms.HiddenInput, required=False)

    name = forms.CharField(
        label='隧道名称',
        widget=forms.TextInput(attrs={'placeholder': 'gre1'}),
        help_text='网卡名称，只能包含字母、数字、下划线和短横线，'
                  '必须以字母开头，最长 15 个字符。')

    local = forms.CharField(
        label='本端地址', required=False,
        widget=forms.TextInput(attrs={'placeholder': '10.10.173.19'}),
        help_text='本机承载隧道的公网或内网 IPv4 地址，必须已经配置在网卡上。'
                  '留空则由内核按路由自动选择源地址。')

    remote = forms.CharField(
        label='远端地址',
        widget=forms.TextInput(attrs={'placeholder': '203.0.113.10'}),
        help_text='对端设备的 IPv4 地址。两端互为对方的远端地址。')

    address = forms.CharField(
        label='隧道地址', required=False,
        widget=forms.TextInput(attrs={'placeholder': '10.20.0.1/30'}),
        help_text='隧道接口自己的 IP 地址与前缀长度。'
                  '对端应配置同网段的另一个地址，例如 10.20.0.2/30。'
                  '只做二层透传时可以留空。')

    mtu = forms.IntegerField(
        label='MTU', initial=1476, min_value=576, max_value=65535,
        help_text='默认 1476。GRE 至少占用 24 字节，保持 1500 会让大包被静默丢弃。'
                  '启用 Key 或校验和时应再减 4。')

    ttl = forms.IntegerField(
        label='TTL', initial=64, min_value=0, max_value=255, required=False,
        help_text='封装后外层 IP 的 TTL，0 表示使用内核默认值。')

    key = forms.IntegerField(
        label='GRE Key', initial=0, min_value=0, max_value=4294967295,
        required=False,
        help_text='可选的隧道标识，0 表示不使用。'
                  '两端必须填写相同的值，否则对端会丢弃报文。')

    checksum = forms.BooleanField(
        label='启用校验和', required=False,
        help_text='为封装报文计算校验和，可发现传输中的位错误，但会多占 4 字节 MTU '
                  '并增加 CPU 开销。')

    clamp_mss = forms.BooleanField(
        label='自动钳制 TCP MSS', required=False, initial=True,
        help_text='对经过本机转发的 TCP 连接，把 MSS 压到隧道的 MTU，'
                  '避免「隧道通了但网页打不开」这类问题。建议保持开启。')

    enabled = forms.BooleanField(
        label='立即启用', required=False, initial=True,
        help_text='取消勾选则只保存配置，不创建接口。')

    comment = forms.CharField(
        label='备注', required=False,
        widget=forms.TextInput(attrs={'placeholder': '例如：到机房 A 的专线'}),
        help_text='仅用于本页面显示，不影响隧道行为。')

    def __init__(self, *args, **kwargs):
        """Allow the caller to preset the suggested interface name."""
        super().__init__(*args, **kwargs)
        if not self.is_bound and not self.initial.get('name'):
            try:
                suggested = privileged.get_tunnels()['suggested_name']
            except Exception:
                logger.exception('Unable to suggest a tunnel name')
                suggested = 'gre1'

            self.fields['name'].initial = suggested

    def clean_name(self):
        """Reject the names the kernel or this app cannot use."""
        name = (self.cleaned_data.get('name') or '').strip()
        if not privileged.NAME_PATTERN.match(name):
            raise forms.ValidationError(
                '只能包含字母、数字、下划线和短横线，必须以字母开头，'
                '长度不超过 15 个字符。')
        if name in privileged.FORBIDDEN_NAMES:
            raise forms.ValidationError('{} 是系统保留名称。'.format(name))

        return name

    def clean_address(self):
        """Normalise the optional tunnel address."""
        return (self.cleaned_data.get('address') or '').strip()

    def clean(self):
        """Require a remote address and keep the pair consistent."""
        cleaned = super().clean()
        local = (cleaned.get('local') or '').strip()
        remote = (cleaned.get('remote') or '').strip()
        if remote and local and local == remote:
            raise forms.ValidationError('本端地址与远端地址不能相同。')

        return cleaned
