# SPDX-License-Identifier: AGPL-3.0-or-later
"""Create and manage GRE tunnels on FreedomBox.

GRE (Generic Routing Encapsulation) is the tunnel type RouterOS calls
``gre-tunnel``.  The kernel module ``ip_gre`` already ships with Debian, so
this app only has to keep a list of tunnels, translate each entry into
``ip link`` / ``ip addr`` calls, and restore the list at boot.

Two things make a hand written list necessary:

* A tunnel is bound to two addresses (local and remote), not to a connection
  profile.  NetworkManager cannot own it without fighting the module that
  manages the LAN interface.
* The tunnel has to survive a reboot even when the local address arrives late,
  so restoring is a oneshot unit that retries nothing and simply runs after
  ``network-online.target``.

MTU is the field people get wrong.  GRE adds at least 24 bytes of overhead
(20 for the outer IPv4 header and 4 for the GRE header, plus 4 more when a
key or a checksum is used).  A tunnel left at 1500 silently blackholes large
packets, which looks like "the tunnel is up but nothing works".  The default
here is therefore 1476, and clamping the TCP MSS of forwarded traffic is on by
default as well.
"""

import ipaddress
import json
import pathlib
import re
import subprocess
import time
import uuid

from plinth import action_utils
from plinth.actions import privileged

CONFIG_DIR = pathlib.Path('/etc/freedombox-gre')
TUNNELS_PATH = CONFIG_DIR / 'tunnels.json'
MSS_PATH = CONFIG_DIR / 'mss.nft'

APPLY_SCRIPT_PATH = '/usr/lib/freedombox-gre/apply.py'
UNIT_PATH = '/etc/systemd/system/freedombox-gre.service'
SERVICE_NAME = 'freedombox-gre'

#: Interface names the kernel accepts and that a human can still read.
NAME_PATTERN = re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{0,14}$')

#: Names that would collide with something the system already owns.
FORBIDDEN_NAMES = frozenset({
    'lo', 'eth0', 'gre', 'gretap', 'ip6gre', 'sit', 'tunl0', 'ip6tnl0',
})

MIN_MTU = 576
MAX_MTU = 65535
DEFAULT_MTU = 1476
DEFAULT_TTL = 64

UNIT_CONTENT = '''[Unit]
Description=FreedomBox GRE tunnels
Documentation=man:ip-link(8)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/bin/python3 {script}

[Install]
WantedBy=multi-user.target
'''.format(script=APPLY_SCRIPT_PATH)

# Kept free of Plinth imports so that a broken or upgrading Plinth cannot stop
# the tunnels from coming back at boot.
APPLY_SCRIPT = '''#!/usr/bin/python3
"""Re-create the GRE tunnels saved by the FreedomBox GRE app."""

import json
import subprocess

TUNNELS_PATH = '/etc/freedombox-gre/tunnels.json'
MSS_PATH = '/etc/freedombox-gre/mss.nft'


def run(arguments):
    """Run a command, ignoring failure."""
    try:
        return subprocess.run(arguments, capture_output=True, text=True,
                              check=False)
    except OSError:
        return None


def link_arguments(tunnel):
    """Build the ip-link command that creates one tunnel."""
    arguments = ['ip', 'link', 'add', tunnel['name'], 'type', 'gre',
                 'remote', tunnel['remote']]
    if tunnel.get('local'):
        arguments += ['local', tunnel['local']]
    if tunnel.get('ttl'):
        arguments += ['ttl', str(tunnel['ttl'])]
    if tunnel.get('key'):
        arguments += ['key', str(tunnel['key'])]
    if tunnel.get('checksum'):
        arguments += ['csum']

    return arguments


def apply_tunnel(tunnel):
    """Recreate one tunnel from scratch."""
    name = tunnel['name']
    run(['ip', 'link', 'del', name])
    result = run(link_arguments(tunnel))
    if result is None or result.returncode != 0:
        return False

    run(['ip', 'link', 'set', 'dev', name, 'mtu', str(tunnel['mtu'])])
    for address in tunnel.get('addresses') or []:
        run(['ip', 'addr', 'replace', address, 'dev', name])
    run(['ip', 'link', 'set', 'dev', name, 'up'])
    return True


def apply_mss(tunnels):
    """Install or remove the TCP MSS clamp used by the tunnels."""
    wanted = [item for item in tunnels if item.get('clamp_mss')]
    if not wanted:
        run(['nft', 'delete', 'table', 'inet', 'fbx_gre_mss'])
        return

    try:
        with open(MSS_PATH, encoding='utf-8') as handle:
            ruleset = handle.read()
    except OSError:
        return

    run(['nft', '-f', MSS_PATH])


def main():
    """Apply every enabled tunnel."""
    run(['modprobe', 'ip_gre'])
    try:
        with open(TUNNELS_PATH, encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return

    tunnels = [item for item in data.get('tunnels') or []
               if isinstance(item, dict) and item.get('enabled')
               and item.get('name') and item.get('remote')]
    for tunnel in tunnels:
        apply_tunnel(tunnel)

    apply_mss(tunnels)


main()
'''

#: Applied after the tunnels exist; ``rt mtu`` picks up the tunnel's own MTU,
#: which is what makes GRE work without hard coding a segment size.
MSS_RULESET = '''table inet fbx_gre_mss
delete table inet fbx_gre_mss
table inet fbx_gre_mss {
    chain post {
        type filter hook postrouting priority mangle; policy accept;
        tcp flags syn tcp option maxseg size set rt mtu
    }
}
'''


def _run(arguments: list[str]):
    """Run a command and capture its output."""
    try:
        return subprocess.run(arguments, capture_output=True, text=True,
                              check=False)
    except OSError:
        return subprocess.CompletedProcess(arguments, 1, '', 'not found')


def _devices() -> list[str]:
    """Return the network interfaces present on the system."""
    process = _run(['ip', '-o', 'link', 'show'])
    names = []
    for line in process.stdout.splitlines():
        parts = line.split(':')
        if len(parts) >= 2:
            names.append(parts[1].strip().split('@')[0])

    return sorted(set(names))


def _local_addresses() -> list[str]:
    """Return the IPv4 addresses configured on this machine."""
    process = _run(['ip', '-o', '-4', 'addr', 'show'])
    addresses = []
    for line in process.stdout.splitlines():
        fields = line.split()
        for index, field in enumerate(fields):
            if field == 'inet' and index + 1 < len(fields):
                addresses.append(fields[index + 1].split('/')[0])

    return sorted(set(addresses))


def read_tunnels() -> list[dict]:
    """Return the saved tunnels, skipping malformed entries."""
    try:
        data = json.loads(TUNNELS_PATH.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []

    if not isinstance(data, dict):
        return []

    tunnels = []
    for item in data.get('tunnels') or []:
        if not isinstance(item, dict) or not item.get('name'):
            continue
        if not item.get('remote'):
            continue

        tunnels.append({
            'id': str(item.get('id') or ''),
            'name': str(item['name']),
            'local': str(item.get('local') or ''),
            'remote': str(item['remote']),
            'addresses': [str(value) for value in item.get('addresses') or []],
            'mtu': int(item.get('mtu') or DEFAULT_MTU),
            'ttl': int(item.get('ttl') or DEFAULT_TTL),
            'key': int(item.get('key') or 0),
            'checksum': bool(item.get('checksum')),
            'clamp_mss': bool(item.get('clamp_mss', True)),
            'enabled': bool(item.get('enabled', True)),
            'comment': str(item.get('comment') or ''),
            'created': int(item.get('created') or 0),
        })

    return tunnels


def _write_tunnels(tunnels: list[dict]):
    """Persist the tunnel list atomically."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    temporary = TUNNELS_PATH.with_suffix('.json.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        json.dump({'version': 1, 'tunnels': tunnels}, handle,
                  ensure_ascii=False, indent=2)
        handle.write('\n')
    temporary.chmod(0o600)
    temporary.replace(TUNNELS_PATH)


def _runtime(name: str) -> dict:
    """Return the live state of one tunnel interface."""
    status = {
        'exists': False,
        'state': '',
        'mtu': '',
        'addresses': [],
        'rx_bytes': 0,
        'tx_bytes': 0,
    }

    process = _run(['ip', '-o', 'link', 'show', 'dev', name])
    if process.returncode != 0 or not process.stdout.strip():
        return status

    status['exists'] = True
    line = process.stdout.strip()
    match = re.search(r'mtu\s+(\d+)', line)
    if match:
        status['mtu'] = match.group(1)
    match = re.search(r'state\s+([A-Z]+)', line)
    if match:
        status['state'] = match.group(1)

    process = _run(['ip', '-o', '-4', 'addr', 'show', 'dev', name])
    for row in process.stdout.splitlines():
        fields = row.split()
        for index, field in enumerate(fields):
            if field == 'inet' and index + 1 < len(fields):
                status['addresses'].append(fields[index + 1])

    for key, counter in (('rx_bytes', 'rx_bytes'), ('tx_bytes', 'tx_bytes')):
        try:
            path = pathlib.Path('/sys/class/net/{}/statistics/{}'.format(
                name, counter))
            status[key] = int(path.read_text().strip())
        except (OSError, ValueError):
            status[key] = 0

    return status


def _validate(tunnel: dict, existing: list[dict], own_id: str = '') -> dict:
    """Check one tunnel and return it in normalised form."""
    name = (tunnel.get('name') or '').strip()
    if not NAME_PATTERN.match(name):
        raise ValueError(
            '隧道名称只能包含字母、数字、下划线和短横线，'
            '必须以字母开头，长度不超过 15 个字符')
    if name in FORBIDDEN_NAMES:
        raise ValueError('隧道名称 {} 是系统保留名，请换一个'.format(name))

    for item in existing:
        if item['name'] == name and item['id'] != own_id:
            raise ValueError('已经存在名为 {} 的隧道'.format(name))

    own_name = _find(existing, own_id)['name'] if own_id else ''
    if name != own_name and name in _devices():
        raise ValueError(
            '系统里已经存在名为 {} 的网卡，请换一个名称'.format(name))

    remote = (tunnel.get('remote') or '').strip()
    try:
        remote_address = ipaddress.IPv4Address(remote)
    except ValueError as exception:
        raise ValueError(
            '远端地址必须是 IPv4 地址，例如 203.0.113.10') from exception

    local = (tunnel.get('local') or '').strip()
    if local:
        try:
            local_address = ipaddress.IPv4Address(local)
        except ValueError as exception:
            raise ValueError(
                '本地地址必须是 IPv4 地址，例如 10.10.173.19') from exception
        if local_address == remote_address:
            raise ValueError('本地地址与远端地址不能相同')
        if str(local_address) not in _local_addresses():
            raise ValueError(
                '本地地址 {} 不在本机任何网卡上。请先确认该地址已经配置好，'
                '或留空让内核自动选择源地址。'.format(local_address))
        local = str(local_address)

    addresses = []
    for value in tunnel.get('addresses') or []:
        text = str(value).strip()
        if not text:
            continue
        if '/' not in text:
            raise ValueError(
                '隧道地址需要写明前缀长度，例如 10.0.0.1/30')
        try:
            interface = ipaddress.ip_interface(text)
        except ValueError as exception:
            raise ValueError('隧道地址格式不正确：{}'.format(text)) from exception
        if interface.version != 4:
            raise ValueError('隧道地址目前只支持 IPv4')
        addresses.append(str(interface))

    mtu = int(tunnel.get('mtu') or DEFAULT_MTU)
    if mtu < MIN_MTU or mtu > MAX_MTU:
        raise ValueError(
            'MTU 必须在 {} 到 {} 之间。GRE 有 24 字节以上开销，'
            '超过 1476 时大包会被丢弃。'.format(MIN_MTU, MAX_MTU))

    ttl = int(tunnel.get('ttl') or 0)
    if ttl < 0 or ttl > 255:
        raise ValueError('TTL 必须在 0 到 255 之间，0 表示使用内核默认值')

    key = int(tunnel.get('key') or 0)
    if key < 0 or key > 4294967295:
        raise ValueError('GRE Key 必须是 0 到 4294967295 之间的整数，0 表示不使用')

    return {
        'name': name,
        'local': local,
        'remote': str(remote_address),
        'addresses': addresses,
        'mtu': mtu,
        'ttl': ttl,
        'key': key,
        'checksum': bool(tunnel.get('checksum')),
        'clamp_mss': bool(tunnel.get('clamp_mss', True)),
        'enabled': bool(tunnel.get('enabled', True)),
        'comment': (tunnel.get('comment') or '').strip()[:120],
    }


def _find(tunnels: list[dict], tunnel_id: str) -> dict:
    """Return one tunnel by id or raise."""
    for item in tunnels:
        if item['id'] == tunnel_id:
            return item

    raise ValueError('没有找到这条隧道，可能已经被删除')


def _delete_link(name: str):
    """Remove the interface, tolerating its absence."""
    _run(['ip', 'link', 'del', name])


def _apply(tunnel: dict) -> str:
    """Create the interface and return an error message, empty on success."""
    _delete_link(tunnel['name'])

    process = _run(['ip', 'link', 'add', tunnel['name'], 'type', 'gre',
                    'remote', tunnel['remote']]
                   + (['local', tunnel['local']] if tunnel['local'] else [])
                   + (['ttl', str(tunnel['ttl'])] if tunnel['ttl'] else [])
                   + (['key', str(tunnel['key'])] if tunnel['key'] else [])
                   + (['csum'] if tunnel['checksum'] else []))
    if process.returncode != 0:
        return process.stderr.strip() or process.stdout.strip() \
            or '内核拒绝创建该隧道'

    _run(['ip', 'link', 'set', 'dev', tunnel['name'], 'mtu',
          str(tunnel['mtu'])])
    for address in tunnel['addresses']:
        _run(['ip', 'addr', 'replace', address, 'dev', tunnel['name']])
    _run(['ip', 'link', 'set', 'dev', tunnel['name'], 'up'])
    return ''


def _apply_mss(tunnels: list[dict]):
    """Keep the MSS clamp in sync with the saved tunnels."""
    wanted = [item for item in tunnels if item['clamp_mss'] and item['enabled']]
    if not wanted:
        _run(['nft', 'delete', 'table', 'inet', 'fbx_gre_mss'])
        return

    path = pathlib.Path(MSS_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(MSS_RULESET, encoding='utf-8')
    path.chmod(0o644)
    _run(['nft', '-f', str(path)])


# --------------------------------------------------------------------------- #
# firewalld
#
# A GRE tunnel is useless if the firewall drops the encapsulated packets: the
# peer's GRE frames arrive on the physical interface, in whatever zone that
# interface sits in, and firewalld rejects everything it was not told about.
# firewalld has no GRE service definition (GRE is IP protocol 47, neither TCP
# nor UDP), so the rule has to be a rich rule, and it is scoped to the
# configured peer address — opening protocol 47 to the whole internet would
# let anybody hand us encapsulated traffic.
#
# Accepting protocol 47 is only half of it.  Packets that arrive over the
# tunnel and leave through the LAN are *forwarded*, and firewalld forwards
# only between interfaces whose zones it can pair: it builds one rule per
# (incoming interface, outgoing interface) pair and ends the chain with a
# reject.  An interface that sits in no zone is part of no pair, so everything
# it receives is refused with "admin prohibited" — the tunnel looks up, the
# peer still cannot reach a single host behind us.  The tunnel interface is
# therefore placed in a zone as well; ``internal`` is where FreedomBox keeps
# the LAN, and firewalld forwards freely inside one zone.
# --------------------------------------------------------------------------- #

FIREWALL_PATH = CONFIG_DIR / 'firewall.json'

#: Zone a tunnel interface is placed in when it does not have one already.
TUNNEL_ZONE = 'internal'


def _firewalld_active() -> bool:
    """Return whether firewalld is managing the packet filter."""
    process = _run(['systemctl', 'is-active', 'firewalld'])
    return process.stdout.strip() == 'active'


def _zone_of(interface: str) -> str:
    """Return the zone an interface belongs to, empty when it has none."""
    zone = _run(['firewall-cmd',
                 '--get-zone-of-interface=' + interface]).stdout.strip()
    return '' if zone in ('', 'no zone') else zone


def _zone_exists(zone: str) -> bool:
    """Return whether *zone* is a zone firewalld knows about."""
    return not _run(['firewall-cmd', '--permanent', '--zone=' + zone,
                     '--list-all']).returncode


def _zone_for_remote(remote: str) -> str:
    """Return the zone that packets coming back from *remote* land in."""
    fields = _run(['ip', '-o', 'route', 'get', remote]).stdout.split()
    device = ''
    if 'dev' in fields:
        index = fields.index('dev')
        if index + 1 < len(fields):
            device = fields[index + 1]

    if device:
        zone = _run(['firewall-cmd',
                     '--get-zone-of-interface=' + device]).stdout.strip()
        if zone and zone != 'no zone':
            return zone

    return _run(['firewall-cmd', '--get-default-zone']).stdout.strip()


def _gre_rule(remote: str) -> str:
    """Return the rich rule that accepts GRE from exactly one peer."""
    return ('rule family="ipv4" source address="{}" protocol value="47" '
            'accept'.format(remote))


def _read_firewall() -> dict:
    """Return what this app added to firewalld last time.

    ``rules`` are the rich rules that accept GRE from a peer, ``zones`` the
    interface-to-zone pairings that let forwarded traffic leave the tunnel.
    Older versions only ever wrote ``rules``, hence the empty defaults.
    """
    empty = {'rules': [], 'zones': []}
    try:
        data = json.loads(FIREWALL_PATH.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return empty

    if not isinstance(data, dict):
        return empty

    return {
        'rules': [item for item in data.get('rules') or []
                  if isinstance(item, dict) and item.get('zone')
                  and item.get('rule')],
        'zones': [item for item in data.get('zones') or []
                  if isinstance(item, dict) and item.get('interface')
                  and item.get('zone')],
    }


def _write_firewall(rules: list[dict], zones: list[dict]):
    """Remember which rules this app owns, so they can be withdrawn later."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with FIREWALL_PATH.open('w', encoding='utf-8') as handle:
        json.dump({'rules': rules, 'zones': zones}, handle,
                  ensure_ascii=False, indent=2)
        handle.write('\n')
    FIREWALL_PATH.chmod(0o600)


def _sync_firewall(tunnels: list[dict]):
    """Let firewalld accept GRE from the peers and forward what arrives.

    Declarative on purpose: the rules recorded from the previous run are
    withdrawn first and the ones the current list needs are added back, so a
    deleted tunnel or a changed peer address cannot leave a stale hole behind.
    """
    if not _firewalld_active():
        return

    previous = _read_firewall()
    changed = False

    # Withdraw the rich rules; they are cheap to re-add and the peer address
    # may have changed, so no comparison is worth the bookkeeping.
    for item in previous['rules']:
        _run(['firewall-cmd', '--permanent', '--zone=' + item['zone'],
              '--remove-rich-rule=' + item['rule']])
        changed = True

    # Work out the zone every enabled tunnel should sit in before touching
    # anything.  A tunnel that already has a zone keeps it: an administrator
    # who moved an interface made a decision this app must not silently undo.
    wanted_zones = {}
    for tunnel in tunnels:
        if not tunnel['enabled']:
            continue
        zone = _zone_of(tunnel['name']) or TUNNEL_ZONE
        if _zone_exists(zone):
            wanted_zones[tunnel['name']] = zone

    # Withdraw only the pairings that are no longer wanted, and ask firewalld
    # for the permanent state rather than trusting our own bookkeeping: the
    # runtime zone is stale until the reload at the end of this function.
    for item in previous['zones']:
        if wanted_zones.get(item['interface']) == item['zone']:
            continue
        _run(['firewall-cmd', '--permanent', '--zone=' + item['zone'],
              '--remove-interface=' + item['interface']])
        changed = True

    recorded = {(item['interface'], item['zone']) for item in previous['zones']}
    assigned = []
    for name, zone in sorted(wanted_zones.items()):
        added = bool(_run(['firewall-cmd', '--permanent', '--zone=' + zone,
                           '--query-interface=' + name]).returncode)
        if added:
            _run(['firewall-cmd', '--permanent', '--zone=' + zone,
                  '--add-interface=' + name])
            changed = True

        # Record the pairing when this app added it, or when it added it on an
        # earlier run; a zone the user picked by hand is never recorded and
        # therefore never removed.
        if added or (name, zone) in recorded:
            assigned.append({'interface': name, 'zone': zone})

    applied = []
    seen = set()
    for tunnel in tunnels:
        if not tunnel['enabled'] or not tunnel['remote']:
            continue
        zone = _zone_for_remote(tunnel['remote'])
        rule = _gre_rule(tunnel['remote'])
        if not zone or (zone, rule) in seen:
            continue
        seen.add((zone, rule))
        _run(['firewall-cmd', '--permanent', '--zone=' + zone,
              '--add-rich-rule=' + rule])
        applied.append({'zone': zone, 'rule': rule})
        changed = True

    _write_firewall(applied, assigned)
    if changed:
        _run(['firewall-cmd', '--reload'])


def _sync_state(tunnels: list[dict]):
    """Re-apply everything that is derived from the tunnel list."""
    _apply_mss(tunnels)
    try:
        _sync_firewall(tunnels)
    except Exception:  # noqa: BLE001 - a firewall hiccup must not fail the save
        # The tunnel itself is already in place; failing the whole operation
        # here would leave the user staring at an error for a working tunnel.
        pass


def _write_apply_script():
    """Install the helper that restores the tunnels at boot."""
    path = pathlib.Path(APPLY_SCRIPT_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(APPLY_SCRIPT, encoding='utf-8')
    path.chmod(0o755)


def _write_unit():
    """Install the systemd unit that runs the helper at boot."""
    path = pathlib.Path(UNIT_PATH)
    path.write_text(UNIT_CONTENT, encoding='utf-8')
    path.chmod(0o644)
    action_utils.service_daemon_reload()


@privileged
def setup():
    """Create the configuration, the helper and the unit."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not TUNNELS_PATH.exists():
        _write_tunnels([])

    _write_apply_script()
    _write_unit()
    action_utils.service_enable(SERVICE_NAME)
    action_utils.service_start(SERVICE_NAME)


@privileged
def get_devices() -> list[str]:
    """Return the interfaces a tunnel could be bound to."""
    return _devices()


@privileged
def get_tunnels() -> dict:
    """Return the saved tunnels together with their live state."""
    tunnels = read_tunnels()
    rows = []
    for tunnel in tunnels:
        row = dict(tunnel)
        row.update(_runtime(tunnel['name']))
        row['suggested'] = ''
        rows.append(row)

    return {
        'tunnels': rows,
        'devices': _devices(),
        'local_addresses': _local_addresses(),
        'suggested_name': _suggest_name(tunnels),
        'gre_available': _run(['modprobe', '-n', 'ip_gre']).returncode == 0,
    }


def _suggest_name(tunnels: list[dict]) -> str:
    """Return the first free greN name."""
    used = {item['name'] for item in tunnels}
    for index in range(1, 100):
        candidate = 'gre{}'.format(index)
        if candidate not in used and candidate not in _devices():
            return candidate

    return 'gre99'


@privileged
def add_tunnel(name: str, local: str, remote: str, addresses: list[str],
               mtu: int, ttl: int, key: int, checksum: bool, clamp_mss: bool,
               enabled: bool, comment: str) -> dict:
    """Validate, create and save a new tunnel."""
    tunnels = read_tunnels()
    tunnel = _validate({
        'name': name,
        'local': local,
        'remote': remote,
        'addresses': addresses,
        'mtu': mtu,
        'ttl': ttl,
        'key': key,
        'checksum': checksum,
        'clamp_mss': clamp_mss,
        'enabled': enabled,
        'comment': comment,
    }, tunnels)

    if tunnel['enabled']:
        problem = _apply(tunnel)
        if problem:
            raise ValueError('创建隧道失败：{}'.format(problem))

    tunnel['id'] = uuid.uuid4().hex
    tunnel['created'] = int(time.time())
    tunnels.append(tunnel)
    _write_tunnels(tunnels)
    _sync_state(tunnels)
    return tunnel


@privileged
def update_tunnel(tunnel_id: str, name: str, local: str, remote: str,
                  addresses: list[str], mtu: int, ttl: int, key: int,
                  checksum: bool, clamp_mss: bool, enabled: bool,
                  comment: str) -> dict:
    """Rewrite one tunnel in place."""
    tunnels = read_tunnels()
    current = _find(tunnels, tunnel_id)
    tunnel = _validate({
        'name': name,
        'local': local,
        'remote': remote,
        'addresses': addresses,
        'mtu': mtu,
        'ttl': ttl,
        'key': key,
        'checksum': checksum,
        'clamp_mss': clamp_mss,
        'enabled': enabled,
        'comment': comment,
    }, tunnels, own_id=tunnel_id)

    if current['name'] != tunnel['name']:
        _delete_link(current['name'])

    if tunnel['enabled']:
        problem = _apply(tunnel)
        if problem:
            raise ValueError('修改隧道失败：{}'.format(problem))
    else:
        _delete_link(tunnel['name'])

    tunnel['id'] = tunnel_id
    tunnel['created'] = current['created']
    tunnels = [tunnel if item['id'] == tunnel_id else item for item in tunnels]
    _write_tunnels(tunnels)
    _sync_state(tunnels)
    return tunnel


@privileged
def delete_tunnel(tunnel_id: str) -> dict:
    """Remove a tunnel from the kernel and from the saved list."""
    tunnels = read_tunnels()
    target = _find(tunnels, tunnel_id)

    _delete_link(target['name'])
    tunnels = [item for item in tunnels if item['id'] != tunnel_id]
    _write_tunnels(tunnels)
    _sync_state(tunnels)
    return target


@privileged
def set_enabled(tunnel_id: str, enabled: bool) -> dict:
    """Bring one tunnel up or down without touching its settings."""
    tunnels = read_tunnels()
    target = _find(tunnels, tunnel_id)
    target['enabled'] = bool(enabled)

    if target['enabled']:
        problem = _apply(target)
        if problem:
            raise ValueError('启用隧道失败：{}'.format(problem))
    else:
        _delete_link(target['name'])

    _write_tunnels(tunnels)
    _sync_state(tunnels)
    return target


@privileged
def uninstall():
    """Remove every tunnel, the helper and the unit."""
    tunnels = read_tunnels()
    for tunnel in tunnels:
        _delete_link(tunnel['name'])

    _run(['nft', 'delete', 'table', 'inet', 'fbx_gre_mss'])
    _sync_firewall([])

    action_utils.service_disable(SERVICE_NAME)
    try:
        pathlib.Path(UNIT_PATH).unlink()
    except OSError:
        pass

    try:
        pathlib.Path(APPLY_SCRIPT_PATH).unlink()
    except OSError:
        pass

    action_utils.service_daemon_reload()
    for directory in (CONFIG_DIR, pathlib.Path(APPLY_SCRIPT_PATH).parent):
        try:
            directory.rmdir()
        except OSError:
            pass
