# SPDX-License-Identifier: AGPL-3.0-or-later
"""URLs for the GRE tunnel module."""

from django.urls import re_path

from . import views

urlpatterns = [
    re_path(r'^sys/gre/$', views.GreAppView.as_view(), name='index'),
    re_path(r'^sys/gre/action/$', views.GreTunnelActionView.as_view(),
            name='action'),
]
