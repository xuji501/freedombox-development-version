# SPDX-License-Identifier: AGPL-3.0-or-later
"""Views for the GRE tunnel app."""

import logging

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect
from django.urls import NoReverseMatch, reverse
from django.views.generic import View

from plinth.views import AppView

from . import privileged, submenu
from .forms import GreTunnelForm

logger = logging.getLogger(__name__)


def _module_url(name: str, fallback: str) -> str:
    """Resolve a URL of this module, tolerating a missing namespace."""
    try:
        return reverse('gre:{}'.format(name))
    except NoReverseMatch:
        return fallback


def _index_url() -> str:
    """Return the URL of the app page."""
    return _module_url('index', '/plinth/sys/gre/')


class GreAppView(AppView):
    """List the tunnels and offer a form to add or edit one."""

    app_id = 'gre'
    template_name = 'gre.html'
    form_class = GreTunnelForm

    def _tunnels(self):
        """Return the saved tunnels, tolerating a broken configuration."""
        try:
            return privileged.get_tunnels()
        except Exception:
            logger.exception('Unable to read the tunnel list')
            return {
                'tunnels': [],
                'devices': [],
                'local_addresses': [],
                'suggested_name': 'gre1',
                'gre_available': False,
            }

    def get_initial(self):
        """Pre-fill the form when the page is opened in edit mode."""
        initial = super().get_initial()
        tunnel_id = (self.request.GET.get('edit') or '').strip()
        if not tunnel_id:
            return initial

        for tunnel in self._tunnels()['tunnels']:
            if tunnel['id'] != tunnel_id:
                continue

            initial.update({
                'tunnel_id': tunnel['id'],
                'name': tunnel['name'],
                'local': tunnel['local'],
                'remote': tunnel['remote'],
                'address': ' '.join(tunnel['addresses']),
                'mtu': tunnel['mtu'],
                'ttl': tunnel['ttl'],
                'key': tunnel['key'],
                'checksum': tunnel['checksum'],
                'clamp_mss': tunnel['clamp_mss'],
                'enabled': tunnel['enabled'],
                'comment': tunnel['comment'],
            })
            break

        return initial

    def get_context_data(self, **kwargs):
        """Expose the tunnels, their live state and the action URLs."""
        context = super().get_context_data(**kwargs)
        data = self._tunnels()

        context['tunnels'] = data['tunnels']
        context['local_addresses'] = data['local_addresses']
        context['gre_available'] = data['gre_available']
        context['subsubmenu'] = submenu.entries(self.request)
        context['editing'] = bool((self.request.GET.get('edit') or '').strip())
        context['action_url'] = _module_url('action', '/plinth/sys/gre/action/')
        context['index_url'] = _index_url()
        return context

    def form_valid(self, form):
        """Create or rewrite the tunnel described by the form."""
        data = form.cleaned_data
        addresses = [value for value in
                     (data.get('address') or '').replace(',', ' ').split()
                     if value]

        common = dict(
            name=data['name'],
            local=data.get('local') or '',
            remote=data['remote'],
            addresses=addresses,
            mtu=int(data.get('mtu') or 1476),
            ttl=int(data.get('ttl') or 0),
            key=int(data.get('key') or 0),
            checksum=bool(data.get('checksum')),
            clamp_mss=bool(data.get('clamp_mss')),
            enabled=bool(data.get('enabled')),
            comment=data.get('comment') or '',
        )

        tunnel_id = (data.get('tunnel_id') or '').strip()
        try:
            if tunnel_id:
                tunnel = privileged.update_tunnel(tunnel_id=tunnel_id, **common)
                messages.success(
                    self.request,
                    '已保存隧道 {}（{} → {}）。'.format(
                        tunnel['name'], tunnel['local'] or '自动',
                        tunnel['remote']))
            else:
                tunnel = privileged.add_tunnel(**common)
                messages.success(
                    self.request,
                    '已创建隧道 {}（{} → {}）。'.format(
                        tunnel['name'], tunnel['local'] or '自动',
                        tunnel['remote']))
        except Exception as exception:
            logger.exception('Unable to save the tunnel')
            messages.error(self.request, '保存失败：{}'.format(exception))
            return self.form_invalid(form)

        return redirect(_index_url())


class GreTunnelActionView(LoginRequiredMixin, View):
    """Delete a tunnel, or bring one up and down."""

    def post(self, request):
        """Dispatch on the ``action`` field posted by the page."""
        tunnel_id = (request.POST.get('tunnel_id') or '').strip()
        action = (request.POST.get('action') or '').strip()

        try:
            if action == 'delete':
                tunnel = privileged.delete_tunnel(tunnel_id)
                messages.success(request,
                                 '已删除隧道 {}。'.format(tunnel['name']))
            elif action in ('enable', 'disable'):
                tunnel = privileged.set_enabled(tunnel_id,
                                                action == 'enable')
                messages.success(
                    request, '已{}隧道 {}。'.format(
                        '启用' if action == 'enable' else '停用',
                        tunnel['name']))
            else:
                messages.error(request, '未知操作：{}'.format(action))
        except Exception as exception:
            logger.exception('Unable to run the tunnel action')
            messages.error(request, '操作失败：{}'.format(exception))

        return redirect(_index_url())

    def get(self, request):
        """Only POST is meaningful, so send the browser back to the page."""
        return redirect(_index_url())
