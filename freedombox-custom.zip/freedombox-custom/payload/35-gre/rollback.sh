#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 卸载 GRE 隧道模块，恢复到安装前的状态。
#
# 用法：sudo bash rollback.sh [备份目录]
#
# 不传备份目录时自动使用 /root/freedombox-gre-module-backup 下最新的一份。
#
# 卸载顺序是有讲究的：先停服务、删 unit，再删重建脚本，最后才动隧道清单。
# 否则 systemd 可能在半途用残留脚本把网卡又建回来。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/gre
ENABLED_DIR=/etc/freedombox/modules-enabled
CONFIG_DIR=/etc/freedombox-gre
APPLY_DIR=/usr/lib/freedombox-gre
UNIT_FILE=/etc/systemd/system/freedombox-gre.service
SERVICE=freedombox-gre
BACKUP_ROOT=/root/freedombox-gre-module-backup

BACKUP_DIR=${1:-}
if [ -z "$BACKUP_DIR" ]; then
    BACKUP_DIR=$(ls -1d "$BACKUP_ROOT"/*/ 2>/dev/null | sort | tail -1)
    BACKUP_DIR=${BACKUP_DIR%/}
fi

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

echo "=============================================="
echo " FreedomBox GRE 隧道模块卸载"
echo "=============================================="

echo ""
echo "== 1/6 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR" ]; then
    echo "使用备份目录：$BACKUP_DIR"
else
    echo "未找到备份目录，将按「全新安装」处理（不还原任何旧文件）"
    BACKUP_DIR=''
fi

echo ""
echo "== 2/6 停止并移除服务 =="
systemctl stop "$SERVICE" 2>/dev/null || true
systemctl disable "$SERVICE" 2>/dev/null || true
rm -f "$UNIT_FILE"
systemctl daemon-reload 2>/dev/null || true
echo "已停止服务并删除 unit"

echo ""
echo "== 3/6 删除隧道网卡 =="
if [ -f "$CONFIG_DIR/tunnels.json" ]; then
    python3 - "$CONFIG_DIR/tunnels.json" <<'PYEOF'
import json
import subprocess
import sys

try:
    with open(sys.argv[1], encoding='utf-8') as handle:
        data = json.load(handle)
except Exception:
    data = {}

removed = 0
for item in data.get('tunnels') or []:
    name = (item or {}).get('name')
    if not name:
        continue
    result = subprocess.run(['ip', 'link', 'del', name],
                            capture_output=True, text=True)
    if result.returncode == 0:
        print('  已删除网卡 {}'.format(name))
        removed += 1

if not removed:
    print('  没有需要删除的网卡')
PYEOF
else
    echo "  未找到隧道清单，跳过"
fi

echo ""
echo "== 4/6 移除 MSS 钳制规则 =="
if nft delete table inet fbx_gre_mss 2>/dev/null; then
    echo "已删除 nft 表 inet fbx_gre_mss"
else
    echo "nft 表不存在，跳过"
fi

echo ""
echo "== 5/6 删除开机重建脚本与配置 =="
rm -rf "$APPLY_DIR"
echo "已删除 $APPLY_DIR"

if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/config" ]; then
    rm -rf "$CONFIG_DIR"
    cp -a "$BACKUP_DIR/config" "$CONFIG_DIR"
    echo "已恢复安装前的隧道清单"
else
    rm -rf "$CONFIG_DIR"
    echo "已删除 $CONFIG_DIR"
fi

echo ""
echo "== 6/6 移除模块代码与启用标记 =="
rm -f "$ENABLED_DIR/gre"
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/module" ]; then
    rm -rf "$MODULE_DIR"
    cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
    echo "已恢复原有模块目录"
else
    rm -rf "$MODULE_DIR"
    echo "已移除模块目录"
fi

if [ -n "$BACKUP_DIR" ] && [ -f "$BACKUP_DIR/enabled-gre" ]; then
    cp -a "$BACKUP_DIR/enabled-gre" "$ENABLED_DIR/gre"
    echo "已恢复原有启用标记"
fi

systemctl restart plinth 2>/dev/null || true
sleep 3

echo ""
echo "== 卸载结果 =="
echo "Plinth 状态：$(systemctl is-active plinth 2>/dev/null || echo 未知)"
echo "服务状态：$(systemctl is-active "$SERVICE" 2>/dev/null || echo 已移除)"
echo ""
echo "当前网卡：$(ip -o link show | awk -F': ' '{print $2}' | tr '\n' ' ')"
echo ""
echo "提示：对端设备上的隧道不会自动删除，需要在对端手工清理。"
echo "=============================================="
