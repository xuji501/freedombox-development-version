"""Run the first-time setup for the GRE tunnel app.

Called by install.sh as root.

Plinth only re-runs setup for apps that already have a version recorded, or for
essential apps, so a freshly added non-essential app is never set up
automatically.  This script does the same work the app's setup() method does,
but calls the private helpers directly instead of going through the privileged
action dispatcher: we are already root, and the dispatcher would try to spawn
sudo for no benefit.

Deliberately does not call app.setup(): the generic App.setup() would also run
the package component, which needs a Plinth operation context that does not
exist outside the web process.
"""

from plinth import web_framework

web_framework.init()

from plinth import action_utils  # noqa: E402
from plinth import app as app_module  # noqa: E402
from plinth import module_loader  # noqa: E402
from plinth.modules.gre import privileged  # noqa: E402

module_loader.load_modules()
app_module.apps_init()

# Configuration file, boot time helper and systemd unit.
privileged.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
if not privileged.TUNNELS_PATH.exists():
    privileged._write_tunnels([])
    print('已创建空的隧道配置:', privileged.TUNNELS_PATH)
else:
    print('保留已有的隧道配置:', privileged.TUNNELS_PATH,
          len(privileged.read_tunnels()), '条')

privileged._write_apply_script()
print('已安装开机恢复脚本:', privileged.APPLY_SCRIPT_PATH)

privileged._write_unit()
print('已安装 systemd unit:', privileged.UNIT_PATH)

action_utils.service_enable(privileged.SERVICE_NAME)
action_utils.service_start(privileged.SERVICE_NAME)
print('服务已启用并启动:', privileged.SERVICE_NAME)

app = app_module.App.get('gre')
app.set_setup_version(app.info.version)
app.enable()

print('setup 版本:', app.get_setup_version(), '/', app.info.version)
print('应用已启用:', app.is_enabled())

tunnels = privileged.read_tunnels()
print('已保存的隧道 {} 条'.format(len(tunnels)))
for tunnel in tunnels:
    runtime = privileged._runtime(tunnel['name'])
    print('  {:<8s} {} -> {} mtu={} {}'.format(
        tunnel['name'], tunnel['local'] or 'auto', tunnel['remote'],
        tunnel['mtu'], '运行中' if runtime['exists'] else '未创建'))
