#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 撤掉 install.sh 写入的 404 修复。
#
# 用法：
#   sudo bash rollback.sh                                  # 只移除补丁块
#   sudo bash rollback.sh /root/freedombox-fixes-backup/20261028-123000
#                                                          # 用备份整体还原

set -euo pipefail

VIEWS=/usr/lib/python3/dist-packages/plinth/views.py
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
FIX_SCRIPT=$SCRIPT_DIR/fix_404.py

fail() {
    echo "错误：$1" >&2
    exit 1
}

[ "$(id -u)" -eq 0 ] || fail "请用 root 运行（sudo bash rollback.sh）"

if [ $# -ge 1 ]; then
    BACKUP=$1/views.py
    [ -f "$BACKUP" ] || fail "备份不存在：$BACKUP"
    cp -a "$BACKUP" "$VIEWS"
    echo "已从 $BACKUP 还原"
else
    [ -f "$FIX_SCRIPT" ] || fail "找不到 $FIX_SCRIPT"
    python3 "$FIX_SCRIPT" uninstall
fi

python3 -m py_compile "$VIEWS"
echo "语法正常"

systemctl restart plinth
sleep 4

if systemctl is-active --quiet plinth; then
    CODE=$(curl -sk -o /dev/null -w '%{http_code}' \
        https://127.0.0.1/plinth/this-page-should-not-exist/ 2>/dev/null \
        || echo 000)
    echo "Plinth 运行正常，不存在的地址当前返回 HTTP $CODE"
else
    fail "Plinth 未能启动，请检查 journalctl -u plinth"
fi
