#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 修复 Plinth 的「404 变 500」缺陷。
#
# 症状：访问任何不存在的地址返回 500，而不是 404 页面。
# 根因：plinth/views.py 的 get_breadcrumbs() 直接读取
#       request.resolver_match.url_name，而 404 请求没有 resolver_match，
#       抛 AttributeError，把 404 响应变成了 500。
#
# 用法：
#   sudo bash install.sh      # 打补丁（幂等，可重复执行）
#   sudo bash rollback.sh     # 撤掉补丁

set -euo pipefail

VIEWS=/usr/lib/python3/dist-packages/plinth/views.py
BACKUP_DIR=/root/freedombox-fixes-backup
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
FIX_SCRIPT=$SCRIPT_DIR/fix_404.py

fail() {
    echo "错误：$1" >&2
    exit 1
}

[ "$(id -u)" -eq 0 ] || fail "请用 root 运行（sudo bash install.sh）"
[ -f "$VIEWS" ] || fail "找不到 $VIEWS，确认已安装 freedombox"
[ -f "$FIX_SCRIPT" ] || fail "找不到 $FIX_SCRIPT"

echo "== 1/5 备份原文件 =="
STAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$BACKUP_DIR/$STAMP"
cp -a "$VIEWS" "$BACKUP_DIR/$STAMP/views.py"
echo "已备份到 $BACKUP_DIR/$STAMP/views.py"

echo ""
echo "== 2/5 写入补丁 =="
python3 "$FIX_SCRIPT" install

echo ""
echo "== 3/5 语法检查 =="
python3 -m py_compile "$VIEWS"
echo "语法正常"

echo ""
echo "== 4/5 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if ! systemctl is-active --quiet plinth; then
    echo "Plinth 未能启动，正在回滚..." >&2
    cp -a "$BACKUP_DIR/$STAMP/views.py" "$VIEWS"
    systemctl restart plinth || true
    fail "已回滚到打补丁前的版本"
fi
echo "Plinth 运行正常"

echo ""
echo "== 5/5 验证 =="
CODE=$(curl -sk -o /tmp/fix404-check.html -w '%{http_code}' \
    https://127.0.0.1/plinth/this-page-should-not-exist/ 2>/dev/null || echo 000)
echo "访问不存在的地址 -> HTTP $CODE（期望 404）"

if [ "$CODE" = "404" ] && grep -q '404' /tmp/fix404-check.html; then
    echo "修复生效：404 页面正常返回"
else
    echo "警告：状态码不是 404，请检查" >&2
    rm -f /tmp/fix404-check.html
    exit 1
fi

# 正常页面必须不受影响
for path in / /apps/ /accounts/login/; do
    PAGE_CODE=$(curl -sk -o /dev/null -w '%{http_code}' \
        "https://127.0.0.1/plinth$path" 2>/dev/null || echo 000)
    echo "  $path -> $PAGE_CODE"
done
rm -f /tmp/fix404-check.html
