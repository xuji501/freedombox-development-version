"""Fix the 404-into-500 defect in Plinth's breadcrumb helper.

``plinth.views.get_breadcrumbs()`` reads ``request.resolver_match.url_name``
without checking for ``None``.  A request that never resolved to a view --
which is exactly the case for a 404 -- has no resolver match, so the
``AttributeError`` raised there replaces the 404 response with a 500.

The patch inserts an early return that falls back to the home menu entry,
so the error page renders normally.  It is wrapped in marker comments so the
script can be re-run after a ``freedombox`` package upgrade, which restores
the original file.
"""

import pathlib
import re
import sys

VIEWS = pathlib.Path('/usr/lib/python3/dist-packages/plinth/views.py')

MARKER_START = '    # plinth-fix-404:start'
MARKER_END = '    # plinth-fix-404:end'

ANCHOR = '    url_name = request.resolver_match.url_name'

PATCH = '''{start}
    if not request.resolver_match:
        # A request that never resolved to a view (a 404, or an error raised
        # before URL resolution) has no resolver match.  Reading url_name
        # from it raises AttributeError, which turns the 404 into a 500.
        # Fall back to the home entry so the error page can still render.
        try:
            home_item = menu.Menu.get_with_url_name('index')
        except LookupError:
            return breadcrumbs

        _add(home_item.url, home_item.name, home_item.url_name)
        breadcrumbs[home_item.url]['is_active_section'] = True
        return breadcrumbs
{end}

'''.format(start=MARKER_START, end=MARKER_END)

BLOCK_PATTERN = re.compile(
    re.escape(MARKER_START) + r'.*?' + re.escape(MARKER_END) + r'\n\n',
    re.DOTALL)


def remove(text: str) -> tuple[str, bool]:
    """Strip an existing patch, returning the new text and whether it hit."""
    new_text, count = BLOCK_PATTERN.subn('', text)
    return new_text, bool(count)


def install() -> int:
    text = VIEWS.read_text(encoding='utf-8')

    if MARKER_START in text:
        text, _ = remove(text)
        print('已存在旧补丁，先移除再重新写入')

    if text.count(ANCHOR) != 1:
        print('锚点出现 {} 次，与预期不符，放弃修改'.format(
            text.count(ANCHOR)), file=sys.stderr)
        return 1

    text = text.replace(ANCHOR, PATCH + ANCHOR, 1)
    VIEWS.write_text(text, encoding='utf-8')
    print('已写入 404 修复 ->', VIEWS)
    return 0


def uninstall() -> int:
    text = VIEWS.read_text(encoding='utf-8')
    text, removed = remove(text)
    if not removed:
        print('未发现补丁，无需处理')
        return 0

    VIEWS.write_text(text, encoding='utf-8')
    print('已移除 404 修复 ->', VIEWS)
    return 0


if __name__ == '__main__':
    action = sys.argv[1] if len(sys.argv) > 1 else 'install'
    sys.exit(uninstall() if action == 'uninstall' else install())
