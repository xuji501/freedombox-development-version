# Plinth 缺陷修复

## 404 变 500

### 现象

访问任何不存在的地址，返回的是 **500 Internal Server Error**，而不是 404 页面。

### 根因

`plinth/views.py` 的 `get_breadcrumbs()`：

```python
url_name = request.resolver_match.url_name
full_url_name = ':'.join(request.resolver_match.app_names + [url_name])
```

这个函数挂在 `plinth.context_processors.common` 里，**每个页面渲染时都会调用**。
而一个没有解析到视图的请求（正是 404 的情形）`request.resolver_match` 是 `None`，
于是抛 `AttributeError`：

```
File "/usr/lib/python3/dist-packages/plinth/context_processors.py", line 27, in common
    breadcrumbs = views.get_breadcrumbs(request)
File "/usr/lib/python3/dist-packages/plinth/views.py", line 78, in get_breadcrumbs
    url_name = request.resolver_match.url_name
AttributeError: 'NoneType' object has no attribute 'url_name'
```

Django 渲染 404 模板时同样要过一遍 context processor，于是 404 又被这个异常
顶成了 500 —— 用户永远看不到那个精心写的 404 页面。

### 修复

在读取 `resolver_match` 之前加一个空值保护，退回到「首页」这一个面包屑：

```python
# plinth-fix-404:start
if not request.resolver_match:
    # A request that never resolved to a view (a 404, or an error raised
    # before URL resolution) has no resolver match.  Reading url_name
    # from it raises AttributeError, which turns the 404 into a 500.
    # Fall back to the home entry so the error page can still render.
    try:
        home_item = menu.Menu.get_with_url_name('index')
    except LookupError:
        return breadcrumbs

    _add(home_item.url, home_item.name, home_item.url_name)
    breadcrumbs[home_item.url]['is_active_section'] = True
    return breadcrumbs
# plinth-fix-404:end
```

补丁块带标记注释，`fix_404.py` 检测到旧标记会先移除再写入，所以可以重复执行。

### 用法

```bash
sudo bash install.sh     # 打补丁（幂等）
sudo bash rollback.sh    # 撤掉
```

安装脚本会：备份到 `/root/freedombox-fixes-backup/<时间戳>/views.py` →
写入补丁 → `py_compile` 语法检查 → 重启 `plinth` → 请求一个不存在的地址，
确认返回 404 且 404 页面内容正常；任一步失败自动还原备份。

### 修复前后

| 请求 | 修复前 | 修复后 |
|---|---|---|
| `/plinth/this-page-should-not-exist/` | 500 | **404**（带首页面包屑与页脚） |
| `/plinth/` | 200 | 200 |
| `/plinth/apps/`（未登录） | 302 → 登录页 | 302 → 登录页 |

### 升级注意

`views.py` 属于 `freedombox` deb 包的文件清单，`apt upgrade freedombox`
会把它还原成官方版本，缺陷随之回来。升级后重新执行一次 `install.sh` 即可。
