#!/bin/bash
# 回滚 OpenVPN 模块补丁
# 用法： sudo bash rollback.sh <备份目录>
#       备份目录由 install.sh 打印，形如 /root/freedombox-openvpn-patch-backup/20261027-130000
set -euo pipefail

MODULE_DIR="/usr/lib/python3/dist-packages/plinth/modules/openvpn"
TPL_DIR="${MODULE_DIR}/templates"
BACKUP_ROOT="/root/freedombox-openvpn-patch-backup"

if [ "$(id -u)" -ne 0 ]; then
    echo "错误：需要 root 权限，请用 sudo 运行" >&2
    exit 1
fi

BACKUP="${1:-}"
if [ -z "$BACKUP" ]; then
    echo "用法： sudo bash $0 <备份目录>" >&2
    echo "可用备份：" >&2
    ls -1 "${BACKUP_ROOT}" 2>/dev/null >&2 || echo "  (无)" >&2
    exit 1
fi

if [ ! -d "$BACKUP" ]; then
    echo "错误：备份目录不存在：${BACKUP}" >&2
    exit 1
fi

for f in privileged.py views.py __init__.py openvpn.html; do
    if [ ! -f "${BACKUP}/${f}" ]; then
        echo "错误：备份不完整，缺少 ${f}" >&2
        exit 1
    fi
done

echo "== 恢复原始文件 =="
cp -a "${BACKUP}/privileged.py" "${MODULE_DIR}/privileged.py"
cp -a "${BACKUP}/views.py" "${MODULE_DIR}/views.py"
cp -a "${BACKUP}/__init__.py" "${MODULE_DIR}/__init__.py"
cp -a "${BACKUP}/openvpn.html" "${TPL_DIR}/openvpn.html"
echo "  已恢复 4 个文件"

if [ -f "${BACKUP}/freedombox.conf" ]; then
    echo "== 恢复服务端配置 =="
    cp -a "${BACKUP}/freedombox.conf" /etc/openvpn/server/freedombox.conf
    echo "  已恢复 freedombox.conf"
fi

echo "== 清理缓存并重启 =="
rm -rf "${MODULE_DIR}/__pycache__" 2>/dev/null || true
systemctl restart plinth
sleep 3
systemctl is-active --quiet plinth \
    && echo "  plinth 已恢复运行" \
    || echo "  警告：plinth 未启动，请检查 journalctl -u plinth -n 40" >&2

echo
echo "回滚完成。设置文件 /etc/openvpn/server/freedombox-settings.json 已保留，"
echo "如确认不再需要可手动删除。"
