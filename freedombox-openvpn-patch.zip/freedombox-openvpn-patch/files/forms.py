# SPDX-License-Identifier: AGPL-3.0-or-later
"""Django form for configuring the OpenVPN server."""

from django import forms
from django.utils.translation import gettext_lazy as _

from . import privileged


class OpenVPNSettingsForm(forms.Form):
    """Listen port and client authentication mode."""

    port = forms.IntegerField(
        label=_('Port'),
        min_value=1,
        max_value=65535,
        help_text=_('UDP port the server listens on. Change this only if '
                    'another service already occupies the default port.'))

    auth_mode = forms.ChoiceField(
        label=_('Client authentication'),
        choices=[
            ('cert', _('Certificate only')),
            ('cert+pw', _('Certificate + username/password')),
        ],
        widget=forms.RadioSelect,
        help_text=_('With username/password enabled, clients must present a '
                    'valid certificate and also supply credentials that are '
                    'verified by an external script.'))

    def clean_port(self):
        """Reject ports already bound by another listening socket."""
        port = self.cleaned_data['port']
        current = privileged.get_settings()
        if port == current['port']:
            return port

        if _port_in_use(port):
            raise forms.ValidationError(
                _('Port %(port)s is already in use by another service.'),
                code='port-in-use',
                params={'port': port})

        return port


def _port_in_use(port: int) -> bool:
    """Return whether any UDP or TCP socket is bound to *port*."""
    import socket

    for sock_type in (socket.SOCK_DGRAM, socket.SOCK_STREAM):
        sock = socket.socket(socket.AF_INET, sock_type)
        sock.settimeout(0.5)
        try:
            # Bind probes the wildcard address; failure means occupied.
            sock.bind(('0.0.0.0', port))
        except OSError:
            return True
        finally:
            sock.close()

    return False
