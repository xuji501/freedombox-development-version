# SPDX-License-Identifier: AGPL-3.0-or-later
"""FreedomBox app for configuring OpenVPN server."""

import logging

from django.contrib import messages
from django.http import HttpResponse
from django.utils.translation import gettext as _

from plinth.modules.names.components import DomainName
from plinth.views import AppView

from . import privileged
from .forms import OpenVPNSettingsForm

logger = logging.getLogger(__name__)


class OpenVPNAppView(AppView):
    """Show OpenVPN app main page."""

    app_id = 'openvpn'
    template_name = 'openvpn.html'
    form_class = OpenVPNSettingsForm

    def get_initial(self):
        """Populate the form with the settings currently in effect."""
        initial = super().get_initial()
        try:
            settings = privileged.get_settings()
            initial['port'] = settings['port']
            initial['auth_mode'] = settings['auth_mode']
        except Exception:
            # Never let a settings read failure break the page.
            logger.exception('Unable to read OpenVPN settings')
            initial.setdefault('port', 1194)
            initial.setdefault('auth_mode', 'cert')

        return initial

    def form_valid(self, form):
        """Persist settings and restart the service."""
        try:
            privileged.set_settings(form.cleaned_data['port'],
                                    form.cleaned_data['auth_mode'])
        except Exception as exception:
            logger.exception('Unable to apply OpenVPN settings')
            messages.error(
                self.request,
                _('Could not apply the new configuration: {error}').format(
                    error=exception))
            return self.form_invalid(form)

        messages.success(self.request, _('Configuration updated.'))
        return super().form_valid(form)


def profile(request):
    """Provide the user's profile for download."""
    username = request.user.username
    domain_name = DomainName.list_names()[0]

    profile_string = privileged.get_profile(username, domain_name)
    response = HttpResponse(profile_string,
                            content_type='application/x-openvpn-profile')
    response['Content-Disposition'] = \
        'attachment; filename={username}.ovpn'.format(username=username)

    return response
