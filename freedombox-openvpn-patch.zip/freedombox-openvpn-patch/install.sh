#!/bin/bash
# 为 FreedomBox 的 OpenVPN 模块增加「认证方式 + 端口」配置项
# 用法： sudo bash install.sh
set -euo pipefail

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
MODULE_DIR="/usr/lib/python3/dist-packages/plinth/modules/openvpn"
TPL_DIR="${MODULE_DIR}/templates"
SETTINGS="/etc/openvpn/server/freedombox-settings.json"
CONF="/etc/openvpn/server/freedombox.conf"
BACKUP_ROOT="/root/freedombox-openvpn-patch-backup"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP="${BACKUP_ROOT}/${TS}"

if [ "$(id -u)" -ne 0 ]; then
    echo "错误：需要 root 权限，请用 sudo 运行" >&2
    exit 1
fi

echo "== 1. 环境检查 =="
PKG_VER="$(dpkg-query -W -f='${Version}' freedombox 2>/dev/null || echo unknown)"
echo "  FreedomBox 版本: ${PKG_VER}"
case "$PKG_VER" in
    25.*) ;;
    *) echo "  警告：本补丁基于 25.9.3 编写，当前版本 ${PKG_VER} 可能不兼容" >&2
       read -r -p "  仍要继续？[y/N] " ans
       [ "$ans" = "y" ] || exit 1 ;;
esac
for f in privileged.py views.py __init__.py; do
    [ -f "${MODULE_DIR}/${f}" ] || { echo "  错误：缺少 ${MODULE_DIR}/${f}" >&2; exit 1; }
done
[ -f "${TPL_DIR}/openvpn.html" ] || { echo "  错误：缺少模板文件" >&2; exit 1; }
echo "  检查通过"

echo "== 2. 备份原始文件 =="
mkdir -p "$BACKUP"
for f in privileged.py views.py __init__.py; do
    cp -a "${MODULE_DIR}/${f}" "${BACKUP}/${f}"
done
cp -a "${TPL_DIR}/openvpn.html" "${BACKUP}/openvpn.html"
[ -f "$CONF" ] && cp -a "$CONF" "${BACKUP}/freedombox.conf"
[ -f "$SETTINGS" ] && cp -a "$SETTINGS" "${BACKUP}/freedombox-settings.json"
echo "  已备份到 ${BACKUP}"

echo "== 3. 初始化设置文件 =="
if [ -f "$SETTINGS" ]; then
    echo "  ${SETTINGS} 已存在，保留现有设置"
else
    CUR_PORT="$(awk '/^port /{print $2; exit}' "$CONF" 2>/dev/null || true)"
    CUR_PORT="${CUR_PORT:-1194}"
    mkdir -p "$(dirname "$SETTINGS")"
    cat > "$SETTINGS" <<JSON
{
  "port": ${CUR_PORT},
  "auth_mode": "cert",
  "auth_script": "/opt/routeweb/ovpn_auth.py"
}
JSON
    chmod 644 "$SETTINGS"
    echo "  已创建 ${SETTINGS}，继承当前端口 ${CUR_PORT}"
fi

echo "== 4. 部署补丁文件 =="
install -m 644 "${SRC_DIR}/files/privileged.py" "${MODULE_DIR}/privileged.py"
install -m 644 "${SRC_DIR}/files/forms.py" "${MODULE_DIR}/forms.py"
install -m 644 "${SRC_DIR}/files/views.py" "${MODULE_DIR}/views.py"
install -m 644 "${SRC_DIR}/files/openvpn.html" "${TPL_DIR}/openvpn.html"
echo "  已部署 4 个文件"

echo "== 5. 提升模块版本号以触发 setup =="
sed -i 's/^    _version = 5$/    _version = 6/' "${MODULE_DIR}/__init__.py"
if ! grep -q '^    _version = 6$' "${MODULE_DIR}/__init__.py"; then
    echo "  错误：版本号替换失败，正在回滚" >&2
    for f in privileged.py views.py __init__.py; do
        cp -a "${BACKUP}/${f}" "${MODULE_DIR}/${f}"
    done
    cp -a "${BACKUP}/openvpn.html" "${TPL_DIR}/openvpn.html"
    exit 1
fi
echo "  _version 已改为 6"

echo "== 6. 语法校验 =="
python3 -m py_compile "${MODULE_DIR}/privileged.py" \
                      "${MODULE_DIR}/forms.py" \
                      "${MODULE_DIR}/views.py" \
    || { echo "  语法错误，正在回滚" >&2
         for f in privileged.py views.py __init__.py; do
             cp -a "${BACKUP}/${f}" "${MODULE_DIR}/${f}"
         done
         cp -a "${BACKUP}/openvpn.html" "${TPL_DIR}/openvpn.html"
         exit 1; }
echo "  语法正确"

echo "== 7. 清理字节码缓存并重启 Plinth =="
rm -rf "${MODULE_DIR}/__pycache__" 2>/dev/null || true
systemctl restart plinth
for _ in $(seq 1 20); do
    systemctl is-active --quiet plinth && break
    sleep 1
done
if ! systemctl is-active --quiet plinth; then
    echo "  错误：plinth 启动失败，最近日志：" >&2
    journalctl -u plinth -n 40 --no-pager >&2
    echo "  请执行： sudo bash rollback.sh ${BACKUP}" >&2
    exit 1
fi
echo "  plinth 已重启"

echo "== 8. 验证 =="
sleep 2
echo "  当前设置："
cat "$SETTINGS"
echo "  OpenVPN 服务状态：$(systemctl is-active openvpn-server@freedombox || true)"
echo "  监听端口："
ss -tuln | grep -E ':119[0-9]' || echo "    (未检测到)"

echo
echo "安装完成。打开 Plinth 的 OpenVPN 页面即可看到「服务器设置」表单。"
echo "回滚命令： sudo bash rollback.sh ${BACKUP}"
