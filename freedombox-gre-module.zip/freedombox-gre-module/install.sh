#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 为 FreedomBox 安装 GRE 隧道管理模块。
#
# 用法：sudo bash install.sh
#
# 安装内容：
#   /usr/lib/python3/dist-packages/plinth/modules/gre/   模块代码
#   /etc/freedombox/modules-enabled/gre                  启用标记
#   /etc/freedombox-gre/tunnels.json                     隧道清单（0600）
#   /usr/lib/freedombox-gre/apply.py                     开机重建脚本（0755）
#   /etc/systemd/system/freedombox-gre.service           oneshot unit
#
# 注意：本模块会创建 GRE 网卡，但不改动任何已有网卡的地址或路由。
# 任何一步失败都会自动回滚到安装前的状态。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/gre
ENABLED_DIR=/etc/freedombox/modules-enabled
CONFIG_DIR=/etc/freedombox-gre
APPLY_DIR=/usr/lib/freedombox-gre
UNIT_FILE=/etc/systemd/system/freedombox-gre.service
SERVICE=freedombox-gre
BACKUP_ROOT=/root/freedombox-gre-module-backup
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
SOURCE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

rollback() {
    echo "正在回滚..." >&2

    systemctl stop "$SERVICE" 2>/dev/null || true
    systemctl disable "$SERVICE" 2>/dev/null || true
    rm -f "$UNIT_FILE"
    systemctl daemon-reload 2>/dev/null || true

    # 删掉本次可能创建出来的网卡，避免回滚后留下孤儿接口。
    if [ -d "$CONFIG_DIR" ] && command -v python3 >/dev/null; then
        python3 - "$CONFIG_DIR/tunnels.json" <<'PYEOF' 2>/dev/null || true
import json
import subprocess
import sys

try:
    with open(sys.argv[1], encoding='utf-8') as handle:
        data = json.load(handle)
except Exception:
    raise SystemExit(0)

for item in data.get('tunnels') or []:
    name = (item or {}).get('name')
    if name:
        subprocess.run(['ip', 'link', 'del', name], capture_output=True)
PYEOF
    fi

    nft delete table inet fbx_gre_mss 2>/dev/null || true
    rm -rf "$APPLY_DIR"

    if [ -d "$BACKUP_DIR/config" ]; then
        rm -rf "$CONFIG_DIR"
        cp -a "$BACKUP_DIR/config" "$CONFIG_DIR"
        echo "已恢复原有隧道清单" >&2
    else
        rm -rf "$CONFIG_DIR"
    fi

    rm -f "$ENABLED_DIR/gre"

    if [ -d "$BACKUP_DIR/module" ]; then
        rm -rf "$MODULE_DIR"
        cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
        echo "已恢复原有模块目录" >&2
    else
        rm -rf "$MODULE_DIR"
        echo "已移除新模块目录" >&2
    fi

    if [ -f "$BACKUP_DIR/enabled-gre" ]; then
        cp -a "$BACKUP_DIR/enabled-gre" "$ENABLED_DIR/gre"
    fi

    systemctl restart plinth 2>/dev/null || true
    echo "回滚完成" >&2
}

echo "=============================================="
echo " FreedomBox GRE 隧道模块安装"
echo "=============================================="

echo ""
echo "== 1/9 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
[ -f "$SOURCE_DIR/files/privileged.py" ] || fail "在 $SOURCE_DIR/files 下找不到模块源文件"
dpkg -s freedombox >/dev/null 2>&1 || fail "未检测到 freedombox 软件包"
echo "freedombox 版本：$(dpkg-query -W -f='${Version}' freedombox)"
command -v ip >/dev/null || fail "未找到 ip 命令（iproute2）"
echo "iproute2：$(ip -V 2>/dev/null | head -1)"

# GRE 由内核模块提供，缺了它整页功能都无意义，提前拦住比装完再报错好。
# 判 ip_gre 是否可用，不能只看 modprobe：
#   1. 已加载（/proc/modules 或 /sys/module）—— 最可靠，容器里也成立
#   2. modprobe -n 干跑通过（需要 kmod 与 /lib/modules）
# 最小化 Debian 上可能没有 kmod，此时 modprobe 命令根本不存在。
if grep -q '^ip_gre ' /proc/modules 2>/dev/null || [ -d /sys/module/ip_gre ]; then
    ok "内核 GRE 模块已加载"
elif command -v modprobe >/dev/null 2>&1 && modprobe -n ip_gre >/dev/null 2>&1; then
    modprobe ip_gre 2>/dev/null || true
    ok "内核 GRE 模块可用"
else
    fail "内核没有 ip_gre 模块，无法创建 GRE 隧道"
fi
echo "GRE 内核模块：可用"

if ! command -v nft >/dev/null; then
    echo "提示：未找到 nft 命令，MSS 钳制功能将被跳过（隧道本身不受影响）"
else
    echo "nftables：$(nft --version 2>/dev/null | head -1)"
fi

echo "现有网卡：$(ip -o link show | awk -F': ' '{print $2}' | tr '\n' ' ')"

echo ""
echo "== 2/9 备份现有状态 =="
mkdir -p "$BACKUP_DIR"
if [ -d "$MODULE_DIR" ]; then
    cp -a "$MODULE_DIR" "$BACKUP_DIR/module"
    echo "已备份现有模块目录"
fi
if [ -f "$ENABLED_DIR/gre" ]; then
    cp -a "$ENABLED_DIR/gre" "$BACKUP_DIR/enabled-gre"
    echo "已备份现有启用标记"
fi
if [ -d "$CONFIG_DIR" ]; then
    cp -a "$CONFIG_DIR" "$BACKUP_DIR/config"
    echo "已备份现有隧道清单（重装时保留已配置的隧道）"
fi
ip -o link show > "$BACKUP_DIR/links.txt" 2>/dev/null || true
echo "备份目录：$BACKUP_DIR"

echo ""
echo "== 3/9 部署模块文件 =="
mkdir -p "$MODULE_DIR/templates"
for name in __init__.py manifest.py forms.py views.py urls.py privileged.py submenu.py; do
    install -m 644 "$SOURCE_DIR/files/$name" "$MODULE_DIR/$name" \
        || fail "复制 $name 失败"
done
install -m 644 "$SOURCE_DIR/files/templates/gre.html" \
    "$MODULE_DIR/templates/gre.html" || fail "复制模板失败"
rm -rf "$MODULE_DIR/__pycache__"
chown -R root:root "$MODULE_DIR"
chmod 755 "$MODULE_DIR"
echo "已部署到 $MODULE_DIR"

echo ""
echo "== 4/9 语法检查 =="
for file in "$MODULE_DIR"/*.py; do
    if ! python3 -m py_compile "$file"; then
        rollback
        fail "语法错误：$file"
    fi
done
echo "全部 Python 文件语法正确"

echo ""
echo "== 5/9 启用模块 =="
mkdir -p "$ENABLED_DIR"
echo "plinth.modules.gre" > "$ENABLED_DIR/gre"
chmod 644 "$ENABLED_DIR/gre"
echo "已写入 $ENABLED_DIR/gre"

echo ""
echo "== 6/9 导入与表单检查 =="
CHECK_SCRIPT=$(mktemp /tmp/gre-check-XXXXXX.py)
cat > "$CHECK_SCRIPT" <<'PYEOF'
# web_framework.init() configures Django itself, so django.setup() must not
# be called beforehand.
from plinth import web_framework

web_framework.init()

from plinth.modules.gre import forms, privileged, views  # noqa: E402

assert views.GreAppView.app_id == 'gre'
assert views.GreAppView.form_class is forms.GreTunnelForm

form = forms.GreTunnelForm()
for field in ('tunnel_id', 'name', 'local', 'remote', 'address', 'mtu',
              'ttl', 'key', 'checksum', 'clamp_mss', 'enabled', 'comment'):
    assert field in form.fields, f'缺少表单字段 {field}'

for action in ('setup', 'get_devices', 'get_tunnels', 'add_tunnel',
               'update_tunnel', 'delete_tunnel', 'set_enabled', 'uninstall'):
    assert callable(getattr(privileged, action)), f'缺少动作 {action}'

# 隧道名称必须是合法的网卡名，这是本模块最基础的边界。
for bad in ('1gre', 'gre tool', 'a' * 20, 'lo', ''):
    try:
        privileged._validate(
            {'name': bad, 'remote': '203.0.113.10', 'local': '',
             'addresses': [], 'mtu': 1476, 'ttl': 64, 'key': 0}, [])
    except ValueError:
        pass
    else:
        raise AssertionError(f'名称 {bad!r} 本应被拒绝')

# 远端地址必填且必须是 IPv4。
try:
    privileged._validate(
        {'name': 'gre1', 'remote': 'not-an-address', 'local': '',
         'addresses': [], 'mtu': 1476, 'ttl': 64, 'key': 0}, [])
except ValueError:
    pass
else:
    raise AssertionError('非法远端地址本应被拒绝')

# 合法的隧道必须能通过校验，并被规范化。
tunnel = privileged._validate(
    {'name': 'gre1', 'remote': '203.0.113.10', 'local': '',
     'addresses': ['10.20.0.1/30'], 'mtu': 1476, 'ttl': 64, 'key': 0}, [])
assert tunnel['name'] == 'gre1'
assert tunnel['addresses'] == ['10.20.0.1/30']

print('开机脚本语法检查：', end='')
compile(privileged.APPLY_SCRIPT, 'apply.py', 'exec')
print('通过')

from django.template.loader import get_template  # noqa: E402
template = get_template('gre.html')
print('模板来源：', template.origin.name)
print('模块导入、表单字段、隧道校验与模板加载全部正常')
PYEOF

if ! python3 "$CHECK_SCRIPT"; then
    rm -f "$CHECK_SCRIPT"
    rollback
    fail "导入检查未通过，已回滚"
fi
rm -f "$CHECK_SCRIPT"

echo ""
echo "== 7/9 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if ! systemctl is-active --quiet plinth; then
    rollback
    fail "Plinth 未能启动，已回滚"
fi
echo "Plinth 运行正常"

echo ""
echo "== 8/9 首次初始化 =="
(cd /usr/lib/python3/dist-packages && \
    timeout 120 python3 "$SOURCE_DIR/init_once.py")
INIT_RC=$?

if [ "$INIT_RC" -ne 0 ]; then
    rollback
    fail "首次初始化失败（退出码 $INIT_RC），已回滚"
fi

echo ""
echo "== 9/9 验证 =="
[ -f "$CONFIG_DIR/tunnels.json" ] || { rollback; fail "隧道清单未生成"; }
[ -x "$APPLY_DIR/apply.py" ] || { rollback; fail "开机重建脚本未安装"; }
[ -f "$UNIT_FILE" ] || { rollback; fail "systemd unit 未安装"; }
systemctl is-enabled --quiet "$SERVICE" || { rollback; fail "服务未设为开机启动"; }
systemctl is-active --quiet "$SERVICE" || { rollback; fail "服务未启动"; }

echo "隧道清单：$(ls -l "$CONFIG_DIR/tunnels.json" | awk '{print $1, $3, $4}')"
echo "重建脚本：$(ls -l "$APPLY_DIR/apply.py" | awk '{print $1, $3, $4}')"
echo "unit 文件：$(ls -l "$UNIT_FILE" | awk '{print $1, $3, $4}')"

# 开机脚本本身要能独立跑通：不依赖 Plinth，重复执行也无害。
if ! /usr/bin/python3 "$APPLY_DIR/apply.py"; then
    rollback
    fail "开机重建脚本执行失败"
fi
echo "开机重建脚本独立执行成功（当前无隧道，属空操作）"

if systemctl is-enabled --quiet plinth; then
    CODE=$(curl -sk -o /dev/null -w '%{http_code}' \
        https://127.0.0.1/plinth/sys/gre/ 2>/dev/null || echo 000)
    echo "GRE 隧道页面返回 HTTP $CODE（302 表示需要登录，属正常）"
fi

echo ""
echo "== 安装结果 =="
python3 - "$CONFIG_DIR/tunnels.json" <<'PYEOF'
import json
import sys

try:
    with open(sys.argv[1], encoding='utf-8') as handle:
        data = json.load(handle)
except Exception:
    data = {}

tunnels = data.get('tunnels') or []
if not tunnels:
    print('已配置的隧道：（空）')
for item in tunnels:
    print('  {:<8s} {} -> {} mtu={} addr={}'.format(
        item.get('name', '?'), item.get('local') or 'auto',
        item.get('remote', '?'), item.get('mtu'),
        ','.join(item.get('addresses') or []) or '-'))
PYEOF

echo ""
echo "服务状态：$(systemctl is-active "$SERVICE") / 开机启动：$(systemctl is-enabled "$SERVICE")"
echo ""
echo "访问 https://<本机地址>/plinth/sys/gre/ 管理 GRE 隧道"
echo "（入口在「系统 → 网络」标签栏，或「系统」页的 GRE 隧道卡片）"
echo "回滚命令：sudo bash $SOURCE_DIR/rollback.sh $BACKUP_DIR"
echo "=============================================="
