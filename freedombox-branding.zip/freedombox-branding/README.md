# FreedomBox 定制版版权信息

在 FreedomBox（Plinth）管理界面的**所有页面**底部加入一行定制版权信息：

```
FreedomBox 定制版，起点火箭开发 20261028，版本号 v1.0.1
```

## 为什么只改一个文件

Plinth 的每个页面最终都继承 `plinth/templates/base.html`：

| 页面 | 继承链 |
|---|---|
| 首页、应用页、系统页 | `index.html` / `cards.html` / `system.html` → `base.html` |
| 各应用页面 | `app.html` → `base.html` |
| 登录页 | `users_login.html` → `base.html` |
| 首次启动向导 | `first_setup.html` → `base_firstboot.html` → `base.html` |
| 404 / 403 / 500 | `404.html` 等 → `base.html` |

所以把版权块写进 `base.html` 的 `<footer>` 里，一次覆盖全部页面。
首页 `index.html` 覆盖了 `footer_block`，但版权块放在 block **之外**，
不受影响。

## 用法

```bash
sudo bash install.sh     # 写入（幂等，可重复执行）
sudo bash rollback.sh    # 移除
```

安装脚本会：

1. 把原模板备份到 `/root/freedombox-branding-backup/<时间戳>/base.html`
2. 在 `</footer>` 前插入版权块（带 `plinth-branding` 标记注释）
3. 用 Django 解析一次 `base.html`，确认模板没被改坏
4. 重启 `plinth` 让模板缓存失效
5. 请求登录页，确认页面里真的出现了这行文字

任何一步失败都会自动还原备份。

## 写入的内容

```html
    <!-- plinth-branding:start -->
    <div class="container plinth-copyright">
      <p class="text-muted small mb-0">
        FreedomBox 定制版，起点火箭开发 20261028，版本号 v1.0.1
      </p>
    </div>
    <!-- plinth-branding:end -->
```

`footer` 本身有 `text-align: center`，所以文字居中；`text-muted small`
让它在视觉上弱于正文，不抢内容焦点。

## 升级注意

`base.html` 属于 `freedombox` deb 包的文件清单，**`apt upgrade freedombox`
会把它还原成官方版本**，版权信息随之消失。升级后重新执行一次
`install.sh` 即可，脚本会先移除残留标记再重新写入，不会重复堆叠。

## 改文案

直接改 `apply_footer.py` 里的 `FOOTER_BLOCK` 常量，然后重新执行
`install.sh`——脚本检测到旧标记会先移除再写入，无需手工清理。
