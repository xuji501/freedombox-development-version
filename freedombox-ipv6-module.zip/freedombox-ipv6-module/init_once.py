"""Run the first-time setup for the IPv6 app.

Called by install.sh as root.

Plinth only re-runs setup for apps that already have a version recorded, or for
essential apps, so a freshly added non-essential app is never set up
automatically.  This does the same work the app's setup() method does, but
calls the private helpers directly: we are already root, so going through the
privileged action dispatcher would only spawn a pointless sudo.

Note what it does NOT do: it does not enable IPv6 routing.  Turning on
forwarding and router advertisements changes how the box behaves on the
network, so it is left as an explicit action on the page.
"""

from plinth import web_framework

web_framework.init()

from plinth import action_utils  # noqa: E402
from plinth import app as app_module  # noqa: E402
from plinth import module_loader  # noqa: E402
from plinth.modules.ipv6 import privileged  # noqa: E402

module_loader.load_modules()
app_module.apps_init()

privileged.CONFIG_DIR.mkdir(parents=True, exist_ok=True)

settings = privileged.read_settings()
if not privileged.SETTINGS_PATH.exists():
    detected = privileged._detect()
    settings['wan_device'] = settings['wan_device'] or detected['wan_device']
    settings['lan_device'] = settings['lan_device'] or detected['lan_device']
    if not settings['prefix']:
        settings['prefix'] = detected['prefix']
    privileged._write_settings(settings)
    print('已写入初始设置:', settings)
else:
    print('保留已有设置:', settings)

privileged._write_generated_files(settings)
print('已生成路由通告配置:', privileged.DNSMASQ_CONF_PATH)
print('已生成 NAT66 规则    :', privileged.NAT_PATH)
print('已生成 sysctl 文件   :', privileged.SYSCTL_PATH)

action_utils.service_daemon_reload()

app = app_module.App.get('ipv6')
app.set_setup_version(app.info.version)
app.enable()

print('setup 版本:', app.get_setup_version(), '/', app.info.version)
print('应用已启用:', app.is_enabled())
print('IPv6 转发当前状态:', privileged._forwarding())
print('内网 IPv6 是否开启:', settings['lan_enabled'])
