"""Local logic tests for the IPv6 app with plinth stubbed out."""

import ipaddress
import json
import pathlib
import sys
import tempfile
import types

plinth = types.ModuleType('plinth')
action_utils = types.ModuleType('plinth.action_utils')
CALLS = []
for name in ('service_enable', 'service_disable', 'service_start',
             'service_stop', 'service_try_restart', 'service_restart',
             'service_daemon_reload'):
    setattr(action_utils, name,
            (lambda label: lambda *a, **k: CALLS.append((label,) + a))(name))
actions = types.ModuleType('plinth.actions')
actions.privileged = lambda func: func
plinth.action_utils = action_utils
plinth.actions = actions
sys.modules['plinth'] = plinth
sys.modules['plinth.action_utils'] = action_utils
sys.modules['plinth.actions'] = actions

sys.path.insert(0, str(pathlib.Path(__file__).parent / 'files'))
import privileged  # noqa: E402

WORK = pathlib.Path(tempfile.mkdtemp(prefix='fbx-ipv6-'))
privileged.CONFIG_DIR = WORK
privileged.SETTINGS_PATH = WORK / 'settings.json'
privileged.DNSMASQ_CONF_PATH = WORK / 'dnsmasq6.conf'
privileged.NAT_PATH = WORK / 'nat.nft'
privileged.SYSCTL_PATH = WORK / '99-freedombox-ipv6.conf'
privileged.PENDING_PATH = WORK / 'pending.json'
privileged.CONFIRMED_PATH = WORK / 'confirmed'
privileged.APPLY_SCRIPT_PATH = str(WORK / 'apply.py')
privileged.REVERT_SCRIPT_PATH = str(WORK / 'revert.py')
privileged.APPLY_UNIT_PATH = str(WORK / 'freedombox-ipv6.service')
privileged.RA_UNIT_PATH = str(WORK / 'freedombox-ipv6-ra.service')
privileged._devices = lambda: ['ens32', 'ens34']
privileged._connection_for = lambda device: 'conn-' + device

print('=' * 60)
print('测试 1：ULA 前缀生成')
print('=' * 60)
seen = set()
for _ in range(20):
    prefix = privileged.generate_prefix()
    network = ipaddress.ip_network(prefix)
    assert network.version == 6, prefix
    assert network.prefixlen == 64, prefix
    assert network.subnet_of(ipaddress.ip_network('fd00::/8')), \
        f'{prefix} 不在 fd00::/8 之内'
    seen.add(prefix)

print('  示例:', sorted(seen)[0])
assert len(seen) == 20, '连续生成的前缀应当互不相同'
print('[通过] 20 个前缀全部是 fd00::/8 内的 /64，且互不重复')

print()
print('=' * 60)
print('测试 2：前缀校验')
print('=' * 60)
good = privileged._normalise_prefix('fd12:3456:7890::/64')
print('  规范化:', good)
assert good == 'fd12:3456:7890::/64'

host = privileged._normalise_prefix('fd12:3456:7890::5/64')
print('  主机位被清零:', host)
assert host == 'fd12:3456:7890::/64', '应规范化为网络地址'

auto = privileged._normalise_prefix('')
print('  留空自动生成:', auto)
assert ipaddress.ip_network(auto).prefixlen == 64

bad_cases = [
    ('缺前缀', 'fd12:3456:7890::'),
    ('不是 /64', 'fd12:3456:7890::/48'),
    ('/56', 'fd12:3456:7890::/56'),
    ('IPv4', '192.168.1.0/24'),
    ('格式错', 'fd12:zzzz::/64'),
    ('链路本地', 'fe80::/64'),
    ('组播', 'ff02::/64'),
    ('公网地址', '2001:db8::/64'),
]
for label, text in bad_cases:
    try:
        privileged._normalise_prefix(text)
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label}（{text}）本应被拒绝')
print('[通过] 八类非法前缀全部拦截')

print()
print('=' * 60)
print('测试 3：设置校验')
print('=' * 60)
settings = privileged._validate({
    'wan_device': 'ens32', 'wan_method': 'auto',
    'lan_device': 'ens34', 'lan_enabled': True,
    'prefix': 'fd12:3456:7890::/64'})
print('  通过:', settings)
assert settings['lan_enabled'] is True
assert settings['prefix'] == 'fd12:3456:7890::/64'

off = privileged._validate({
    'wan_device': 'ens32', 'wan_method': 'disabled',
    'lan_device': 'ens34', 'lan_enabled': False, 'prefix': ''})
print('  关闭内网:', off)
assert off['prefix'] == '', '关闭内网时不应强行生成前缀'

bad_settings = [
    ('WAN 网卡不存在', {'wan_device': 'eth9', 'wan_method': 'auto',
                       'lan_device': 'ens34', 'lan_enabled': False}),
    ('LAN 网卡不存在', {'wan_device': 'ens32', 'wan_method': 'auto',
                       'lan_device': 'eth9', 'lan_enabled': False}),
    ('WAN 与 LAN 相同', {'wan_device': 'ens32', 'wan_method': 'auto',
                        'lan_device': 'ens32', 'lan_enabled': True}),
    ('获取方式非法', {'wan_device': 'ens32', 'wan_method': 'magic',
                    'lan_device': 'ens34', 'lan_enabled': False}),
    ('开内网却没选 LAN', {'wan_device': 'ens32', 'wan_method': 'auto',
                        'lan_device': '', 'lan_enabled': True}),
    ('开内网却没选 WAN', {'wan_device': '', 'wan_method': 'auto',
                        'lan_device': 'ens34', 'lan_enabled': True}),
]
for label, case in bad_settings:
    try:
        privileged._validate(case)
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label} 本应被拒绝')
print('[通过] 六类非法组合全部拦截')

print()
print('=' * 60)
print('测试 4：生成的路由通告配置')
print('=' * 60)
conf = privileged._dnsmasq_conf(settings)
print('\n'.join('  ' + line for line in conf.splitlines()))
assert 'port=0' in conf, 'RA 实例不应占用 53 端口'
assert 'interface=ens34' in conf
assert 'enable-ra' in conf
assert 'dhcp-range=fd12:3456:7890::100,fd12:3456:7890::1ff,64,12h' in conf
assert 'dhcp-option=option6:dns-server,[fd12:3456:7890::1]' in conf

empty = privileged._dnsmasq_conf({'prefix': '', 'lan_device': 'ens34'})
print('  未配前缀时:')
print('\n'.join('  ' + line for line in empty.splitlines()))
assert 'enable-ra' not in empty, '没有前缀时不能发路由通告'
print('[通过] 有前缀时启用 RA，无前缀时保持惰性')

print()
print('=' * 60)
print('测试 5：NAT66 规则')
print('=' * 60)
rules = privileged._nat_rules(settings)
print('\n'.join('  ' + line for line in rules.splitlines()))
assert 'table ip6 fbx_ipv6nat' in rules
assert 'oifname "ens32" ip6 saddr fd12:3456:7890::/64 masquerade' in rules
assert 'priority srcnat' in rules

no_wan = privileged._nat_rules({'prefix': 'fd12::/64', 'wan_device': ''})
assert 'masquerade' not in no_wan, '没有 WAN 时不应生成伪装规则'
print('[通过] 伪装规则指向 WAN 口，缺配置时不留残余规则')

print()
print('=' * 60)
print('测试 6：sysctl 顺序（这是最容易踩的坑）')
print('=' * 60)
privileged._write_generated_files(settings)
text = privileged.SYSCTL_PATH.read_text(encoding='utf-8')
print('\n'.join('  ' + line for line in text.splitlines()))
forward = text.index('all.forwarding = 1')
accept = text.index('ens32.accept_ra = 2')
assert forward < accept, \
    'accept_ra 必须写在 forwarding 之后，否则内核会把 accept_ra 重置为 0'
print('[通过] forwarding 在前、accept_ra 在后')

print()
print('测试 6b：关闭内网时，sysctl 文件不能留下 forwarding=1')
print('=' * 60)
privileged._write_generated_files({
    'wan_device': 'ens32', 'wan_method': 'disabled',
    'lan_device': 'ens34', 'lan_enabled': False, 'prefix': 'fd12::/64'})
off_text = privileged.SYSCTL_PATH.read_text(encoding='utf-8')
print('\n'.join('  ' + line for line in off_text.splitlines()))
assert 'all.forwarding = 0' in off_text, \
    '关闭内网时，开机用的 sysctl 文件必须是 forwarding=0'
assert 'all.forwarding = 1' not in off_text, \
    '否则重启会把用户已经关掉的功能重新打开'
assert 'accept_ra = 1' in off_text, '关闭时应把 accept_ra 复位为 1'
assert 'accept_ra = 2' not in off_text

# 还原成开启态，后面的测试依赖它。
privileged._write_generated_files(settings)
print('[通过] 关闭态写 0，开启态写 1，不会在重启后复活')

print()
print('=' * 60)
print('测试 7：开机脚本与 unit')
print('=' * 60)
compile(privileged.APPLY_SCRIPT, 'apply.py', 'exec')
compile(privileged.REVERT_SCRIPT, 'revert.py', 'exec')
assert 'plinth' not in privileged.APPLY_SCRIPT, '开机脚本不能依赖 Plinth'
assert 'plinth' not in privileged.REVERT_SCRIPT, '还原脚本不能依赖 Plinth'

script = privileged.APPLY_SCRIPT
# Look for the actual sysctl arguments, not the comment that explains them.
assert script.index('net.ipv6.conf.all.forwarding=1') < \
    script.index('net.ipv6.conf.{}.accept_ra=2'), \
    '开机脚本里的顺序也必须先 forwarding 再 accept_ra'
assert "run(['nft', 'delete', 'table'] + NAT_TABLE.split())" in script

ra_unit = privileged.RA_UNIT_CONTENT
print('  RA unit:')
for line in ra_unit.splitlines():
    if line.startswith(('ExecStart=', 'BindsTo=', 'Restart=', 'After=')):
        print('   ', line)
assert 'BindsTo=freedombox-ipv6.service' in ra_unit
assert '/etc/freedombox-ipv6/dnsmasq6.conf' in ra_unit
assert '--keep-in-foreground' in ra_unit

apply_unit = privileged.APPLY_UNIT_CONTENT
assert 'Type=oneshot' in apply_unit and 'RemainAfterExit=yes' in apply_unit
assert 'ExecStart=/usr/bin/python3 /usr/lib/freedombox-ipv6/apply.py' \
    in apply_unit
print('[通过] 两个脚本语法有效且不依赖 Plinth，unit 关系正确')

print()
print('=' * 60)
print('测试 8：应用配置（成功路径）')
print('=' * 60)
CALLS.clear()
privileged._write_settings(privileged.read_settings())


def fresh_state():
    """Return a mutable state holder for the fakes."""
    return {'ipv4_calls': 0, 'commands': [], 'nmcli': [],
            'nft_fails': False, 'address_present': True}


STATE = fresh_state()
REAL_IPV4 = {'ens32': ['10.10.173.19/24'], 'ens34': ['172.16.19.1/24']}


def fake_run(arguments):
    """Record a command and report success."""
    STATE['commands'].append(list(arguments))
    if STATE['nft_fails'] and arguments[:2] == ['nft', '-f']:
        return types.SimpleNamespace(stdout='', stderr='syntax error',
                                     returncode=1)
    return types.SimpleNamespace(stdout='', stderr='', returncode=0)


def fake_nmcli(*arguments):
    """Record an nmcli call and report success."""
    STATE['nmcli'].append(list(arguments))
    return types.SimpleNamespace(stdout='', stderr='', returncode=0)


def fake_ipv4(device):
    """Return the IPv4 addresses, going blank once the change is applied."""
    if not STATE['address_present']:
        # 第一次（记录基线）之后返回空，模拟改坏了
        STATE['ipv4_calls'] += 1
        if STATE['ipv4_calls'] > 2:
            return []
    return REAL_IPV4.get(device, [])


def fake_has_address(device, address):
    """Report whether the LAN got its IPv6 address."""
    return STATE['address_present']


def fake_default_routes(family):
    """Report the default routes."""
    if family == 'ipv4':
        return ['default via 10.10.173.1 dev ens32']
    return []


privileged._run = fake_run
privileged._nmcli = fake_nmcli
privileged._ipv4_addresses = fake_ipv4
privileged._has_address = fake_has_address
privileged._default_routes = fake_default_routes

result = privileged.apply_settings('ens32', 'auto', 'ens34', True,
                                   'fd12:3456:7890::/64')
print('  保存的设置:', json.dumps(privileged.read_settings(),
                                  ensure_ascii=False))
assert result['prefix'] == 'fd12:3456:7890::/64'
assert privileged.read_settings()['lan_enabled'] is True

sysctl_calls = [item for item in STATE['commands'] if item[0] == 'sysctl']
print('  sysctl 调用顺序:')
for item in sysctl_calls:
    print('   ', ' '.join(item))
assert sysctl_calls[0][-1].endswith('all.forwarding=1'), '先开转发'
assert sysctl_calls[1][-1].endswith('ens32.accept_ra=2'), '再设 accept_ra'

nft_calls = [item for item in STATE['commands'] if item[0] == 'nft']
print('  nft 调用:', nft_calls)
assert any(item[:4] == ['nft', 'delete', 'table', 'ip6'] for item in nft_calls)
assert any(item[:2] == ['nft', '-f'] for item in nft_calls)

print('  nmcli 调用:')
for item in STATE['nmcli']:
    print('   ', ' '.join(item))
assert any('ipv6.method' in item and 'auto' in item for item in STATE['nmcli'])

manual = [item for item in STATE['nmcli']
          if 'ipv6.method' in item and 'manual' in item]
assert len(manual) == 1, '方法与地址必须在同一条 nmcli 命令里'
assert 'ipv6.addresses' in manual[0], '同一条命令里必须带地址'
assert 'fd12:3456:7890::1/64' in manual[0], manual[0]
print('  manual 的单条命令:', ' '.join(manual[0]))

assert any('reapply' in item for item in STATE['nmcli']), \
    '应优先 reapply，避免重新激活把 IPv4 一起断开'

assert any('freedombox-ipv6-ra' in item for item in CALLS), 'RA 服务应被启动'
assert any('systemd-run' in item[0] for item in STATE['commands']), \
    '应挂上后备定时器'
assert any('stop' in item and any('fbx-ipv6-revert' in str(x) for x in item)
           for item in STATE['commands']), '成功之后应停掉定时器'
assert privileged.CONFIRMED_PATH.exists(), '成功之后应写确认标记'
print('[通过] 方法+地址一条命令下发，reapply 优先，后备定时器已装上并停掉')

print()
print('=' * 60)
print('测试 8b：nmcli 拒绝修改时必须立刻报错')
print('=' * 60)
# 这正是踩过的坑：ipv6.method=manual 单独下发会被拒绝，
# 若忽略返回码，后面所有步骤都会「成功」但什么也没发生。
STATE.update(fresh_state())
CALLS.clear()


def refusing_nmcli(*arguments):
    """Reject every modify, the way nmcli rejects a lone method=manual."""
    STATE['nmcli'].append(list(arguments))
    if arguments[:2] == ('connection', 'modify'):
        return types.SimpleNamespace(
            stdout='',
            stderr="Error: Failed to modify connection: ipv6.method: "
                   "method 'manual' requires at least an address or a route",
            returncode=2)
    return types.SimpleNamespace(stdout='', stderr='', returncode=0)


privileged._nmcli = refusing_nmcli
try:
    privileged.apply_settings('ens32', 'auto', 'ens34', True,
                              'fd12:3456:7890::/64')
except ValueError as error:
    print('  [拒绝]', error)
    assert '修改' in str(error), '应说明是哪一步失败'
    assert 'requires at least an address' in str(error), \
        'nmcli 的原始报错要原样带给用户，否则无从排查'
else:
    raise AssertionError('nmcli 拒绝时必须报错')

privileged._nmcli = fake_nmcli
print('[通过] nmcli 的报错被如实抛给用户，不会静默继续')

print()
print('=' * 60)
print('测试 9：改动把网络弄坏时自动回滚')
print('=' * 60)
CALLS.clear()
STATE.update(fresh_state())
STATE['address_present'] = False
before = privileged.read_settings()

try:
    privileged.apply_settings('ens32', 'auto', 'ens34', True,
                              'fd12:dead:beef::/64')
except ValueError as error:
    print('  [回滚]', error)
else:
    raise AssertionError('弄坏网络时本应回滚')

restore_calls = [item for item in STATE['nmcli'] if 'up' in item]
print('  恢复用的 nmcli up 次数:', len(restore_calls))
assert restore_calls, '回滚时必须重新激活连接'
after = privileged.read_settings()
assert after['prefix'] == before['prefix'], '回滚后配置不能变成新值'
assert after['lan_enabled'] == before['lan_enabled']
print('  配置未被改写:', after['prefix'])
print('[通过] 检测到 LAN 地址丢失后立即还原，且不保存新配置')

print()
print('=' * 60)
print('测试 10：NAT 规则写入失败也要回滚')
print('=' * 60)
STATE.update(fresh_state())
STATE['nft_fails'] = True
try:
    privileged.apply_settings('ens32', 'auto', 'ens34', True,
                              'fd12:cafe::/64')
except ValueError as error:
    print('  [回滚]', error)
    assert 'NAT66' in str(error)
else:
    raise AssertionError('NAT 写入失败时本应回滚')
assert privileged.read_settings()['prefix'] != 'fd12:cafe::/64'
print('[通过] nft 报错时还原 NetworkManager 设置并保留原配置')

print()
print('=' * 60)
print('测试 11：关闭内网 IPv6')
print('=' * 60)
STATE.update(fresh_state())
CALLS.clear()
privileged.apply_settings('ens32', 'disabled', 'ens34', False, '')
saved = privileged.read_settings()
print('  设置:', json.dumps(saved, ensure_ascii=False))
assert saved['lan_enabled'] is False
assert any('freedombox-ipv6-ra' in item and 'stop' in item[0] + item[1]
           for item in CALLS if len(item) > 1), 'RA 服务应被停止'
assert any(item[-1].endswith('all.forwarding=0') for item in STATE['commands']
           if item[0] == 'sysctl'), '应关掉 IPv6 转发'
assert any(item[:4] == ['nft', 'delete', 'table', 'ip6']
           for item in STATE['commands']), '应删除 NAT66 表'
assert any(item[-1].endswith('ens32.accept_ra=1') for item in STATE['commands']
           if item[0] == 'sysctl'), '关闭时应把 WAN 的 accept_ra 复位为 1'
print('[通过] 关闭时停服务、关转发、删 NAT 规则、复位 accept_ra')

print()
print('=' * 60)
print('测试 12：自动探测网卡')
print('=' * 60)
privileged._run = lambda arguments: types.SimpleNamespace(
    stdout='default via 10.10.173.1 dev ens32 proto static\n'
    if arguments[:4] == ['ip', '-4', 'route', 'show'] else '',
    stderr='', returncode=0)
detected = privileged._detect()
print('  探测结果:', detected)
assert detected['wan_device'] == 'ens32'
assert detected['lan_device'] == 'ens34'
assert ipaddress.ip_network(detected['prefix']).prefixlen == 64
print('[通过] 默认路由所在网卡判为 WAN，另一块有地址的判为 LAN')

print()
print('=' * 60)
print('测试 13：识别「WAN 收到了本机自己的路由通告」')
print('=' * 60)
on = {'wan_device': 'ens32', 'lan_device': 'ens34', 'lan_enabled': True,
      'prefix': 'fd12:3456:7890::/64'}

LAN_ONLY = [{'address': 'fd12:3456:7890::1/64', 'scope': 'global'}]
LINK_ONLY = [{'address': 'fe80::1/64', 'scope': 'link'}]

privileged._addresses = lambda device: (LAN_ONLY if device == 'ens34'
                                       else LINK_ONLY)
privileged._run = lambda arguments: types.SimpleNamespace(
    stdout='', stderr='', returncode=0)
print('  只有 LAN 有 ULA:', privileged._wan_sees_own_prefix(on))
assert privileged._wan_sees_own_prefix(on) is False

# 实测到的真实形态：WAN 上没留下地址，但装了一条 proto ra 的 on-link 路由。
privileged._run = lambda arguments: types.SimpleNamespace(
    stdout='fd12:3456:7890::/64 dev ens32 proto ra metric 104 pref medium\n'
    'fd12:3456:7890::/64 dev ens32 proto kernel metric 256 expires 43196sec\n'
    'fe80::/64 dev ens32 proto kernel metric 256 pref medium\n',
    stderr='', returncode=0)
print('  只有路由没有地址:', privileged._wan_sees_own_prefix(on))
assert privileged._wan_sees_own_prefix(on) is True, \
    'WAN 上出现本机前缀的路由也算泄漏'

# 地址形态同样要能识别。
privileged._addresses = lambda device: (
    LAN_ONLY if device == 'ens34' else
    [{'address': 'fd12:3456:7890::4f2a/64', 'scope': 'global'}])
privileged._run = lambda arguments: types.SimpleNamespace(
    stdout='', stderr='', returncode=0)
print('  WAN 也拿到了 ULA 地址:', privileged._wan_sees_own_prefix(on))
assert privileged._wan_sees_own_prefix(on) is True

off = dict(on, lan_enabled=False)
assert privileged._wan_sees_own_prefix(off) is False, '功能关闭时不必提示'
print('[通过] 地址与路由两种形态都能识别，关闭状态不误报')

print()
print('=' * 60)
print('测试 14：网络分区的标签栏')
print('=' * 60)
# submenu.py 只用到 Django 的两个小接口，桩掉就能在本地验证。
django = types.ModuleType('django')
django_urls = types.ModuleType('django.urls')
django_utils = types.ModuleType('django.utils')
django_translation = types.ModuleType('django.utils.translation')


class NoReverseMatch(Exception):
    """Stand-in for django.urls.NoReverseMatch."""


ROUTES = {
    'networks:index': '/plinth/sys/networks/',
    'ipv6:index': '/plinth/sys/ipv6/',
    'routes:index': '/plinth/sys/routes/',
}


def fake_reverse(name, args=None, kwargs=None):
    """Resolve only the names the test knows about."""
    if name not in ROUTES:
        raise NoReverseMatch(name)
    return ROUTES[name]


django_urls.NoReverseMatch = NoReverseMatch
django_urls.reverse = fake_reverse
django_translation.gettext_lazy = lambda text: text
django.utils = django_utils
django_utils.translation = django_translation
sys.modules['django'] = django
sys.modules['django.urls'] = django_urls
sys.modules['django.utils'] = django_utils
sys.modules['django.utils.translation'] = django_translation

import submenu  # noqa: E402

Request = types.SimpleNamespace

tabs = submenu.entries(Request(path='/plinth/sys/ipv6/'))
print('  /plinth/sys/ipv6/ 的标签栏：')
for tab in tabs:
    print('   ', tab['text'], tab['url'], '← 当前' if tab['active'] else '')
assert [tab['text'] for tab in tabs] == ['网络', 'IPv6 网络', '静态路由']
assert [tab['active'] for tab in tabs] == [False, True, False], \
    '只有当前页对应的标签高亮'

tabs = submenu.entries(Request(path='/plinth/sys/networks/'))
assert [tab['active'] for tab in tabs] == [True, False, False], \
    '在 Networks 页上应高亮「网络」'
print('  /plinth/sys/networks/ 高亮：', tabs[0]['text'])

# 某个模块没装时，它的标签应当自动消失，而不是抛异常。
ROUTES.pop('routes:index')
tabs = submenu.entries(Request(path='/plinth/sys/ipv6/'))
assert [tab['text'] for tab in tabs] == ['网络', 'IPv6 网络']
print('  未安装静态路由模块时的标签栏：', [tab['text'] for tab in tabs])
ROUTES['routes:index'] = '/plinth/sys/routes/'

# install() 必须真的把标签栏塞进 Networks 页，而且只能包一层。
views_module = types.ModuleType('plinth.modules.networks.views')


class FakeNetworksView:
    """Minimal stand-in for plinth.modules.networks.views.NetworksAppView."""

    request = Request(path='/plinth/sys/networks/')
    original_calls = 0

    def get_context_data(self, **kwargs):
        type(self).original_calls += 1
        return {'menu_items': []}


views_module.NetworksAppView = FakeNetworksView
networks_module = types.ModuleType('plinth.modules.networks')
networks_module.views = views_module
modules_module = types.ModuleType('plinth.modules')
modules_module.networks = networks_module
plinth.modules = modules_module
sys.modules['plinth.modules'] = modules_module
sys.modules['plinth.modules.networks'] = networks_module
sys.modules['plinth.modules.networks.views'] = views_module

submenu.install()
submenu.install()  # 第二个模块重复安装时不能再包一层
context = FakeNetworksView().get_context_data()
assert [tab['text'] for tab in context['subsubmenu']] == \
    ['网络', 'IPv6 网络', '静态路由'], 'Networks 页应拿到完整标签栏'
assert FakeNetworksView.original_calls == 1, 'install() 只能包装一次'
assert FakeNetworksView._freedombox_network_submenu is True
print('  Networks 页上下文已注入标签栏，且只包装一次')
print('[通过] 标签顺序、高亮、缺模块降级与幂等安装都正确')

print()
print('全部测试通过')
