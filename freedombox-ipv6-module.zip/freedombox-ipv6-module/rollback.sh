#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 卸载 IPv6 路由器模块，恢复到安装前的状态。
#
# 用法：sudo bash rollback.sh [备份目录]
#
# 不传备份目录时自动使用 /root/freedombox-ipv6-module-backup 下最新的一份。
#
# 顺序很重要：先停服务、删 unit，再关转发、删 NAT66，最后才动设置文件。
# 反过来的话，systemd 可能在半途用残留脚本把转发和 NAT 规则又加回来。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/ipv6
ENABLED_DIR=/etc/freedombox/modules-enabled
CONFIG_DIR=/etc/freedombox-ipv6
SCRIPT_DIR=/usr/lib/freedombox-ipv6
SYSCTL_FILE=/etc/sysctl.d/99-freedombox-ipv6.conf
APPLY_UNIT=/etc/systemd/system/freedombox-ipv6.service
RA_UNIT=/etc/systemd/system/freedombox-ipv6-ra.service
BACKUP_ROOT=/root/freedombox-ipv6-module-backup

BACKUP_DIR=${1:-}
if [ -z "$BACKUP_DIR" ]; then
    BACKUP_DIR=$(ls -1d "$BACKUP_ROOT"/*/ 2>/dev/null | sort | tail -1)
    BACKUP_DIR=${BACKUP_DIR%/}
fi

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

echo "=============================================="
echo " FreedomBox IPv6 路由器模块卸载"
echo "=============================================="

echo ""
echo "== 1/6 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR" ]; then
    echo "使用备份目录：$BACKUP_DIR"
else
    echo "未找到备份目录，将按「全新安装」处理"
    BACKUP_DIR=''
fi

echo ""
echo "== 2/6 停止服务并删除 unit =="
systemctl stop freedombox-ipv6-ra 2>/dev/null || true
systemctl disable freedombox-ipv6-ra 2>/dev/null || true
systemctl stop freedombox-ipv6 2>/dev/null || true
systemctl disable freedombox-ipv6 2>/dev/null || true
systemctl stop fbx-ipv6-revert.timer 2>/dev/null || true
rm -f "$RA_UNIT" "$APPLY_UNIT"
systemctl daemon-reload 2>/dev/null || true
echo "已停止服务并删除 unit"

echo ""
echo "== 3/6 关闭转发并删除 NAT66 =="
nft delete table ip6 fbx_ipv6nat 2>/dev/null && echo "已删除 NAT66 表" \
    || echo "没有 NAT66 表"
sysctl -qw net.ipv6.conf.all.forwarding=0
echo "IPv6 转发已关闭：$(cat /proc/sys/net/ipv6/conf/all/forwarding)"

echo ""
echo "== 4/6 处理设置与脚本 =="
LAN=''
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/config" ]; then
    rm -rf "$CONFIG_DIR"
    cp -a "$BACKUP_DIR/config" "$CONFIG_DIR"
    echo "已恢复安装前的设置目录"
else
    # 记下当前的 LAN 网卡，稍后把它的 IPv6 改回 disabled。
    if [ -f "$CONFIG_DIR/settings.json" ]; then
        LAN=$(python3 -c "import json;print(json.load(open('$CONFIG_DIR/settings.json')).get('lan_device') or '')" 2>/dev/null)
    fi
    rm -rf "$CONFIG_DIR"
    echo "已删除设置目录"
fi
rm -rf "$SCRIPT_DIR"
rm -f "$SYSCTL_FILE"
echo "已删除脚本、sysctl 文件"

if [ -n "$LAN" ]; then
    CONN=$(nmcli -t -f NAME,DEVICE connection show 2>/dev/null \
        | awk -F: -v d="$LAN" '$NF == d {print $1; exit}')
    if [ -n "$CONN" ]; then
        nmcli connection modify "$CONN" ipv6.method disabled
        nmcli connection modify "$CONN" ipv6.addresses ''
        nmcli connection up "$CONN" >/dev/null 2>&1 || true
        echo "已把 $LAN（$CONN）的 IPv6 改回 disabled"
    fi
fi

echo ""
echo "== 5/6 移除模块代码与启用标记 =="
rm -f "$ENABLED_DIR/ipv6"
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/module" ]; then
    rm -rf "$MODULE_DIR"
    cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
    echo "已恢复原有模块目录"
else
    rm -rf "$MODULE_DIR"
    echo "已移除模块目录"
fi
if [ -n "$BACKUP_DIR" ] && [ -f "$BACKUP_DIR/enabled-ipv6" ]; then
    cp -a "$BACKUP_DIR/enabled-ipv6" "$ENABLED_DIR/ipv6"
    echo "已恢复原有启用标记"
fi

echo ""
echo "== 6/6 重启 Plinth 并核对网络 =="
systemctl restart plinth 2>/dev/null || true
sleep 3

echo "Plinth 状态：$(systemctl is-active plinth 2>/dev/null || echo 未知)"
echo "IPv4 默认路由：$(ip -4 route show default | head -1)"
echo "IPv6 默认路由：$(ip -6 route show default | head -1)"
echo "IPv6 转发：$(cat /proc/sys/net/ipv6/conf/all/forwarding)"
echo "NAT66 表：$(nft list table ip6 fbx_ipv6nat >/dev/null 2>&1 && echo 仍存在 || echo 已删除)"
echo ""
echo "提示：内网设备可能还缓存着之前拿到的 IPv6 地址，"
echo "      它们会在地址过期后自动消失，或重启设备即可清除。"
echo "=============================================="
