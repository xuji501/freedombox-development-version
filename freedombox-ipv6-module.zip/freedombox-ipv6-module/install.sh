#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 为 FreedomBox 安装 IPv6 路由器模块。
#
# 用法：sudo bash install.sh
#
# 安装内容：
#   /usr/lib/python3/dist-packages/plinth/modules/ipv6/   模块代码
#   /etc/freedombox/modules-enabled/ipv6                  启用标记
#   /etc/freedombox-ipv6/settings.json                    设置
#   /etc/freedombox-ipv6/dnsmasq6.conf                    路由通告配置
#   /etc/freedombox-ipv6/nat.nft                          NAT66 规则
#   /etc/sysctl.d/99-freedombox-ipv6.conf                 转发与 accept_ra
#   /usr/lib/freedombox-ipv6/apply.py                     开机恢复
#   /usr/lib/freedombox-ipv6/revert.py                    未确认改动的自动还原
#   /etc/systemd/system/freedombox-ipv6*.service          两个 unit
#
# 注意：安装本身**不会**改动网络。转发、路由通告、NAT66 都要在页面上
# 明确打开才会生效，默认是关闭的。
#
# 任何一步失败都会自动回滚到安装前的状态。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/ipv6
ENABLED_DIR=/etc/freedombox/modules-enabled
CONFIG_DIR=/etc/freedombox-ipv6
SCRIPT_DIR=/usr/lib/freedombox-ipv6
SYSCTL_FILE=/etc/sysctl.d/99-freedombox-ipv6.conf
APPLY_UNIT=/etc/systemd/system/freedombox-ipv6.service
RA_UNIT=/etc/systemd/system/freedombox-ipv6-ra.service
BACKUP_ROOT=/root/freedombox-ipv6-module-backup
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
SOURCE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

rollback() {
    echo "正在回滚..." >&2

    systemctl stop freedombox-ipv6-ra 2>/dev/null || true
    systemctl disable freedombox-ipv6-ra 2>/dev/null || true
    systemctl stop freedombox-ipv6 2>/dev/null || true
    systemctl disable freedombox-ipv6 2>/dev/null || true
    rm -f "$RA_UNIT" "$APPLY_UNIT"
    systemctl daemon-reload 2>/dev/null || true

    nft delete table ip6 fbx_ipv6nat 2>/dev/null || true

    # 只有在本次安装真的打开过转发时才需要关掉它。
    if [ -f "$BACKUP_DIR/forwarding.txt" ]; then
        if [ "$(cat "$BACKUP_DIR/forwarding.txt")" = "0" ]; then
            sysctl -qw net.ipv6.conf.all.forwarding=0 || true
        fi
    fi

    rm -f "$SYSCTL_FILE"
    rm -rf "$SCRIPT_DIR"

    if [ -d "$BACKUP_DIR/config" ]; then
        rm -rf "$CONFIG_DIR"
        cp -a "$BACKUP_DIR/config" "$CONFIG_DIR"
        echo "已恢复原有设置目录" >&2
    else
        rm -rf "$CONFIG_DIR"
    fi

    rm -f "$ENABLED_DIR/ipv6"

    if [ -d "$BACKUP_DIR/module" ]; then
        rm -rf "$MODULE_DIR"
        cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
        echo "已恢复原有模块目录" >&2
    else
        rm -rf "$MODULE_DIR"
        echo "已移除新模块目录" >&2
    fi

    if [ -f "$BACKUP_DIR/enabled-ipv6" ]; then
        cp -a "$BACKUP_DIR/enabled-ipv6" "$ENABLED_DIR/ipv6"
    fi

    systemctl restart plinth 2>/dev/null || true
    echo "回滚完成" >&2
}

echo "=============================================="
echo " FreedomBox IPv6 路由器模块安装"
echo "=============================================="

echo ""
echo "== 1/9 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
[ -f "$SOURCE_DIR/files/privileged.py" ] || fail "在 $SOURCE_DIR/files 下找不到模块源文件"
dpkg -s freedombox >/dev/null 2>&1 || fail "未检测到 freedombox 软件包"
echo "freedombox 版本：$(dpkg-query -W -f='${Version}' freedombox)"
command -v nmcli >/dev/null || fail "未找到 nmcli，本模块依赖 NetworkManager"
echo "NetworkManager：$(nmcli --version)"
[ -x /usr/sbin/dnsmasq ] || fail "未找到 /usr/sbin/dnsmasq，请先安装 dnsmasq-base"
command -v nft >/dev/null || fail "未找到 nft，本模块用 nftables 做 NAT66"
command -v systemd-run >/dev/null || fail "未找到 systemd-run，无法安装自动还原定时器"
echo "nft：$(nft --version)"
echo "网卡：$(ip -o link show | awk -F': ' '{print $2}' | grep -v '^lo$' | tr '\n' ' ')"

echo ""
echo "== 2/9 备份现有状态 =="
mkdir -p "$BACKUP_DIR"
if [ -d "$MODULE_DIR" ]; then
    cp -a "$MODULE_DIR" "$BACKUP_DIR/module"
    echo "已备份现有模块目录"
fi
if [ -f "$ENABLED_DIR/ipv6" ]; then
    cp -a "$ENABLED_DIR/ipv6" "$BACKUP_DIR/enabled-ipv6"
fi
if [ -d "$CONFIG_DIR" ]; then
    cp -a "$CONFIG_DIR" "$BACKUP_DIR/config"
    echo "已备份现有设置目录"
fi
cat /proc/sys/net/ipv6/conf/all/forwarding > "$BACKUP_DIR/forwarding.txt"
echo "IPv6 转发原值：$(cat "$BACKUP_DIR/forwarding.txt")"
mkdir -p "$BACKUP_DIR/nm-connections"
cp -a /etc/NetworkManager/system-connections/. "$BACKUP_DIR/nm-connections/" 2>/dev/null
nmcli -t -f NAME,DEVICE,UUID,ACTIVE connection show \
    > "$BACKUP_DIR/nm-list.txt" 2>/dev/null || true
ip -4 addr show > "$BACKUP_DIR/ipv4-addr.txt" 2>/dev/null || true
ip -6 addr show > "$BACKUP_DIR/ipv6-addr.txt" 2>/dev/null || true
ip -4 route show > "$BACKUP_DIR/route4.txt" 2>/dev/null || true
echo "备份目录：$BACKUP_DIR"

echo ""
echo "== 3/9 部署模块文件 =="
mkdir -p "$MODULE_DIR/templates"
install -m 644 "$SOURCE_DIR/files/__init__.py"           "$MODULE_DIR/__init__.py"   || fail "复制 __init__.py 失败"
install -m 644 "$SOURCE_DIR/files/manifest.py"           "$MODULE_DIR/manifest.py"   || fail "复制 manifest.py 失败"
install -m 644 "$SOURCE_DIR/files/forms.py"              "$MODULE_DIR/forms.py"      || fail "复制 forms.py 失败"
install -m 644 "$SOURCE_DIR/files/views.py"              "$MODULE_DIR/views.py"      || fail "复制 views.py 失败"
install -m 644 "$SOURCE_DIR/files/urls.py"               "$MODULE_DIR/urls.py"       || fail "复制 urls.py 失败"
install -m 644 "$SOURCE_DIR/files/privileged.py"         "$MODULE_DIR/privileged.py" || fail "复制 privileged.py 失败"
install -m 644 "$SOURCE_DIR/files/submenu.py"            "$MODULE_DIR/submenu.py"    || fail "复制 submenu.py 失败"
install -m 644 "$SOURCE_DIR/files/templates/ipv6.html"   "$MODULE_DIR/templates/ipv6.html" || fail "复制模板失败"
rm -rf "$MODULE_DIR/__pycache__"
chown -R root:root "$MODULE_DIR"
chmod 755 "$MODULE_DIR"
echo "已部署到 $MODULE_DIR"

echo ""
echo "== 4/9 语法检查 =="
for file in "$MODULE_DIR"/*.py; do
    if ! python3 -m py_compile "$file"; then
        rollback
        fail "语法错误：$file"
    fi
done
echo "全部 Python 文件语法正确"

echo ""
echo "== 5/9 启用模块 =="
mkdir -p "$ENABLED_DIR"
echo "plinth.modules.ipv6" > "$ENABLED_DIR/ipv6"
chmod 644 "$ENABLED_DIR/ipv6"
echo "已写入 $ENABLED_DIR/ipv6"

echo ""
echo "== 6/9 导入与表单检查 =="
CHECK_SCRIPT=$(mktemp /tmp/ipv6-check-XXXXXX.py)
cat > "$CHECK_SCRIPT" <<'PYEOF'
# web_framework.init() configures Django itself, so django.setup() must not
# be called before it.
from plinth import web_framework

web_framework.init()

import ipaddress  # noqa: E402

from plinth.modules.ipv6 import forms, privileged, views  # noqa: E402

assert views.IPv6AppView.app_id == 'ipv6'
assert views.IPv6AppView.form_class is forms.IPv6SettingsForm

form = forms.IPv6SettingsForm()
for field in ('wan_device', 'wan_method', 'lan_device', 'lan_enabled',
              'prefix'):
    assert field in form.fields, f'缺少表单字段 {field}'

for action in ('setup', 'get_devices', 'get_status', 'detect',
               'apply_settings', 'regenerate_prefix', 'uninstall'):
    assert callable(getattr(privileged, action)), f'缺少动作 {action}'

# 生成的前缀必须落在 fd00::/8 且是 /64。
prefix = privileged.generate_prefix()
network = ipaddress.ip_network(prefix)
assert network.prefixlen == 64, prefix
assert network.subnet_of(ipaddress.ip_network('fd00::/8')), prefix

# sysctl 顺序：forwarding 必须在 accept_ra 之前。
text = privileged.SYSCTL_CONTENT.format(
    accept_ra='net.ipv6.conf.ens32.accept_ra = 2')
assert text.index('all.forwarding = 1') < text.index('accept_ra = 2')

for script, name in ((privileged.APPLY_SCRIPT, 'apply.py'),
                     (privileged.REVERT_SCRIPT, 'revert.py')):
    compile(script, name, 'exec')
    assert 'plinth' not in script, f'{name} 不能依赖 Plinth'

from django.template.loader import get_template  # noqa: E402
template = get_template('ipv6.html')
print('模板来源：', template.origin.name)
print('模块导入、表单字段、前缀生成、脚本语法与模板加载全部正常')
PYEOF

if ! python3 "$CHECK_SCRIPT"; then
    rm -f "$CHECK_SCRIPT"
    rollback
    fail "导入检查未通过，已回滚"
fi
rm -f "$CHECK_SCRIPT"

echo ""
echo "== 7/9 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if ! systemctl is-active --quiet plinth; then
    rollback
    fail "Plinth 未能启动，已回滚"
fi
echo "Plinth 运行正常"

echo ""
echo "== 8/9 首次初始化 =="
(cd /usr/lib/python3/dist-packages && \
    timeout 120 python3 "$SOURCE_DIR/init_once.py")
INIT_RC=$?

if [ "$INIT_RC" -ne 0 ]; then
    rollback
    fail "首次初始化失败（退出码 $INIT_RC），已回滚"
fi

echo ""
echo "== 9/9 验证 =="
[ -f "$CONFIG_DIR/settings.json" ] || { rollback; fail "设置文件未生成"; }
[ -f "$CONFIG_DIR/dnsmasq6.conf" ] || { rollback; fail "路由通告配置未生成"; }
[ -f "$CONFIG_DIR/nat.nft" ] || { rollback; fail "NAT66 规则未生成"; }
[ -x "$SCRIPT_DIR/apply.py" ] || { rollback; fail "开机脚本未安装"; }
[ -x "$SCRIPT_DIR/revert.py" ] || { rollback; fail "还原脚本未安装"; }
[ -f "$APPLY_UNIT" ] || { rollback; fail "freedombox-ipv6.service 未安装"; }
[ -f "$RA_UNIT" ] || { rollback; fail "freedombox-ipv6-ra.service 未安装"; }

echo "设置文件：$(ls -l "$CONFIG_DIR/settings.json" | awk '{print $1, $3, $4}')"
echo "开机脚本：$(ls -l "$SCRIPT_DIR/apply.py" | awk '{print $1, $3, $4}')"

# 安装不能改变网络状态：转发必须还是原值，IPv4 默认路由必须还在。
NOW_FORWARDING=$(cat /proc/sys/net/ipv6/conf/all/forwarding)
BEFORE_FORWARDING=$(cat "$BACKUP_DIR/forwarding.txt")
[ "$NOW_FORWARDING" = "$BEFORE_FORWARDING" ] || {
    rollback
    fail "安装过程改变了 IPv6 转发状态（$BEFORE_FORWARDING → $NOW_FORWARDING）"
}
echo "IPv6 转发保持原值：$NOW_FORWARDING"

DEFAULT_V4=$(ip -4 route show default | head -1)
[ -n "$DEFAULT_V4" ] || { rollback; fail "IPv4 默认路由丢失，请立即检查网络"; }
echo "IPv4 默认路由：$DEFAULT_V4"

if nft list table ip6 fbx_ipv6nat >/dev/null 2>&1; then
    rollback
    fail "安装后出现了 NAT66 表，安装不应改动网络"
fi
echo "NAT66 表尚未创建（符合预期，需在页面上开启）"

CODE=$(curl -sk -o /dev/null -w '%{http_code}' \
    https://127.0.0.1/plinth/sys/ipv6/ 2>/dev/null || echo 000)
echo "IPv6 页面返回 HTTP $CODE（302 表示需要登录，属正常）"

echo ""
echo "== 安装结果 =="
python3 - <<'PYEOF'
import json
with open('/etc/freedombox-ipv6/settings.json') as handle:
    settings = json.load(handle)
print('WAN 网卡 :', settings.get('wan_device') or '（未设置）')
print('获取方式 :', settings.get('wan_method'))
print('LAN 网卡 :', settings.get('lan_device') or '（未设置）')
print('内网 IPv6:', '已开启' if settings.get('lan_enabled') else '未开启')
print('内网前缀 :', settings.get('prefix') or '（未设置）')
PYEOF

echo ""
echo "访问 https://<本机地址>/plinth/sys/ipv6/ 配置（入口在「系统 → 网络」菜单下）"
echo "回滚命令：sudo bash $SOURCE_DIR/rollback.sh $BACKUP_DIR"
echo "=============================================="
