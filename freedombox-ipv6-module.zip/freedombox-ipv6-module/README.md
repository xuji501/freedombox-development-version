# FreedomBox IPv6 路由器模块

给 Plinth 增加一个 IPv6 管理页面，位置在「系统 → 网络 → IPv6 网络」。

解决的问题：很多运营商已经提供 IPv6，但家庭网络里的设备拿不到 —— 因为路由器
没把 IPv6 转发给内网。这个模块让本机充当 IPv6 路由器：WAN 侧按所选方式向上游
获取地址，内网侧下发 ULA 前缀、通过路由通告让设备自动配置地址，并做 IPv6 转发
与 NAT66。

## 安装

```bash
sudo bash install.sh
```

9 步，任一步失败自动回滚。**安装本身不改动网络**：转发、路由通告、NAT66 默认
全是关闭的，必须在页面上明确打开才生效。安装脚本最后会专门核对这一点（转发值
必须与安装前一致、NAT66 表必须不存在）。

## 卸载

```bash
sudo bash rollback.sh              # 自动用最新备份
sudo bash rollback.sh /root/freedombox-ipv6-module-backup/20261027-160000
```

卸载会关转发、删 NAT66、删两个 unit，并把 LAN 网卡的 `ipv6.method` 改回
`disabled`。

## 页面结构

1. **当前状态** —— 上游 IPv6 是否获取到、IPv6 转发、路由通告服务、NAT66、
   IPv6 默认路由
2. **网卡地址** —— 每块网卡的 IPv6 获取方式、IPv6 地址（含 scope）、IPv4 地址
3. **IPv6 路由器设置** —— WAN 网卡 + 获取方式、LAN 网卡 + 是否开启、内网前缀
4. **说明** —— 为什么用 ULA + NAT66、`accept_ra=2` 的原因、自动还原机制

## 两个关键设计

### 为什么用 ULA + NAT66，而不是把上游 /64 拆开

运营商通常只通过 SLAAC 给一个 /64，并且拒绝 DHCPv6 前缀委派（PD）。没有 PD 就
没有可分配的前缀；把一个 /64 拆成更小的段会破坏 SLAAC（它要求 /64）。所以内网
用 ULA（`fd00::/8` 内的随机 /64），对外做 NAT66 —— 这正是所有家用路由器的做法。

好处是：即使上游暂时没有 IPv6，内网设备仍能用 ULA 互访；等上游开通后，不用再
改任何配置就能上外网。

### 为什么必须设 `accept_ra=2`

这是个很容易踩的坑：

```
net.ipv6.conf.all.forwarding = 1
net.ipv6.conf.ens32.accept_ra = 2      # 必须在上一行之后
```

打开 IPv6 转发时，内核会把**所有**接口的 `accept_ra` 重置为 0。默认值 1 表示
"只在没开转发时接受路由通告"，一旦开了转发就彻底不接受了。结果是 WAN 的地址
在下次续租时悄悄消失，而且不报错 —— 表现就是"IPv6 用着用着没了"。

`accept_ra=2` 的含义是"即使开了转发也接受路由通告"。顺序不能反：先写
`accept_ra=2` 再写 `forwarding=1`，前面的会被覆盖。

模块在三处都保证了这个顺序：生成的 `sysctl.d` 文件、`apply.py` 开机脚本、
`apply_settings()` 运行时。本地测试专门断言了这三处的先后关系。

## 踩过的三个坑

真机联调时踩到的，都写进代码和测试里了：

**1. `nmcli connection modify ipv6.method manual` 单独执行会失败**

```
Error: Failed to modify connection 'lan-static': ipv6.method:
       method 'manual' requires at least an address or a route
```

nmcli 是在**整条命令的属性都应用完之后**才校验 profile 的。所以方法和地址必须
写在同一条命令里：

```bash
nmcli connection modify lan-static \
    ipv6.method manual ipv6.addresses fd07:ada8:9656::1/64
```

分成两条的话，第一条就报错，第二条又因为 method 还是 `disabled` 而报错。最阴的
是 `nmcli device reapply` 此时仍然返回 0 —— 看起来"成功"，实际什么都没发生。
`_set_ipv6()` 现在检查每一条 nmcli 的返回码，并把这个报错原样抛到页面上。

**2. 关闭功能后，sysctl 文件不能留着 `forwarding=1`**

一开始不管开关状态都写 `net.ipv6.conf.all.forwarding = 1`。结果是：用户关掉内网
IPv6，当次生效，但**下次重启转发又自己开了**。现在按开关状态分别生成，关闭时写
`forwarding = 0` 并把 WAN 的 `accept_ra` 复位为 1。

**3. WAN 和 LAN 在同一二层网段时，本机的 RA 会被自己收到**

这台机器两块网卡是 VMware 的 vNIC，接在同一个虚拟交换机上。开启内网 IPv6 后，
`ip -6 route` 里出现了 `fd07:ada8:9656::/64 dev ens32 proto ra`，`ens32` 还通过
SLAAC 给自己配了一个 ULA 地址 —— 本机在 ens34 上发的路由通告，ens32 也收到了
（路由器请求被自己回应）。

这不是软件缺陷，真正的路由器 WAN/LAN 是物理隔离的。但页面会检测这种情况并给出
警告（`wan_sees_own_prefix`），免得用户对着 WAN 上莫名其妙的 `fd00::` 地址发懵。
如果确实需要隔离，把两块网卡接到不同网络，或用 VLAN 分开。

## 安全机制：改动会自动还原

改 LAN 网卡的地址是唯一能把人锁在门外的操作。所以 `apply_settings()` 有三层
保护：

1. **改前快照** —— 记录两块网卡对应 NetworkManager 连接的 `ipv6.method` 与
   `ipv6.addresses`
2. **改后验证** —— 检查 LAN/WAN 的 IPv4 地址是否还在、IPv4 默认路由是否还在、
   LAN 是否真的拿到了 `前缀::1`。任何一项不满足，立刻用快照还原并报错，
   **不写入设置文件**
3. **后备定时器** —— 动手之前用 `systemd-run --on-active=180` 挂一个定时器，
   3 分钟内没有确认（确认标记在全部验证通过后写入），`revert.py` 会自动把
   NetworkManager 设置、转发开关、NAT66 和 RA 服务一起还原

第 2 层和第 3 层都会还原**完整**的运行时状态，而不只是 NetworkManager：转发、
NAT66、RA 服务都按改动前的配置重新摆好。这一点是实测发现遗漏后补上的 ——
最初的回滚只还原了 NetworkManager，失败的开启会留下 `forwarding=1` 和 NAT 规则。

## 文件清单

| 路径 | 作用 | 权限 |
| --- | --- | --- |
| `/usr/lib/python3/dist-packages/plinth/modules/ipv6/` | 模块代码 | 755 / 644 |
| `/etc/freedombox/modules-enabled/ipv6` | 启用标记 | 644 |
| `/etc/freedombox-ipv6/settings.json` | 设置 | 644 |
| `/etc/freedombox-ipv6/dnsmasq6.conf` | 路由通告配置 | 644 |
| `/etc/freedombox-ipv6/nat.nft` | NAT66 规则 | 644 |
| `/etc/sysctl.d/99-freedombox-ipv6.conf` | 转发与 accept_ra | 644 |
| `/usr/lib/freedombox-ipv6/apply.py` | 开机恢复（不依赖 Plinth） | 755 |
| `/usr/lib/freedombox-ipv6/revert.py` | 未确认改动的自动还原 | 755 |
| `/etc/systemd/system/freedombox-ipv6.service` | oneshot，跑 apply.py | 644 |
| `/etc/systemd/system/freedombox-ipv6-ra.service` | dnsmasq 前台，发 RA | 644 |

## 路由通告为什么用第二个 dnsmasq

内网已经有一个 dnsmasq 在跑（DHCP 模块，负责 IPv4）。它和 RA 实例互不干扰：

| | IPv4 实例 | IPv6 RA 实例 |
| --- | --- | --- |
| 配置 | `/etc/freedombox-dhcp/dnsmasq.conf` | `/etc/freedombox-ipv6/dnsmasq6.conf` |
| DNS | 53 端口 | `port=0`，不做 DNS |
| DHCP | IPv4 67 | IPv6 547 |
| RA | 无 | `enable-ra` |

RA 实例只发路由通告和 DHCPv6，DNS 仍由 IPv4 那个实例应答。这样两边的配置各自
独立，改一个不会影响另一个。

`BindsTo=freedombox-ipv6.service` 让 RA 服务跟着 oneshot 走：oneshot 被停掉，
RA 也一起停。

## 已知边界

- **不做前缀委派（PD）**。如果上游给了 PD，本模块不会去申请；内网仍然是 ULA。
- **不做 IPv6 防火墙端口开放**。内网 → 外网的转发由 firewalld 的
  `fbx_int_to_ext_fwd` 策略放行（该策略没有 family 限制，IPv6 一并覆盖）；
  外网 → 内网的入站仍然被拦，需要单独开端口。
- **DNS 指向 `前缀::1`**。如果内网设备解析不了 IPv6 域名，它们通常会自动回落
  到 IPv4 DNS；也可以在设备上手工指定。
- **不改 WAN 的 IPv4 配置**。WAN 侧只动 `ipv6.method`。
- **`ipv6.method=ignore`** 表示"保持内核现状"，此时本模块不碰该网卡的 IPv6。

## 排错

```bash
# 看转发开没开
cat /proc/sys/net/ipv6/conf/all/forwarding

# 看 WAN 会不会接受路由通告（开了转发之后这一项必须是 2）
cat /proc/sys/net/ipv6/conf/ens32/accept_ra

# 看 RA 服务
systemctl status freedombox-ipv6-ra
journalctl -u freedombox-ipv6-ra -n 50

# 看 NAT66 规则
nft list table ip6 fbx_ipv6nat

# 看开机恢复有没有跑过
systemctl status freedombox-ipv6
journalctl -u freedombox-ipv6 -n 50

# 手工验证 RA 配置语法
dnsmasq --test --conf-file=/etc/freedombox-ipv6/dnsmasq6.conf
```

内网设备拿不到地址时，先在设备上看有没有 `前缀::/64` 的地址和默认路由；
没有的话通常是 RA 没发出去（`systemctl status freedombox-ipv6-ra`），
而不是前缀本身有问题。
