# SPDX-License-Identifier: AGPL-3.0-or-later
"""IPv6 routing for FreedomBox.

Two independent halves:

* the WAN side, which only decides how the box itself obtains an IPv6 address
  (SLAAC, DHCPv6, or not at all);
* the LAN side, which makes the box a router for its internal network: a ULA
  prefix on the LAN interface, router advertisements so clients configure
  themselves, IPv6 forwarding, and NAT66 towards the WAN.

NAT66 rather than prefix delegation is deliberate.  Most residential lines
hand out a single /64 by SLAAC and refuse DHCPv6 prefix delegation, so there
is nothing to sub-delegate; splitting the /64 would break SLAAC on the WAN.
Masquerading a ULA prefix is what every consumer router does in that
situation.
"""

import ipaddress
import json
import pathlib
import re
import secrets
import subprocess

from plinth import action_utils
from plinth.actions import privileged

CONFIG_DIR_PATH = '/etc/freedombox-ipv6'
SETTINGS_FILE = CONFIG_DIR_PATH + '/settings.json'
DNSMASQ_CONF_FILE = CONFIG_DIR_PATH + '/dnsmasq6.conf'
NAT_FILE = CONFIG_DIR_PATH + '/nat.nft'
PENDING_FILE = CONFIG_DIR_PATH + '/pending.json'
CONFIRMED_FILE = CONFIG_DIR_PATH + '/confirmed'
SYSCTL_FILE = '/etc/sysctl.d/99-freedombox-ipv6.conf'
APPLY_SCRIPT_PATH = '/usr/lib/freedombox-ipv6/apply.py'
REVERT_SCRIPT_PATH = '/usr/lib/freedombox-ipv6/revert.py'
APPLY_UNIT_PATH = '/etc/systemd/system/freedombox-ipv6.service'
RA_UNIT_PATH = '/etc/systemd/system/freedombox-ipv6-ra.service'

# Path objects derived from the strings above, so that anything written into a
# systemd unit or a script always uses the Linux path and never a
# platform-specific rendering.
CONFIG_DIR = pathlib.Path(CONFIG_DIR_PATH)
SETTINGS_PATH = pathlib.Path(SETTINGS_FILE)
DNSMASQ_CONF_PATH = pathlib.Path(DNSMASQ_CONF_FILE)
NAT_PATH = pathlib.Path(NAT_FILE)
SYSCTL_PATH = pathlib.Path(SYSCTL_FILE)
PENDING_PATH = pathlib.Path(PENDING_FILE)
CONFIRMED_PATH = pathlib.Path(CONFIRMED_FILE)
APPLY_SERVICE = 'freedombox-ipv6'
RA_SERVICE = 'freedombox-ipv6-ra'
BACKSTOP_UNIT = 'fbx-ipv6-revert'
BACKSTOP_SECONDS = 180

# Interfaces that can never carry a LAN or WAN prefix.
VIRTUAL_PREFIXES = ('lo', 'tun', 'tap', 'wg', 'ppp', 'docker', 'br-', 'veth')

WAN_METHODS = ('auto', 'dhcp', 'disabled', 'ignore')

DEFAULT_SETTINGS = {
    'version': 1,
    'wan_device': '',
    'wan_method': 'disabled',
    'lan_device': '',
    'lan_enabled': False,
    'prefix': '',
}

APPLY_SCRIPT = '''#!/usr/bin/python3
"""Re-apply the FreedomBox IPv6 router settings at boot.

Kept free of Plinth imports: forwarding, NAT66 and the router advertisement
daemon must come up even when Plinth is broken or being upgraded.
"""

import json
import subprocess
import sys

SETTINGS_PATH = '/etc/freedombox-ipv6/settings.json'
NAT_PATH = '/etc/freedombox-ipv6/nat.nft'
NAT_TABLE = 'ip6 fbx_ipv6nat'


def run(arguments):
    """Run a command, ignoring failures."""
    return subprocess.run(arguments, capture_output=True, text=True,
                          check=False)


def main():
    """Apply sysctl settings and the NAT66 table."""
    try:
        with open(SETTINGS_PATH, encoding='utf-8') as handle:
            settings = json.load(handle)
    except (OSError, ValueError):
        return

    if not settings.get('lan_enabled'):
        return

    wan = settings.get('wan_device') or ''
    prefix = settings.get('prefix') or ''

    # Order matters: turning forwarding on resets accept_ra to 0 on every
    # interface, so accept_ra=2 has to be written afterwards or the WAN stops
    # taking router advertisements.
    run(['sysctl', '-qw', 'net.ipv6.conf.all.forwarding=1'])
    if wan:
        run(['sysctl', '-qw', 'net.ipv6.conf.{}.accept_ra=2'.format(wan)])

    if not prefix:
        return

    run(['nft', 'delete', 'table'] + NAT_TABLE.split())
    result = run(['nft', '-f', NAT_PATH])
    if result.returncode != 0:
        sys.stderr.write(result.stderr)


main()
'''

REVERT_SCRIPT = '''#!/usr/bin/python3
"""Undo an IPv6 change that was never confirmed.

Runs from a transient systemd timer armed just before the change is applied.
If the browser never comes back to confirm, this puts the network back the
way it was, so a mistake cannot leave the box unreachable.

settings.json still holds the previous configuration at this point: the new
one is only written once everything has been verified, and a successful run
leaves a confirmation file behind that makes this script return immediately.
"""

import json
import os
import subprocess

PENDING_PATH = '/etc/freedombox-ipv6/pending.json'
CONFIRMED_PATH = '/etc/freedombox-ipv6/confirmed'
SETTINGS_PATH = '/etc/freedombox-ipv6/settings.json'
APPLY_SCRIPT = '/usr/lib/freedombox-ipv6/apply.py'
NAT_TABLE = ['ip6', 'fbx_ipv6nat']


def run(arguments):
    """Run a command, ignoring failures."""
    return subprocess.run(arguments, capture_output=True, text=True,
                          check=False)


def main():
    """Restore the saved NetworkManager settings and the runtime state."""
    if os.path.exists(CONFIRMED_PATH):
        return

    try:
        with open(PENDING_PATH, encoding='utf-8') as handle:
            snapshot = json.load(handle)
    except (OSError, ValueError):
        snapshot = {}

    for connection, values in snapshot.get('connections', {}).items():
        method = values.get('method') or 'disabled'
        addresses = values.get('addresses') or []
        # One call: nmcli rejects ipv6.method=manual on its own.
        arguments = ['nmcli', 'connection', 'modify', connection,
                     'ipv6.method', method]
        arguments += ['ipv6.addresses',
                      ','.join(addresses) if addresses else '']
        run(arguments)
        run(['nmcli', 'connection', 'up', connection])

    try:
        with open(SETTINGS_PATH, encoding='utf-8') as handle:
            settings = json.load(handle)
    except (OSError, ValueError):
        settings = {}

    if settings.get('lan_enabled'):
        # It was on before, so put the old forwarding and NAT66 back.
        run(['/usr/bin/python3', APPLY_SCRIPT])
        run(['systemctl', 'start', 'freedombox-ipv6-ra'])
    else:
        run(['systemctl', 'stop', 'freedombox-ipv6-ra'])
        run(['nft', 'delete', 'table'] + NAT_TABLE)
        run(['sysctl', '-qw', 'net.ipv6.conf.all.forwarding=0'])


main()
'''

RA_UNIT_CONTENT = '''[Unit]
Description=FreedomBox IPv6 router advertisements
After=network-online.target {apply_service}.service
Wants=network-online.target
BindsTo={apply_service}.service

[Service]
Type=simple
ExecStart=/usr/sbin/dnsmasq --keep-in-foreground --conf-file={conf}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
'''.format(apply_service=APPLY_SERVICE, conf=DNSMASQ_CONF_FILE)

APPLY_UNIT_CONTENT = '''[Unit]
Description=FreedomBox IPv6 routing (forwarding and NAT66)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/bin/python3 {script}

[Install]
WantedBy=multi-user.target
'''.format(script=APPLY_SCRIPT_PATH)

SYSCTL_CONTENT = '''# Generated by the FreedomBox IPv6 app.
# Forwarding first: setting it resets accept_ra on every interface, so the
# per-interface accept_ra below has to come after it.
net.ipv6.conf.all.forwarding = 1
{accept_ra}
'''

SYSCTL_CONTENT_DISABLED = '''# Generated by the FreedomBox IPv6 app.
# LAN IPv6 is off, so forwarding must stay off as well.  This file is what
# runs at boot: leaving forwarding=1 here would silently re-enable a feature
# the user had turned off.
net.ipv6.conf.all.forwarding = 0
{accept_ra}
'''


def _run(arguments: list[str]):
    """Run a command and capture its output."""
    try:
        return subprocess.run(arguments, capture_output=True, text=True,
                              check=False)
    except OSError as exception:
        return subprocess.CompletedProcess(arguments, 1, '',
                                          str(exception))


def _nmcli(*arguments):
    """Run nmcli and return the finished process."""
    return _run(['nmcli'] + list(arguments))


# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------

def read_settings() -> dict:
    """Return the saved settings, falling back to defaults."""
    settings = dict(DEFAULT_SETTINGS)
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return settings

    if not isinstance(data, dict):
        return settings

    for key in DEFAULT_SETTINGS:
        if key in data:
            settings[key] = data[key]

    settings['lan_enabled'] = bool(settings.get('lan_enabled'))
    return settings


def _write_settings(settings: dict):
    """Persist the settings atomically."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    temporary = SETTINGS_PATH.with_suffix('.json.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        json.dump(settings, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
    temporary.chmod(0o644)
    temporary.replace(SETTINGS_PATH)


# --------------------------------------------------------------------------
# Interfaces
# --------------------------------------------------------------------------

def _devices() -> list[str]:
    """Return the physical network interfaces."""
    process = _run(['ip', '-o', 'link', 'show'])
    names = []
    for line in process.stdout.splitlines():
        parts = line.split(':')
        if len(parts) < 2:
            continue
        name = parts[1].strip().split('@')[0]
        if name.startswith(VIRTUAL_PREFIXES):
            continue
        names.append(name)

    return sorted(set(names))


def _connection_for(device: str) -> str:
    """Return the NetworkManager connection name bound to a device."""
    process = _nmcli('-t', '-f', 'NAME,DEVICE', 'connection', 'show')
    for line in process.stdout.splitlines():
        if line.endswith(':' + device):
            return line[:-len(device) - 1].replace('\\:', ':')

    return ''


def _ipv6_method(device: str) -> str:
    """Return the IPv6 method NetworkManager uses for a device."""
    connection = _connection_for(device)
    if not connection:
        return ''

    process = _nmcli('-g', 'ipv6.method', 'connection', 'show', connection)
    return process.stdout.strip()


def _addresses(device: str) -> list[dict]:
    """Return the IPv6 addresses configured on a device."""
    process = _run(['ip', '-6', '-o', 'addr', 'show', 'dev', device])
    rows = []
    for line in process.stdout.splitlines():
        match = re.search(r'inet6 (\S+) scope (\S+)', line)
        if not match:
            continue
        rows.append({
            'address': match.group(1),
            'scope': match.group(2),
        })

    return rows


def _has_address(device: str, address: str) -> bool:
    """Return whether a device carries exactly this address."""
    for row in _addresses(device):
        if row['address'].split('/')[0] == address:
            return True

    return False


def _ipv4_addresses(device: str) -> list[str]:
    """Return the IPv4 addresses of a device in CIDR form."""
    process = _run(['ip', '-4', '-o', 'addr', 'show', 'dev', device])
    return re.findall(r'inet (\d+\.\d+\.\d+\.\d+/\d+)', process.stdout)


def _default_routes(family: str) -> list[str]:
    """Return the default routes of one family."""
    process = _run(['ip', '-6' if family == 'ipv6' else '-4', 'route',
                    'show', 'default'])
    return [line.strip() for line in process.stdout.splitlines()
            if line.strip()]


def _forwarding() -> bool:
    """Return whether the kernel forwards IPv6 packets."""
    try:
        text = pathlib.Path('/proc/sys/net/ipv6/conf/all/forwarding') \
            .read_text(encoding='utf-8')
    except OSError:
        return False

    return text.strip() == '1'


def _accept_ra(device: str) -> int:
    """Return the accept_ra setting of one device."""
    try:
        text = pathlib.Path(
            '/proc/sys/net/ipv6/conf/{}/accept_ra'.format(device)) \
            .read_text(encoding='utf-8')
    except OSError:
        return 0

    try:
        return int(text.strip())
    except ValueError:
        return 0


def _has_global(device: str) -> bool:
    """Return whether a device has a globally routable IPv6 address."""
    for row in _addresses(device):
        address = row['address'].split('/')[0]
        if row['scope'] != 'global':
            continue
        try:
            parsed = ipaddress.ip_address(address)
        except ValueError:
            continue
        # ULA is "global" as far as the kernel scope goes, but it cannot
        # reach the Internet on its own.
        if parsed.is_global and not parsed.is_private:
            return True

    return False


def _wan_sees_own_prefix(settings: dict) -> bool:
    """Return whether the WAN picked up this box's own ULA prefix.

    On a box whose two NICs sit on the same layer 2 segment (a VM with both
    virtual adapters on one switch, for instance), the router advertisements
    sent on the LAN are visible on the WAN as well, and the WAN happily takes
    an address and an on-link route from them.  A real router has physically
    separate segments and never sees this, but it is worth surfacing instead
    of leaving the operator to wonder why the WAN grew a fd00:: route.

    Both the address and the route are checked: the kernel sometimes installs
    the on-link route without keeping the address (duplicate address
    detection can fail and remove it), and the route alone is already a sign
    that advertisements are crossing segments.
    """
    prefix = settings.get('prefix') or ''
    wan = settings.get('wan_device') or ''
    if not prefix or not wan or not settings.get('lan_enabled'):
        return False

    try:
        network = ipaddress.ip_network(prefix)
    except ValueError:
        return False

    for row in _addresses(wan):
        try:
            address = ipaddress.ip_address(row['address'].split('/')[0])
        except ValueError:
            continue
        if address in network:
            return True

    process = _run(['ip', '-6', 'route', 'show', 'dev', wan])
    for line in process.stdout.splitlines():
        tokens = line.split()
        if not tokens:
            continue
        try:
            route = ipaddress.ip_network(tokens[0], strict=False)
        except ValueError:
            continue
        if route == network:
            return True

    return False


# --------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------

def _validate(settings: dict) -> dict:
    """Check the settings and return them in normalised form."""
    devices = _devices()
    wan = (settings.get('wan_device') or '').strip()
    lan = (settings.get('lan_device') or '').strip()

    if wan and wan not in devices:
        raise ValueError('WAN 网卡 {} 不存在'.format(wan))
    if lan and lan not in devices:
        raise ValueError('LAN 网卡 {} 不存在'.format(lan))
    if wan and lan and wan == lan:
        raise ValueError('WAN 和 LAN 不能是同一块网卡，否则流量会绕回自己')

    method = (settings.get('wan_method') or 'disabled').strip()
    if method not in WAN_METHODS:
        raise ValueError('获取方式只能是自动（SLAAC）、DHCPv6、关闭或忽略')

    enabled = bool(settings.get('lan_enabled'))
    prefix = (settings.get('prefix') or '').strip()

    if enabled:
        if not lan:
            raise ValueError('开启内网 IPv6 必须选择 LAN 网卡')
        if not wan:
            raise ValueError('开启内网 IPv6 必须选择 WAN 网卡，'
                             '否则无法确定向哪里转发')
        prefix = _normalise_prefix(prefix)

    return {
        'wan_device': wan,
        'wan_method': method,
        'lan_device': lan,
        'lan_enabled': enabled,
        'prefix': prefix,
    }


def _normalise_prefix(text: str) -> str:
    """Check a ULA prefix and return it as a /64 network."""
    text = (text or '').strip()
    if not text:
        text = generate_prefix()

    if '/' not in text:
        raise ValueError(
            '前缀需要写明长度，例如 {}；只写地址会被当成单个主机'.format(
                generate_prefix()))

    try:
        network = ipaddress.ip_network(text, strict=False)
    except ValueError as exception:
        raise ValueError('前缀格式不正确：{}'.format(text)) from exception

    if network.version != 6:
        raise ValueError('前缀必须是 IPv6 网段')

    if network.prefixlen != 64:
        raise ValueError(
            '内网前缀必须是 /64，当前是 /{}。'
            'SLAAC 要求 /64，其它长度客户端无法自动配置地址。'.format(
                network.prefixlen))

    if network.is_link_local:
        raise ValueError('不能用链路本地地址（fe80::/10）做内网前缀')
    if network.is_multicast:
        raise ValueError('不能用组播地址做内网前缀')

    if not network.subnet_of(ipaddress.ip_network('fd00::/8')) \
       and not network.is_global:
        raise ValueError(
            '{} 不是可用的内网前缀。建议使用 ULA（fd00::/8 之内）'.format(
                network))

    return str(network)


def generate_prefix() -> str:
    """Return a random ULA /64 from the fd00::/8 range.

    RFC 4193 asks for 40 bits of randomness, which leaves 16 bits of subnet
    numbering below it.  This app hands out the whole /64, so the random part
    is what makes the prefix unique to this site.
    """
    value = secrets.randbits(40)
    return 'fd{:02x}:{:04x}:{:04x}::/64'.format(
        (value >> 32) & 0xff, (value >> 16) & 0xffff, value & 0xffff)


# --------------------------------------------------------------------------
# Generated files
# --------------------------------------------------------------------------

def _dnsmasq_conf(settings: dict) -> str:
    """Return the router advertisement configuration."""
    lines = [
        '# Generated by the FreedomBox IPv6 app. Do not edit by hand.',
        '# This instance only does router advertisements and DHCPv6; DNS is',
        '# served by the existing dnsmasq on the IPv4 side.',
        'port=0',
    ]

    prefix = settings.get('prefix') or ''
    lan = settings.get('lan_device') or ''
    if not prefix or not lan:
        # Nothing to advertise yet; a valid but inert configuration keeps
        # the service from crash looping if it is ever started early.
        lines.append('# no prefix configured yet')
        return '\n'.join(lines) + '\n'

    network = ipaddress.ip_network(prefix)
    base = str(network.network_address).rstrip(':')

    lines += [
        'interface={}'.format(lan),
        'bind-dynamic',
        'dhcp-range={}::100,{}::1ff,64,12h'.format(base, base),
        'enable-ra',
        'dhcp-option=option6:dns-server,[{}::1]'.format(base),
        'quiet-dhcp6',
    ]
    return '\n'.join(lines) + '\n'


def _nat_rules(settings: dict) -> str:
    """Return the NAT66 table definition."""
    prefix = settings.get('prefix') or ''
    wan = settings.get('wan_device') or ''
    if not prefix or not wan:
        return '\n'.join([
            '# Generated by the FreedomBox IPv6 app. Do not edit by hand.',
            '# no prefix or WAN device configured yet',
            'table ip6 fbx_ipv6nat {',
            '    chain postrouting {',
            '        type nat hook postrouting priority srcnat;',
            '        policy accept;',
            '    }',
            '}',
            '',
        ])

    return '\n'.join([
        '# Generated by the FreedomBox IPv6 app. Do not edit by hand.',
        'table ip6 fbx_ipv6nat {',
        '    chain postrouting {',
        '        type nat hook postrouting priority srcnat; policy accept;',
        '        oifname "{}" ip6 saddr {} masquerade'.format(wan, prefix),
        '    }',
        '}',
        '',
    ])


def _write_generated_files(settings: dict):
    """Write the RA config, the NAT66 rules and the sysctl file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    DNSMASQ_CONF_PATH.write_text(_dnsmasq_conf(settings), encoding='utf-8')
    DNSMASQ_CONF_PATH.chmod(0o644)

    NAT_PATH.write_text(_nat_rules(settings), encoding='utf-8')
    NAT_PATH.chmod(0o644)

    accept_ra = ''
    if settings['wan_device']:
        # 2 while forwarding is on (otherwise the kernel ignores router
        # advertisements), 1 when it is off, which is the kernel default.
        value = 2 if settings['lan_enabled'] else 1
        accept_ra = 'net.ipv6.conf.{}.accept_ra = {}'.format(
            settings['wan_device'], value)

    template = SYSCTL_CONTENT if settings['lan_enabled'] \
        else SYSCTL_CONTENT_DISABLED
    SYSCTL_PATH.write_text(template.format(accept_ra=accept_ra),
                           encoding='utf-8')
    SYSCTL_PATH.chmod(0o644)

    for path, content, mode in (
            (pathlib.Path(APPLY_SCRIPT_PATH), APPLY_SCRIPT, 0o755),
            (pathlib.Path(REVERT_SCRIPT_PATH), REVERT_SCRIPT, 0o755)):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        path.chmod(mode)

    pathlib.Path(APPLY_UNIT_PATH).write_text(APPLY_UNIT_CONTENT,
                                             encoding='utf-8')
    pathlib.Path(APPLY_UNIT_PATH).chmod(0o644)
    pathlib.Path(RA_UNIT_PATH).write_text(RA_UNIT_CONTENT, encoding='utf-8')
    pathlib.Path(RA_UNIT_PATH).chmod(0o644)


# --------------------------------------------------------------------------
# NetworkManager
# --------------------------------------------------------------------------

def _split_addresses(text: str) -> list[str]:
    """Split nmcli's multi-value output into single addresses.

    Depending on the version and the -g/-t flag, nmcli separates list
    entries with ' | ', ';' or ','.  Accept all three.
    """
    return [item.strip() for item in re.split(r'\s*\|\s*|;|,', text or '')
            if item.strip()]


def _snapshot(devices: list[str]) -> dict:
    """Record the IPv6 settings of the connections behind these devices."""
    connections = {}
    for device in devices:
        if not device:
            continue
        connection = _connection_for(device)
        if not connection:
            continue
        method = _nmcli('-g', 'ipv6.method', 'connection', 'show',
                        connection).stdout.strip()
        addresses = _nmcli('-g', 'ipv6.addresses', 'connection', 'show',
                           connection).stdout
        connections[connection] = {
            'method': method or 'disabled',
            'addresses': _split_addresses(addresses),
        }

    return {'connections': connections}


def _restore(snapshot: dict):
    """Put the recorded NetworkManager settings back."""
    for connection, values in snapshot.get('connections', {}).items():
        _nmcli('connection', 'modify', connection,
               'ipv6.method', values.get('method') or 'disabled')
        addresses = values.get('addresses') or []
        _nmcli('connection', 'modify', connection, 'ipv6.addresses',
               ','.join(addresses) if addresses else '')
        _nmcli('connection', 'up', connection)


def _message(process) -> str:
    """Return the useful part of a failed command's output."""
    return (process.stderr.strip() or process.stdout.strip()
            or '命令返回 {}'.format(process.returncode))


def _set_ipv6(device: str, method: str, addresses: str = ''):
    """Point one device's connection at the given IPv6 method.

    Every property goes into a single nmcli call on purpose.  Setting
    ``ipv6.method manual`` on its own is rejected with "method 'manual'
    requires at least an address or a route", because nmcli validates the
    profile after applying the whole command line.  Splitting it into two
    calls fails on the first one and silently leaves the device unchanged.
    """
    connection = _connection_for(device)
    if not connection:
        raise ValueError('网卡 {} 没有对应的 NetworkManager 连接，'
                         '无法修改 IPv6 设置'.format(device))

    arguments = ['connection', 'modify', connection, 'ipv6.method', method]
    if method == 'manual':
        if not addresses:
            raise ValueError('内网 IPv6 至少需要一个地址')
        arguments += ['ipv6.addresses', addresses, 'ipv6.ignore-auto-dns',
                      'yes']
    else:
        arguments += ['ipv6.addresses', '', 'ipv6.ignore-auto-dns', 'no']

    process = _nmcli(*arguments)
    if process.returncode != 0:
        raise ValueError('修改 {} 的 IPv6 设置失败：{}'.format(
            device, _message(process)))

    # reapply keeps the IPv4 side up; a full reactivation would drop the very
    # link the browser is talking to us over.  It does apply address changes,
    # but it does not restart the DHCPv6 / SLAAC client, so those methods
    # still need a real reactivation.
    process = _nmcli('device', 'reapply', device)
    wanted = addresses.split('/')[0] if addresses else ''

    if wanted:
        applied = _has_address(device, wanted)
    elif method in ('auto', 'dhcp'):
        applied = False
    else:
        applied = process.returncode == 0

    if applied:
        return

    process = _nmcli('connection', 'up', connection)
    if process.returncode != 0:
        raise ValueError('应用 {} 的 IPv6 设置失败：{}'.format(
            device, _message(process)))


# --------------------------------------------------------------------------
# Backstop
# --------------------------------------------------------------------------

def _arm_backstop(snapshot: dict):
    """Undo the change automatically if it is not confirmed in time.

    Changing the LAN interface's addressing is the one operation that can
    lock someone out of the box.  A transient systemd timer restores the
    previous settings unless the caller confirms first.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PENDING_PATH.write_text(json.dumps(snapshot, ensure_ascii=False),
                            encoding='utf-8')
    PENDING_PATH.chmod(0o600)
    try:
        CONFIRMED_PATH.unlink()
    except OSError:
        pass

    _run(['systemctl', 'stop', BACKSTOP_UNIT + '.timer'])
    _run(['systemd-run', '--on-active={}'.format(BACKSTOP_SECONDS),
          '--unit=' + BACKSTOP_UNIT, '--collect',
          '/usr/bin/python3', REVERT_SCRIPT_PATH])


def _disarm_backstop():
    """Keep the change and stop the timer."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIRMED_PATH.write_text('ok\n', encoding='utf-8')
    _run(['systemctl', 'stop', BACKSTOP_UNIT + '.timer'])
    try:
        PENDING_PATH.unlink()
    except OSError:
        pass


# --------------------------------------------------------------------------
# Apply
# --------------------------------------------------------------------------

def _verify(settings: dict, before_ipv4: dict) -> list[str]:
    """Return the list of things the change broke."""
    problems = []

    lan = settings['lan_device']
    wan = settings['wan_device']

    if lan and before_ipv4.get(lan):
        current = _ipv4_addresses(lan)
        missing = [item for item in before_ipv4[lan] if item not in current]
        if missing:
            problems.append('LAN 口丢失了 IPv4 地址 {}'.format(
                ', '.join(missing)))

    if wan and before_ipv4.get(wan):
        current = _ipv4_addresses(wan)
        missing = [item for item in before_ipv4[wan] if item not in current]
        if missing:
            problems.append('WAN 口丢失了 IPv4 地址 {}'.format(
                ', '.join(missing)))

    if not _default_routes('ipv4'):
        problems.append('IPv4 默认路由消失了')

    if settings['lan_enabled']:
        wanted = '{}1'.format(settings['prefix'].split('/')[0])
        if not _has_address(lan, wanted):
            problems.append('LAN 口没有配置上 IPv6 地址 {}'.format(wanted))

    return problems


def _restore_runtime(settings: dict, strict: bool = False):
    """Bring forwarding, NAT66 and the services in line with the settings.

    ``strict`` turns a failed NAT66 load into an error; it is off during
    rollback, where the priority is to get back to a working state rather
    than to report every last problem.
    """
    action_utils.service_daemon_reload()

    enabled = settings.get('lan_enabled') and settings.get('wan_device') \
        and settings.get('prefix')

    if enabled:
        # Forwarding first: the kernel resets accept_ra to 0 on every
        # interface when forwarding is switched on, and a WAN that stops
        # taking router advertisements silently loses its address at the next
        # lease renewal.
        _run(['sysctl', '-qw', 'net.ipv6.conf.all.forwarding=1'])
        _run(['sysctl', '-qw', 'net.ipv6.conf.{}.accept_ra=2'.format(
            settings['wan_device'])])

        _run(['nft', 'delete', 'table', 'ip6', 'fbx_ipv6nat'])
        process = _run(['nft', '-f', str(NAT_PATH)])
        if strict and process.returncode != 0:
            raise ValueError('写入 NAT66 规则失败：{}'.format(
                _message(process)))

        action_utils.service_enable(APPLY_SERVICE)
        action_utils.service_start(APPLY_SERVICE)
        action_utils.service_enable(RA_SERVICE)
        action_utils.service_start(RA_SERVICE)
    else:
        action_utils.service_stop(RA_SERVICE)
        action_utils.service_disable(RA_SERVICE)
        _run(['nft', 'delete', 'table', 'ip6', 'fbx_ipv6nat'])
        _run(['sysctl', '-qw', 'net.ipv6.conf.all.forwarding=0'])
        if settings.get('wan_device'):
            # Put the WAN back to the kernel default; leaving it at 2 keeps a
            # forwarding-era setting around for no reason.
            _run(['sysctl', '-qw', 'net.ipv6.conf.{}.accept_ra=1'.format(
                settings['wan_device'])])


def _rollback(previous: dict, snapshot: dict):
    """Put NetworkManager and the runtime state back the way they were."""
    _run(['systemctl', 'stop', BACKSTOP_UNIT + '.timer'])
    _restore(snapshot)
    _write_generated_files(previous)
    _restore_runtime(previous)


def _apply_network(settings: dict):
    """Change NetworkManager, then the generated files and runtime state."""
    if settings['wan_device']:
        _set_ipv6(settings['wan_device'], settings['wan_method'])

    if settings['lan_device']:
        if settings['lan_enabled']:
            address = '{}1/64'.format(settings['prefix'].split('/')[0])
            _set_ipv6(settings['lan_device'], 'manual', address)
        else:
            _set_ipv6(settings['lan_device'], 'disabled')

    _write_generated_files(settings)
    _restore_runtime(settings, strict=True)


def _apply(settings: dict, previous: dict):
    """Apply the settings, rolling back if the box stops being reachable."""
    before_ipv4 = {
        device: _ipv4_addresses(device)
        for device in (settings['wan_device'], settings['lan_device'])
        if device
    }

    snapshot = _snapshot([settings['wan_device'], settings['lan_device']])
    _arm_backstop(snapshot)

    try:
        _apply_network(settings)
    except Exception:
        _rollback(previous, snapshot)
        raise

    problems = _verify(settings, before_ipv4)
    if problems:
        _rollback(previous, snapshot)
        raise ValueError(
            '{}。改动已撤销，网络恢复原状。'.format('；'.join(problems)))

    _disarm_backstop()
    _write_settings(settings)


# --------------------------------------------------------------------------
# Privileged actions
# --------------------------------------------------------------------------

@privileged
def setup():
    """Create the settings file, helper scripts and units."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    settings = read_settings()
    if not SETTINGS_PATH.exists():
        if not settings['prefix']:
            settings['prefix'] = generate_prefix()
        if not settings['wan_device'] or not settings['lan_device']:
            detected = _detect()
            settings['wan_device'] = settings['wan_device'] or \
                detected['wan_device']
            settings['lan_device'] = settings['lan_device'] or \
                detected['lan_device']
        _write_settings(settings)

    _write_generated_files(settings)
    action_utils.service_daemon_reload()


def _detect() -> dict:
    """Guess the WAN and LAN interfaces.

    The WAN is whichever interface currently carries the default route; the
    LAN is the remaining physical interface with an IPv4 address.
    """
    devices = _devices()
    wan = ''
    process = _run(['ip', '-4', 'route', 'show', 'default'])
    match = re.search(r'dev (\S+)', process.stdout)
    if match and match.group(1) in devices:
        wan = match.group(1)

    candidates = [device for device in devices
                  if device != wan and _ipv4_addresses(device)]
    lan = candidates[0] if candidates else ''

    return {'wan_device': wan, 'lan_device': lan,
            'prefix': generate_prefix()}


@privileged
def get_devices() -> list[str]:
    """Return the interfaces that can carry an IPv6 prefix."""
    return _devices()


@privileged
def get_status() -> dict:
    """Return everything the page needs to describe the current state."""
    settings = read_settings()

    interfaces = []
    for device in _devices():
        interfaces.append({
            'name': device,
            'connection': _connection_for(device),
            'method': _ipv6_method(device),
            'addresses': _addresses(device),
            'ipv4': _ipv4_addresses(device),
            'accept_ra': _accept_ra(device),
            'has_global': _has_global(device),
        })

    wan = settings['wan_device']
    upstream = bool(wan) and _has_global(wan) and \
        bool(_default_routes('ipv6'))

    ra_active = _run(['systemctl', 'is-active', RA_SERVICE]).stdout.strip()
    nat_present = _run(['nft', 'list', 'table', 'ip6',
                        'fbx_ipv6nat']).returncode == 0

    return {
        'settings': settings,
        'interfaces': interfaces,
        'devices': _devices(),
        'default_routes': _default_routes('ipv6'),
        'forwarding': _forwarding(),
        'ra_active': ra_active == 'active',
        'nat_present': nat_present,
        'upstream_has_ipv6': upstream,
        'wan_sees_own_prefix': _wan_sees_own_prefix(settings),
    }


@privileged
def detect() -> dict:
    """Return the guessed interfaces and a fresh ULA prefix."""
    return _detect()


@privileged
def apply_settings(wan_device: str, wan_method: str, lan_device: str,
                   lan_enabled: bool, prefix: str) -> dict:
    """Validate, apply and save the IPv6 configuration."""
    previous = read_settings()
    settings = _validate({
        'wan_device': wan_device,
        'wan_method': wan_method,
        'lan_device': lan_device,
        'lan_enabled': lan_enabled,
        'prefix': prefix or previous['prefix'],
    })

    _apply(settings, previous)
    return settings


@privileged
def regenerate_prefix() -> str:
    """Return a new random ULA prefix without applying it."""
    return generate_prefix()


@privileged
def uninstall():
    """Remove forwarding, NAT66, the services and the generated files."""
    settings = read_settings()

    action_utils.service_stop(RA_SERVICE)
    action_utils.service_disable(RA_SERVICE)
    action_utils.service_stop(APPLY_SERVICE)
    action_utils.service_disable(APPLY_SERVICE)

    _run(['nft', 'delete', 'table', 'ip6', 'fbx_ipv6nat'])
    _run(['sysctl', '-qw', 'net.ipv6.conf.all.forwarding=0'])

    for path in (APPLY_UNIT_PATH, RA_UNIT_PATH, str(SYSCTL_PATH),
                 APPLY_SCRIPT_PATH, REVERT_SCRIPT_PATH):
        try:
            pathlib.Path(path).unlink()
        except OSError:
            pass

    if settings['lan_device']:
        _nmcli('connection', 'modify',
               _connection_for(settings['lan_device']),
               'ipv6.method', 'disabled')

    action_utils.service_daemon_reload()

    for directory in (CONFIG_DIR, pathlib.Path(APPLY_SCRIPT_PATH).parent):
        try:
            directory.rmdir()
        except OSError:
            pass
