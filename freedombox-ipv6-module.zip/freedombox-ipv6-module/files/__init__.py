# SPDX-License-Identifier: AGPL-3.0-or-later
"""FreedomBox app to run the box as an IPv6 router."""

from django.utils.translation import gettext_lazy as _

from plinth import app as app_module
from plinth import menu

from . import manifest, privileged, submenu

_description = [
    _('IPv6 是新一代的互联网协议，与 IPv4 并行工作。很多运营商已经提供 IPv6，'
      '但家庭网络里的设备往往拿不到，因为路由器没有把 IPv6 转发给内网。'),
    _('这个页面让本机充当 IPv6 路由器：WAN 侧按所选方式向上游获取地址，'
      '内网侧下发一个 ULA 前缀（fd00::/8），由本机通过路由通告让内网设备'
      '自动配置地址，并做 IPv6 转发与 NAT66。'),
    _('如果上游暂时没有 IPv6，内网设备仍然可以用 ULA 地址互访，'
      '等上游开通后无需再改配置即可上外网。'),
]


class IPv6App(app_module.App):
    """FreedomBox app for IPv6 routing."""

    app_id = 'ipv6'

    _version = 1

    def __init__(self) -> None:
        """Create components for the app."""
        super().__init__()

        info = app_module.Info(app_id=self.app_id, version=self._version,
                               name=_('IPv6 网络'), icon='fa-globe',
                               description=_description, tags=manifest.tags)
        self.add(info)

        # Plinth only renders two levels of menu (the sections of the System
        # page and the cards inside them), so an item whose parent is the
        # Networks card would never be drawn anywhere.  Stay a sibling of the
        # Networks card instead, and add the shared tab bar to the Networks
        # page in post_init().
        menu_item = menu.Menu('menu-ipv6', info.name, info.icon, info.tags,
                              'ipv6:index', parent_url_name='system:system',
                              order=22)
        self.add(menu_item)

    def post_init(self):
        """Add the shared tab bar to the Networks page."""
        submenu.install()

    def setup(self, old_version):
        """Install the settings file, helpers and units."""
        super().setup(old_version)
        privileged.setup()
        if not old_version:
            self.enable()

    def uninstall(self):
        """Remove forwarding, NAT66 and the generated files."""
        super().uninstall()
        privileged.uninstall()
