# SPDX-License-Identifier: AGPL-3.0-or-later
"""URLs for the IPv6 module."""

from django.urls import re_path

from . import views

urlpatterns = [
    re_path(r'^sys/ipv6/$', views.IPv6AppView.as_view(), name='index'),
    re_path(r'^sys/ipv6/regenerate/$',
            views.PrefixRegenerateView.as_view(), name='regenerate'),
]
