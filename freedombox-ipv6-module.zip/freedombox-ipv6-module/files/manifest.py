# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tags for the IPv6 app."""

from django.utils.translation import gettext_lazy as _

tags = [_('网络'), _('IPv6'), _('系统')]
