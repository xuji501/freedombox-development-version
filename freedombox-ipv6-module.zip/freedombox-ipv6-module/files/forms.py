# SPDX-License-Identifier: AGPL-3.0-or-later
"""Django form for the IPv6 router settings."""

import ipaddress
import logging

from django import forms

from . import privileged

logger = logging.getLogger(__name__)

METHOD_CHOICES = [
    ('auto', '自动获取（SLAAC 路由通告）'),
    ('dhcp', 'DHCPv6'),
    ('disabled', '关闭（本机不获取 IPv6）'),
    ('ignore', '忽略（保持内核现状）'),
]


class IPv6SettingsForm(forms.Form):
    """WAN acquisition method and LAN sharing settings."""

    wan_device = forms.ChoiceField(
        label='WAN 网卡', required=False,
        help_text='接入上游网络的网卡，通常就是带默认路由的那一块。')

    wan_method = forms.ChoiceField(
        label='WAN 获取方式', choices=METHOD_CHOICES, initial='auto',
        help_text='上游给 IPv6 时用「自动」；只有 DHCPv6 时用 DHCPv6；'
                  '不想让本机获取 IPv6 就选「关闭」。')

    lan_device = forms.ChoiceField(
        label='LAN 网卡', required=False,
        help_text='对内提供 IPv6 的网卡，通常是内网那一块。')

    lan_enabled = forms.BooleanField(
        label='开启内网 IPv6', required=False,
        help_text='打开后会启用 IPv6 转发、路由通告和 NAT66，'
                  '内网设备将自动获得 IPv6 地址。')

    prefix = forms.CharField(
        label='内网前缀', required=False,
        widget=forms.TextInput(attrs={'placeholder': 'fd00:1234:5678::/64'}),
        help_text='必须是 /64 的 ULA 前缀（fd00::/8 之内）。留空会自动生成一个。')

    def __init__(self, *args, **kwargs):
        """Populate the interface lists from the live system."""
        super().__init__(*args, **kwargs)
        self.fields['wan_device'].choices = self._device_choices()
        self.fields['lan_device'].choices = self._device_choices()

    @staticmethod
    def _device_choices():
        """Return the interfaces as (value, label) pairs."""
        try:
            devices = privileged.get_devices()
        except Exception:
            logger.exception('Unable to list network interfaces')
            devices = []

        return [('', '未选择')] + [(name, name) for name in devices]

    def clean_prefix(self):
        """Reject a prefix that could not work with SLAAC."""
        text = (self.cleaned_data.get('prefix') or '').strip()
        if not text:
            return ''

        if '/' not in text:
            raise forms.ValidationError(
                '前缀需要写明长度，例如 fd00:1234:5678::/64')

        try:
            network = ipaddress.ip_network(text, strict=False)
        except ValueError as exception:
            raise forms.ValidationError(
                '前缀格式不正确：{}'.format(text)) from exception

        if network.version != 6:
            raise forms.ValidationError('前缀必须是 IPv6 网段')
        if network.prefixlen != 64:
            raise forms.ValidationError(
                '内网前缀必须是 /64，当前是 /{}。SLAAC 要求 /64。'.format(
                    network.prefixlen))
        if network.is_link_local or network.is_multicast:
            raise forms.ValidationError('不能使用链路本地或组播地址做前缀')

        return str(network)

    def clean(self):
        """Check the combination of choices, not just the single fields."""
        cleaned = super().clean()
        wan = cleaned.get('wan_device') or ''
        lan = cleaned.get('lan_device') or ''
        enabled = cleaned.get('lan_enabled')

        if enabled and not lan:
            raise forms.ValidationError('开启内网 IPv6 时必须选择 LAN 网卡')
        if enabled and not wan:
            raise forms.ValidationError(
                '开启内网 IPv6 时必须选择 WAN 网卡，否则无法确定向哪里转发')
        if wan and lan and wan == lan:
            raise forms.ValidationError('WAN 和 LAN 不能是同一块网卡')

        return cleaned
