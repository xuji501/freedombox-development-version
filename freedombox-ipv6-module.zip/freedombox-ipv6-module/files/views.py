# SPDX-License-Identifier: AGPL-3.0-or-later
"""Views for the IPv6 app."""

import logging

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse
from django.urls import NoReverseMatch, reverse
from django.views.generic import View

from plinth.views import AppView

from . import privileged, submenu
from .forms import IPv6SettingsForm

logger = logging.getLogger(__name__)

EMPTY_STATUS = {
    'settings': {},
    'interfaces': [],
    'devices': [],
    'default_routes': [],
    'forwarding': False,
    'ra_active': False,
    'nat_present': False,
    'upstream_has_ipv6': False,
}


def _module_url(name: str, fallback: str) -> str:
    """Resolve a URL of this module, tolerating a missing namespace."""
    try:
        return reverse('ipv6:{}'.format(name))
    except NoReverseMatch:
        return fallback


class IPv6AppView(AppView):
    """Show the IPv6 state and let the user change the settings."""

    app_id = 'ipv6'
    template_name = 'ipv6.html'
    form_class = IPv6SettingsForm

    def get_initial(self):
        """Pre-fill the form with what is currently saved."""
        initial = super().get_initial()
        try:
            settings = privileged.get_status()['settings']
        except Exception:
            logger.exception('Unable to read the IPv6 settings')
            return initial

        for key in ('wan_device', 'wan_method', 'lan_device', 'prefix'):
            if settings.get(key):
                initial[key] = settings[key]
        initial['lan_enabled'] = bool(settings.get('lan_enabled'))
        return initial

    def get_context_data(self, **kwargs):
        """Expose the live state next to the form."""
        context = super().get_context_data(**kwargs)

        try:
            status = privileged.get_status()
        except Exception:
            logger.exception('Unable to read the IPv6 status')
            status = dict(EMPTY_STATUS)

        context.update(status)
        context['subsubmenu'] = submenu.entries(self.request)
        context['regenerate_url'] = _module_url(
            'regenerate', '/plinth/sys/ipv6/regenerate/')
        return context

    def form_valid(self, form):
        """Apply the new configuration."""
        data = form.cleaned_data
        try:
            settings = privileged.apply_settings(
                data.get('wan_device') or '',
                data.get('wan_method') or 'disabled',
                data.get('lan_device') or '',
                bool(data.get('lan_enabled')),
                data.get('prefix') or '')
        except Exception as exception:
            logger.exception('Unable to apply the IPv6 settings')
            messages.error(self.request, '保存失败：{}'.format(exception))
            return self.form_invalid(form)

        if settings['lan_enabled']:
            messages.success(
                self.request,
                '已开启内网 IPv6：前缀 {}，内网设备将自动获得地址。'.format(
                    settings['prefix']))
        else:
            messages.success(self.request, '已保存 IPv6 设置。')

        return super().form_valid(form)


class PrefixRegenerateView(LoginRequiredMixin, View):
    """Hand back a fresh random ULA prefix for the form to use."""

    def get(self, request):
        """Return the prefix as JSON."""
        try:
            prefix = privileged.regenerate_prefix()
        except Exception:
            logger.exception('Unable to generate a prefix')
            return JsonResponse({'error': '生成前缀失败'}, status=500)

        return JsonResponse({'prefix': prefix})
