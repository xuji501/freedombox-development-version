"""Run the first-time setup for the DHCP app.

Plinth's startup routine only re-runs setup for apps that already have a
version recorded, or for essential apps, so a freshly added non-essential app
is never set up automatically.  This script runs the same work the app's
setup() method does, skipping the package component (dnsmasq-base is already
installed) because package installation requires a Plinth operation context.
"""

from plinth import web_framework

web_framework.init()

from plinth import app as app_module  # noqa: E402
from plinth import module_loader  # noqa: E402
from plinth.modules.dhcp import privileged  # noqa: E402

module_loader.load_modules()
app_module.apps_init()

app = app_module.App.get('dhcp')
print('当前 setup 版本:', app.get_setup_version(), '/ 目标:', app.info.version)

settings = privileged.read_settings()
print('已有设置:', settings)

if not settings['interface']:
    detected = privileged._detect_defaults()
    print('探测到的默认值:', detected)
    settings.update(detected)
    privileged._write_settings(settings)

print('应用配置（enabled=False 时不会改动网络）...')
privileged._apply(settings)

app.set_setup_version(app.info.version)
app.enable()

print('setup 完成，版本:', app.get_setup_version())
print('应用已启用:', app.is_enabled())
