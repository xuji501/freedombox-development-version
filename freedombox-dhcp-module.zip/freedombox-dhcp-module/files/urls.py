# SPDX-License-Identifier: AGPL-3.0-or-later
"""URLs for the DHCP module."""

from django.urls import re_path

from . import views

urlpatterns = [
    re_path(r'^apps/dhcp/$', views.DHCPAppView.as_view(), name='index'),
    re_path(r'^apps/dhcp/binding/$', views.BindingActionView.as_view(),
            name='binding'),
]
