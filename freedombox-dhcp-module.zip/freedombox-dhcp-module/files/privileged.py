# SPDX-License-Identifier: AGPL-3.0-or-later
"""Configure a dnsmasq based DHCP server.

FreedomBox normally lets NetworkManager run DHCP in 'shared' mode, but that
mode gives no control over the address pool, the default gateway or the DNS
servers handed to clients.  This module runs a dedicated dnsmasq instance with
a fully configurable pool instead, and keeps NetworkManager out of the way by
switching the matching connection from 'shared' to 'manual' while it is
active.
"""

import copy
import datetime
import grp
import ipaddress
import json
import logging
import os
import pathlib
import pwd
import re
import shutil
import subprocess
import time

from plinth import action_utils
from plinth.actions import privileged

SETTINGS_PATH = '/etc/freedombox-dhcp/settings.json'
CONFIG_PATH = '/etc/freedombox-dhcp/dnsmasq.conf'
CONFIG_DIR = pathlib.Path('/etc/freedombox-dhcp')

LEASE_PATH = '/var/lib/freedombox-dhcp/dnsmasq.leases'
STATE_DIR = pathlib.Path('/var/lib/freedombox-dhcp')

SERVICE_NAME = 'freedombox-dhcp'
UNIT_PATH = '/etc/systemd/system/freedombox-dhcp.service'
PID_PATH = '/run/freedombox-dhcp.pid'

NM_SHARED_LEASE_DIR = '/var/lib/NetworkManager'

SYSCTL_PATH = '/etc/sysctl.d/99-freedombox-dhcp.conf'

# Records the interface currently taken over from NetworkManager.  Without it
# a fresh install would bounce the connection back to shared mode for no
# reason, dropping the interface for a moment.
MANAGED_PATH = STATE_DIR / 'managed-interface'
MANAGED_IPV6_PATH = STATE_DIR / 'managed-ipv6'

# Records the network for which NAT and forwarding rules were installed.
STATE_NETWORK_PATH = STATE_DIR / 'nft-network'

# Standalone helper run from the unit's ExecStartPre so the rules survive a
# reboot, since NetworkManager no longer re-creates them.
RULES_SCRIPT_PATH = '/usr/lib/freedombox-dhcp/apply-rules.py'

DEFAULT_SETTINGS = {
    'enabled': False,
    'interface': '',
    'range_start': '',
    'range_end': '',
    'netmask': '255.255.255.0',
    'lease_time': '12h',
    'gateway': '',
    'dns': [],
    'domain': '',
    'static_hosts': [],
    # IPv6
    'ipv6_enabled': False,
    'ipv6_prefix': '',
    'ipv6_range_start': '',
    'ipv6_range_end': '',
    'ipv6_lease_time': '12h',
    'ipv6_dns': [],
    'ipv6_static_hosts': [],
}

UNIT_CONTENT = '''[Unit]
Description=FreedomBox DHCP server
Documentation=man:dnsmasq(8)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
# NetworkManager owns the NAT and forwarding rules while the interface is in
# shared mode.  Once we take over, nobody re-creates them, so they are
# installed here on every start.
ExecStartPre=/usr/bin/python3 {rules_script}
ExecStart=/usr/sbin/dnsmasq --keep-in-foreground --conf-file={config_path}
ExecReload=/bin/kill -HUP $MAINPID
Restart=on-failure
RestartSec=2

[Install]
WantedBy=multi-user.target
'''.format(rules_script=RULES_SCRIPT_PATH, config_path=CONFIG_PATH)

RULES_SCRIPT = '''#!/usr/bin/python3
"""Re-install the NAT and forwarding rules the DHCP app relies on.

Executed from the unit's ExecStartPre.  NetworkManager maintained these rules
while the interface was in shared mode; after the switch nobody else does.
"""

import ipaddress
import json
import subprocess

SETTINGS_PATH = '/etc/freedombox-dhcp/settings.json'


def run(arguments):
    """Run a command, ignoring failures."""
    return subprocess.run(arguments, capture_output=True, text=True,
                          check=False)


def active_connection(interface):
    """Return the NetworkManager connection active on *interface*."""
    process = run([
        'nmcli', '--terse', '--fields', 'NAME,DEVICE', 'connection', 'show',
        '--active'
    ])
    for line in process.stdout.splitlines():
        name, _, device = line.rpartition(':')
        if device == interface and name:
            return name

    return ''


def ipv6_addresses(connection):
    """Return the IPv6 addresses of a NetworkManager connection."""
    process = run([
        'nmcli', '--get-values', 'ipv6.addresses', 'connection', 'show',
        connection
    ])
    addresses = []
    # nmcli escapes the colons of an address in this output format.
    for item in process.stdout.replace(chr(92) + ':', ':').split(','):
        item = item.strip()
        if item:
            addresses.append(item)

    return addresses


def main():
    """Install the rules if the app is enabled."""
    try:
        with open(SETTINGS_PATH, encoding='utf-8') as handle:
            settings = json.load(handle)
    except (OSError, ValueError):
        return

    if not settings.get('enabled'):
        return

    interface = settings.get('interface', '')
    if not interface:
        return

    try:
        start = ipaddress.IPv4Address(settings['range_start'])
        netmask = ipaddress.IPv4Address(settings['netmask'])
    except (KeyError, ipaddress.AddressValueError):
        return

    network = str(ipaddress.IPv4Network('{}/{}'.format(start, netmask),
                                        strict=False))

    masquerade = 'ip saddr {} ip daddr != {} masquerade'.format(
        network, network)
    if masquerade not in run(
            ['nft', 'list', 'table', 'inet', 'nat']).stdout:
        run([
            'nft', 'add', 'rule', 'inet', 'nat', 'postrouting', 'ip', 'saddr',
            network, 'ip', 'daddr', '!=', network, 'masquerade'
        ])

    filter_text = run(['nft', 'list', 'table', 'inet', 'filter']).stdout

    accept_in = 'ip saddr {} iifname "{}" accept'.format(network, interface)
    if accept_in not in filter_text:
        run([
            'nft', 'add', 'rule', 'inet', 'filter', 'forward', 'ip', 'saddr',
            network, 'iifname', interface, 'accept'
        ])

    accept_out = ('ip daddr {} oifname "{}" ct state established,related '
                  'accept'.format(network, interface))
    if accept_out not in filter_text:
        run([
            'nft', 'add', 'rule', 'inet', 'filter', 'forward', 'ip', 'daddr',
            network, 'oifname', interface, 'ct', 'state',
            'established,related', 'accept'
        ])

    # Restore the IPv6 ULA address if IPv6 is enabled.  NetworkManager
    # owns the addresses of the connection, so the address has to be put
    # into its profile; adding it to the kernel directly would only
    # survive until the connection is activated again.
    if settings.get('ipv6_enabled') and settings.get('ipv6_prefix'):
        base = settings['ipv6_prefix'].split('/')[0].rstrip(':')
        address = base + '::1/64'
        connection = active_connection(interface)
        if connection:
            addresses = ipv6_addresses(connection)
            if address not in addresses:
                addresses.append(address)
                run([
                    'nmcli', 'connection', 'modify', connection,
                    'ipv6.method', 'manual',
                    'ipv6.addresses', ','.join(addresses)
                ])
                run(['nmcli', 'device', 'reapply', interface])
        else:
            # No connection to manage, fall back to the kernel.
            addr_text = run([
                'ip', '-6', 'addr', 'show', 'dev', interface]).stdout
            if address not in addr_text:
                run(['ip', '-6', 'addr', 'add', address, 'dev', interface])


main()
'''


def read_settings() -> dict:
    """Return current settings merged over defaults.

    Safe to call from unprivileged code: the file is world readable and any
    malformed value falls back to the default instead of raising.
    """
    settings = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_PATH, encoding='utf-8') as file_handle:
            data = json.load(file_handle)
    except (OSError, ValueError):
        return settings

    if not isinstance(data, dict):
        return settings

    if isinstance(data.get('enabled'), bool):
        settings['enabled'] = data['enabled']
    if isinstance(data.get('ipv6_enabled'), bool):
        settings['ipv6_enabled'] = data['ipv6_enabled']

    for key in ('interface', 'range_start', 'range_end', 'netmask',
                'lease_time', 'gateway', 'domain',
                'ipv6_prefix', 'ipv6_range_start', 'ipv6_range_end',
                'ipv6_lease_time'):
        value = data.get(key)
        if isinstance(value, str):
            settings[key] = value.strip()

    for dns_key in ('dns', 'ipv6_dns'):
        dns = data.get(dns_key)
        if isinstance(dns, list):
            settings[dns_key] = [item for item in dns if isinstance(item, str)]
        elif isinstance(dns, str):
            settings[dns_key] = [item.strip() for item in dns.split(',')
                                 if item.strip()]

    for hosts_key in ('static_hosts', 'ipv6_static_hosts'):
        hosts = data.get(hosts_key)
        if isinstance(hosts, list):
            parsed = []
            for item in hosts:
                if not isinstance(item, dict):
                    continue

                mac = item.get('mac')
                ip = item.get('ip')
                if not isinstance(mac, str) or not isinstance(ip, str):
                    continue
                if not mac.strip() or not ip.strip():
                    continue

                name = item.get('name')
                parsed.append({
                    'mac': mac.strip(),
                    'ip': ip.strip(),
                    'name': name.strip() if isinstance(name, str) else '',
                })

            settings[hosts_key] = parsed

    return settings


def _write_settings(settings: dict):
    """Persist settings atomically with world readable permissions."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    path = pathlib.Path(SETTINGS_PATH)
    temporary = path.with_suffix('.json.tmp')
    with temporary.open('w', encoding='utf-8') as file_handle:
        json.dump(settings, file_handle, ensure_ascii=False, indent=2)
        file_handle.write('\n')
    temporary.chmod(0o644)
    temporary.replace(path)


_HEX_DIGITS = set('0123456789abcdef')


def normalize_mac(value: str) -> str:
    """Return a MAC address in colon separated lower case form.

    Accepts aa:bb:cc:dd:ee:ff, aa-bb-cc-dd-ee-ff, aabb.ccdd.eeff and
    aabbccddeeff so that addresses can be pasted in whatever form a client
    list happens to use.
    """
    text = value.strip().lower().replace('-', ':')

    if '.' in text:
        text = text.replace('.', '')
        if len(text) != 12 or any(char not in _HEX_DIGITS for char in text):
            raise ValueError('MAC 地址格式不正确：{}'.format(value))
        return ':'.join(text[index:index + 2] for index in range(0, 12, 2))

    parts = text.split(':')
    if len(parts) == 1 and len(text) == 12:
        parts = [text[index:index + 2] for index in range(0, 12, 2)]

    if len(parts) != 6 or any(
            len(part) != 2 or any(char not in _HEX_DIGITS for char in part)
            for part in parts):
        raise ValueError('MAC 地址格式不正确：{}'.format(value))

    return ':'.join(parts)


def parse_static_hosts(text: str) -> list[dict]:
    """Parse the static host table from its text form.

    One host per line as 'MAC IP [name]'.  Commas, semicolons and whitespace
    are all accepted as separators, so a line copied out of a client list
    works as is.  Blank lines and lines starting with '#' are ignored.
    """
    hosts = []
    for number, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue

        parts = [part for part in re.split(r'[\s,;]+', line) if part]
        if len(parts) < 2:
            raise ValueError(
                '第 {} 行缺少 MAC 或 IP 地址：{}'.format(number, line))

        try:
            mac = normalize_mac(parts[0])
        except ValueError as exception:
            raise ValueError('第 {} 行：{}'.format(number, exception)) from \
                exception

        try:
            ip = str(ipaddress.IPv4Address(parts[1]))
        except ipaddress.AddressValueError as exception:
            raise ValueError(
                '第 {} 行 IP 地址不合法：{}'.format(number,
                                                   parts[1])) from exception

        hosts.append({
            'mac': mac,
            'ip': ip,
            'name': ' '.join(parts[2:]).strip(),
        })

    return hosts


def format_static_hosts(hosts: list[dict]) -> str:
    """Render the static host table back to its text form."""
    lines = []
    for host in hosts:
        line = '{} {}'.format(host['mac'], host['ip'])
        if host.get('name'):
            line += ' {}'.format(host['name'])
        lines.append(line)

    return '\n'.join(lines)


def render_config(settings: dict) -> str:
    """Build the dnsmasq configuration for the given settings."""
    lines = [
        '# Managed by FreedomBox. Do not edit by hand.',
        '# Changes are overwritten whenever the DHCP app is reconfigured.',
        '',
        '# NetworkManager used to run a dnsmasq in shared mode that answered',
        '# DNS queries on the LAN address. Keep answering them here so that',
        '# clients still pointing at this box keep working after the switch.',
        'port=53',
        'listen-address={}'.format(settings['gateway']),
        'bind-interfaces',
        'except-interface=lo',
        'no-hosts',
        'no-resolv',
    ]

    for server in settings['dns']:
        lines.append('server={}'.format(server))

    lines += [
        '',
        'interface={}'.format(settings['interface']),
        '',
        'dhcp-range={},{},{},{}'.format(settings['range_start'],
                                        settings['range_end'],
                                        settings['netmask'],
                                        settings['lease_time']),
        'dhcp-option=1,{}'.format(settings['netmask']),
        'dhcp-option=3,{}'.format(settings['gateway']),
        'dhcp-option=6,{}'.format(','.join(settings['dns'])),
    ]

    if settings.get('domain'):
        lines.append('dhcp-option=15,{}'.format(settings['domain']))

    # IPv6 DHCPv6 and Router Advertisement
    if settings.get('ipv6_enabled') and settings.get('ipv6_prefix'):
        # prefix is stored as "fd12:3456:7890::/64"; strip the length and
        # trailing colons so that the base ends right before the :: block.
        base = settings['ipv6_prefix'].split('/')[0].rstrip(':')
        ra_start = settings.get('ipv6_range_start') or '::100'
        ra_end = settings.get('ipv6_range_end') or '::1ff'
        ra_time = settings.get('ipv6_lease_time') or '12h'
        # If start/end are bare suffixes ("::100"), prepend the prefix
        if ra_start.startswith('::'):
            ra_start = base + ra_start
        if ra_end.startswith('::'):
            ra_end = base + ra_end
        lines += [
            '',
            '# IPv6 Router Advertisement and DHCPv6',
            'enable-ra',
            'dhcp-range={},{},{},{}'.format(ra_start, ra_end, 'slaac', ra_time),
            'dhcp-option=option6:dns-server,[{}]'.format(
                _ipv6_gateway_from_prefix(base)),
        ]
        for server in settings.get('ipv6_dns', []):
            if server:
                lines.append('dhcp-option=option6:dns-server,[{}]'.format(
                    server))

        if settings.get('ipv6_static_hosts'):
            lines.append('')
            lines.append('# Fixed MAC to IPv6 address assignments')
            for host in settings['ipv6_static_hosts']:
                line = 'dhcp-host=id:{},[{}]'.format(host['mac'], host['ip'])
                if host.get('name'):
                    line += ',{}'.format(host['name'])
                lines.append(line)

    if settings.get('static_hosts'):
        lines.append('')
        lines.append('# Fixed MAC to address assignments')
        for host in settings['static_hosts']:
            line = 'dhcp-host={},{}'.format(host['mac'], host['ip'])
            if host.get('name'):
                line += ',{}'.format(host['name'])
            lines.append(line)

    lines += [
        '',
        'dhcp-authoritative',
        'dhcp-leasefile={}'.format(LEASE_PATH),
        'pid-file={}'.format(PID_PATH),
        'log-dhcp',
        '',
    ]
    return '\n'.join(lines)


def _write_config(settings: dict):
    """Write the dnsmasq configuration file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    path = pathlib.Path(CONFIG_PATH)
    path.write_text(render_config(settings), encoding='utf-8')
    path.chmod(0o644)


def _write_unit():
    """Install the systemd unit for the dedicated dnsmasq instance."""
    path = pathlib.Path(UNIT_PATH)
    path.write_text(UNIT_CONTENT, encoding='utf-8')
    path.chmod(0o644)
    action_utils.service_daemon_reload()


def _remove_unit():
    """Remove the systemd unit if present."""
    path = pathlib.Path(UNIT_PATH)
    if path.exists():
        path.unlink()
        action_utils.service_daemon_reload()


def _run(arguments: list[str]):
    """Run a command and log its output without touching stdout."""
    try:
        process = subprocess.run(arguments, capture_output=True, text=True,
                                 check=False)
    except OSError as exception:
        logging.exception('Unable to execute %s', arguments[0])
        return subprocess.CompletedProcess(arguments, 1, '', str(exception))

    if process.stdout.strip():
        logging.info('%s: %s', arguments[0], process.stdout.strip())
    if process.returncode != 0:
        logging.warning('%s failed (%s): %s', arguments, process.returncode,
                        process.stderr.strip())
    return process


def _nm_connection_for(interface: str) -> str | None:
    """Return the NetworkManager connection name active on *interface*."""
    process = _run([
        'nmcli', '--terse', '--fields', 'NAME,DEVICE', 'connection', 'show',
        '--active'
    ])
    for line in process.stdout.splitlines():
        name, _, device = line.rpartition(':')
        if device == interface and name:
            return name

    return None


def _interface_address(interface: str) -> str | None:
    """Return the IPv4 address of *interface* in CIDR notation."""
    process = _run(['ip', '-o', '-4', 'addr', 'show', interface])
    for token in process.stdout.split():
        if '/' in token and token[0].isdigit():
            return token

    return None


def _nm_set_method(interface: str, method: str) -> str:
    """Switch the NetworkManager connection of *interface* to *method*.

    'shared' makes NetworkManager run its own dnsmasq with an automatically
    computed pool.  'manual' keeps the static address but stops that dnsmasq,
    which is what we need before our own instance can bind port 67.
    """
    connection = _nm_connection_for(interface)
    if not connection:
        raise ValueError(
            'No active NetworkManager connection found for interface {}.'
            .format(interface))

    if method == 'manual':
        address = _interface_address(interface)
        if not address:
            raise ValueError(
                'Interface {} has no IPv4 address to keep.'.format(interface))

        _run([
            'nmcli', 'connection', 'modify', connection, 'ipv4.method',
            'manual', 'ipv4.addresses', address
        ])
    else:
        _run([
            'nmcli', 'connection', 'modify', connection, 'ipv4.method',
            'shared'
        ])

    _run(['nmcli', 'connection', 'up', connection])
    return connection


def _nm_ipv6_addresses(connection: str) -> list[str]:
    """Return the IPv6 addresses configured on a NetworkManager connection.

    NetworkManager applies the addresses of a connection from its profile
    every time the connection is activated, and it drops every address it
    does not know about.  The addresses therefore have to be managed
    through the profile instead of the kernel.
    """
    process = _run([
        'nmcli', '--get-values', 'ipv6.addresses', 'connection', 'show',
        connection
    ])
    addresses = []
    # nmcli escapes the colons of an address in this output format.
    for item in process.stdout.replace('\\:', ':').split(','):
        item = item.strip()
        if item:
            addresses.append(item)

    return addresses


def _nm_ipv6_method(connection: str) -> str:
    """Return the ipv6.method configured on a NetworkManager connection."""
    process = _run([
        'nmcli', '--get-values', 'ipv6.method', 'connection', 'show', connection
    ])
    return process.stdout.strip()


def _nm_set_ipv6_addresses(connection: str, addresses: list[str],
                           method: str):
    """Write the IPv6 addresses and method of a NetworkManager connection.

    The complete list has to be given, NetworkManager 1.52 does not
    understand the '+'/'-' syntax for adding or removing a single entry.
    """
    _run([
        'nmcli', 'connection', 'modify', connection, 'ipv6.method', method,
        'ipv6.addresses', ','.join(addresses)
    ])


def _nm_reapply(interface: str, connection: str):
    """Apply the profile of *connection* to *interface* again.

    A reapply refreshes the addresses without taking the link down, which
    keeps the running DHCP service alive.  Only if that is not possible
    the connection is brought up again.
    """
    process = _run(['nmcli', 'device', 'reapply', interface])
    if process.returncode != 0:
        _run(['nmcli', 'connection', 'up', connection])


def _kernel_ipv6(interface: str) -> str:
    """Return the IPv6 address listing of *interface*."""
    return _run(['ip', '-6', 'addr', 'show', 'dev', interface]).stdout


def _wait_for_ipv6(interface: str, address: str, present: bool,
                   timeout: float = 5.0) -> bool:
    """Wait until *address* is (or is no longer) configured.

    NetworkManager applies a profile change asynchronously, so the
    kernel needs a moment to reflect it.  dnsmasq must not be started
    before the address exists, otherwise the router advertisement goes
    out without a matching source address.
    """
    deadline = time.monotonic() + timeout
    while True:
        if (address in _kernel_ipv6(interface)) == present:
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(0.2)


def _ensure_ip_forward():
    """Make sure IPv4 forwarding survives a reboot.

    NetworkManager enables forwarding implicitly while a connection is in
    shared mode.  Once we take the interface out of shared mode that no longer
    happens, so the setting is made explicit.
    """
    try:
        current = pathlib.Path('/proc/sys/net/ipv4/ip_forward').read_text()
        if current.strip() != '1':
            pathlib.Path('/proc/sys/net/ipv4/ip_forward').write_text('1\n')
    except OSError:
        logging.exception('Unable to enable IPv4 forwarding at runtime')

    try:
        pathlib.Path(SYSCTL_PATH).write_text('net.ipv4.ip_forward = 1\n',
                                             encoding='utf-8')
    except OSError:
        logging.exception('Unable to persist IPv4 forwarding')


def _migrate_leases(interface: str):
    """Seed the lease file with leases handed out by NetworkManager.

    Reusing the existing MAC to address assignments means clients keep the
    address they already have when the service is taken over, instead of
    getting a new one on the next renewal.
    """
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    target = pathlib.Path(LEASE_PATH)
    if target.exists():
        return

    source = pathlib.Path(NM_SHARED_LEASE_DIR) / \
        'dnsmasq-{}.leases'.format(interface)
    if source.exists():
        try:
            shutil.copy2(source, target)
            logging.info('Imported existing leases from %s', source)
        except OSError:
            logging.exception('Unable to import leases from %s', source)
        return

    target.touch()


def _ipv6_gateway_from_prefix(prefix: str) -> str:
    """Return the ::1 address for a given ULA prefix."""
    # Strip the prefix length and any trailing colons so that the base
    # ends right before the :: block.
    base = prefix.split('/')[0].rstrip(':')
    return base + '::1'


def _ipv6_address_from_prefix(prefix: str) -> str:
    """Return the gateway address of a ULA prefix in CIDR notation."""
    return _ipv6_gateway_from_prefix(prefix) + '/64'


def _ipv6_network_from_prefix(prefix: str):
    """Return an IPv6Network object for the given prefix string."""
    text = prefix.strip()
    if '/' not in text:
        text += '/64'
    return ipaddress.IPv6Network(text, strict=False)


def _read_ipv6_neighbours(interface: str) -> list[dict]:
    """Return MAC-to-IPv6 mappings from the kernel neighbour table."""
    process = _run(['ip', '-6', 'neigh', 'show', 'dev', interface])
    neighbours = []
    for line in process.stdout.splitlines():
        # Format: 2001:db8::1 lladdr aa:bb:cc:dd:ee:ff [router] REACHABLE
        # The state is the last field, an optional 'router' flag may sit
        # in front of it.  Entries in FAILED state have no lladdr.
        parts = line.split()
        if len(parts) < 4 or parts[1] != 'lladdr':
            continue
        addr = parts[0]
        mac = parts[2].lower()
        state = parts[-1]
        try:
            ip_obj = ipaddress.IPv6Address(addr)
            if ip_obj.is_link_local or ip_obj.is_loopback:
                continue
        except ipaddress.AddressValueError:
            continue
        neighbours.append({
            'address': addr,
            'mac': mac,
            'state': state,
        })
    return neighbours


def _read_ipv6_leases() -> list[dict]:
    """Return IPv6 leases from the dnsmasq lease file.

    dnsmasq's lease file format for DHCPv6 is similar to IPv4 but the
    address field contains an IPv6 address and the DUID is longer.
    """
    leases = []
    try:
        for line in pathlib.Path(LEASE_PATH).read_text(
                encoding='utf-8').splitlines():
            parts = line.split()
            if len(parts) < 5:
                continue
            addr = parts[2]
            try:
                ip_obj = ipaddress.IPv6Address(addr)
                if ip_obj.version != 6:
                    continue
            except ipaddress.AddressValueError:
                continue
            if ip_obj.is_link_local or ip_obj.is_loopback:
                continue
            try:
                expires = int(parts[0])
            except ValueError:
                expires = 0
            if expires == 0:
                expires_text = '永久'
            else:
                expires_text = datetime.datetime.fromtimestamp(
                    expires).strftime('%Y-%m-%d %H:%M')
            # For IPv6, the client-id field is the DUID; we normalise
            # the MAC from the DUID if possible (last 6 hex pairs).
            duid = parts[1]
            mac = _duid_to_mac(duid) or duid
            leases.append({
                'expires': expires,
                'expires_text': expires_text,
                'mac': mac,
                'address': addr,
                'hostname': '' if parts[3] == '*' else parts[3],
                'client_id': duid,
            })
    except OSError:
        pass
    return leases


def _duid_to_mac(duid: str) -> str | None:
    """Try to extract a MAC address from a DHCPv6 DUID.

    DUID-LL (link-layer) and DUID-LLT both end with the 6-byte MAC.
    The DUID is typically shown as a colon-separated hex string.
    """
    parts = duid.lower().split(':')
    if len(parts) >= 6:
        mac_parts = parts[-6:]
        if all(len(p) == 2 and set(p) <= _HEX_DIGITS for p in mac_parts):
            return ':'.join(mac_parts)
    return None


def _network_of(settings: dict) -> str:
    """Return the CIDR network the pool lives in."""
    start = ipaddress.IPv4Address(settings['range_start'])
    netmask = ipaddress.IPv4Address(settings['netmask'])
    return str(ipaddress.IPv4Network('{}/{}'.format(start, netmask),
                                     strict=False))


def _nft_table_text(family: str, table: str) -> str:
    """Return the ruleset text of a single nftables table."""
    return _run(['nft', 'list', 'table', family, table]).stdout


def _install_nft_rules(network: str, interface: str):
    """Install masquerade and forwarding rules for *network*.

    NetworkManager adds exactly these rules while the interface is in shared
    mode and removes them again once it leaves that mode.  Without them the
    clients still get an address but lose connectivity, so they have to be
    reinstated by us.
    """
    masquerade = 'ip saddr {} ip daddr != {} masquerade'.format(
        network, network)
    if masquerade not in _nft_table_text('inet', 'nat'):
        _run([
            'nft', 'add', 'rule', 'inet', 'nat', 'postrouting', 'ip', 'saddr',
            network, 'ip', 'daddr', '!=', network, 'masquerade'
        ])

    filter_text = _nft_table_text('inet', 'filter')

    accept_in = 'ip saddr {} iifname "{}" accept'.format(network, interface)
    if accept_in not in filter_text:
        _run([
            'nft', 'add', 'rule', 'inet', 'filter', 'forward', 'ip', 'saddr',
            network, 'iifname', interface, 'accept'
        ])

    accept_out = ('ip daddr {} oifname "{}" ct state established,related '
                  'accept'.format(network, interface))
    if accept_out not in filter_text:
        _run([
            'nft', 'add', 'rule', 'inet', 'filter', 'forward', 'ip', 'daddr',
            network, 'oifname', interface, 'ct', 'state',
            'established,related', 'accept'
        ])


def _remove_nft_rules(network: str, interface: str):
    """Remove the rules installed by :func:`_install_nft_rules`."""
    targets = [
        ('inet', 'nat', 'postrouting',
         'ip saddr {} ip daddr != {} masquerade'.format(network, network)),
        ('inet', 'filter', 'forward',
         'ip saddr {} iifname "{}" accept'.format(network, interface)),
        ('inet', 'filter', 'forward',
         'ip daddr {} oifname "{}" ct state established,related accept'
         .format(network, interface)),
    ]

    for family, table, chain, pattern in targets:
        output = _run(['nft', '-a', 'list', 'table', family, table]).stdout
        for line in output.splitlines():
            if pattern in line and 'handle' in line:
                handle = line.rsplit('handle', 1)[1].strip()
                _run([
                    'nft', 'delete', 'rule', family, table, chain, 'handle',
                    handle
                ])


def _fix_lease_permissions():
    """Give the unprivileged dnsmasq user write access to its state dir.

    dnsmasq drops privileges to 'nobody' right after binding its sockets, so
    the lease file has to be owned by that user or renewals are never
    persisted.
    """
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    try:
        uid = pwd.getpwnam('nobody').pw_uid
        gid = grp.getgrnam('nogroup').gr_gid
    except KeyError:
        uid = gid = 65534

    os.chmod(STATE_DIR, 0o755)
    try:
        os.chown(STATE_DIR, uid, gid)
    except OSError:
        logging.exception('Unable to change owner of %s', STATE_DIR)

    lease = pathlib.Path(LEASE_PATH)
    if lease.exists():
        os.chmod(lease, 0o644)
        try:
            os.chown(lease, uid, gid)
        except OSError:
            logging.exception('Unable to change owner of %s', lease)


def _write_rules_script():
    """Install the helper that restores the nftables rules at boot."""
    path = pathlib.Path(RULES_SCRIPT_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(RULES_SCRIPT, encoding='utf-8')
    path.chmod(0o755)


def _managed_interface() -> str:
    """Return the interface currently taken over from NetworkManager."""
    try:
        return MANAGED_PATH.read_text(encoding='utf-8').strip()
    except OSError:
        return ''


def _set_managed(interface: str):
    """Remember which interface we took over from NetworkManager."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    MANAGED_PATH.write_text(interface, encoding='utf-8')


def _read_network() -> str:
    """Return the network the installed nftables rules belong to."""
    try:
        return STATE_NETWORK_PATH.read_text(encoding='utf-8').strip()
    except OSError:
        return ''


def _remember_network(network: str):
    """Remember which network the installed nftables rules belong to."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_NETWORK_PATH.write_text(network, encoding='utf-8')


def _clear_managed():
    """Forget the interface we took over."""
    try:
        MANAGED_PATH.unlink()
    except OSError:
        pass


def _set_managed_ipv6(state: dict):
    """Record the IPv6 state we changed so it can be restored later."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    MANAGED_IPV6_PATH.write_text(json.dumps(state, ensure_ascii=False),
                                  encoding='utf-8')


def _read_managed_ipv6() -> dict:
    """Return the IPv6 state we recorded, or an empty dict.

    Older versions of this module wrote a plain '<interface> <address>'
    line, which is still understood.
    """
    try:
        text = MANAGED_IPV6_PATH.read_text(encoding='utf-8').strip()
    except OSError:
        return {}

    if not text:
        return {}

    try:
        state = json.loads(text)
    except ValueError:
        parts = text.split(None, 1)
        if len(parts) == 2:
            return {'interface': parts[0], 'address': parts[1]}
        return {}

    return state if isinstance(state, dict) else {}


def _clear_managed_ipv6():
    """Forget the IPv6 address we added."""
    try:
        MANAGED_IPV6_PATH.unlink()
    except OSError:
        pass


def _nm_ipv6_add(interface: str, address: str) -> bool:
    """Add the IPv6 address to the NetworkManager profile.

    NetworkManager owns the addresses of an interface and drops every
    address it does not know about as soon as it activates the
    connection.  An address added with 'ip addr add' is therefore gone
    again after the next reconnect, which is why the address is stored
    in the connection profile instead.
    """
    connection = _nm_connection_for(interface)
    if not connection:
        logging.warning('No NetworkManager connection for interface %s',
                        interface)
        return False

    addresses = _nm_ipv6_addresses(connection)
    method = _nm_ipv6_method(connection)

    # Remember how the connection looked before, so that it can be
    # restored exactly when IPv6 is switched off again.  An earlier
    # record is kept, otherwise a repeated save would remember our own
    # address as part of the original state.
    state = _read_managed_ipv6()
    if (state.get('address') == address
            and state.get('connection') == connection):
        original_addresses = state.get('addresses')
        original_method = state.get('method')
    else:
        original_addresses = list(addresses)
        original_method = method

    if address not in addresses:
        # Keep the addresses NetworkManager was already managing and add
        # ours on top of them.
        addresses.append(address)

    # A static address requires the manual method.
    process = _run([
        'nmcli', 'connection', 'modify', connection, 'ipv6.method', 'manual',
        'ipv6.addresses', ','.join(addresses)
    ])
    if process.returncode != 0:
        return False

    _set_managed_ipv6({
        'interface': interface,
        'connection': connection,
        'address': address,
        'method': original_method,
        'addresses': original_addresses,
    })

    # Re-apply the profile so the change takes effect right away.  A
    # reapply keeps the link up, unlike 'connection up'.
    _nm_reapply(interface, connection)

    # NetworkManager applies the profile asynchronously.  dnsmasq is
    # started right after this call and must not advertise a prefix
    # before the gateway address actually exists.
    if not _wait_for_ipv6(interface, address, True):
        logging.warning('IPv6 address %s did not appear on %s', address,
                        interface)

    return True


def _nm_ipv6_remove(interface: str, address: str) -> bool:
    """Remove the IPv6 address from the NetworkManager profile.

    The addresses and the method the connection had before this module
    touched it are restored, so that switching IPv6 off leaves no trace.
    """
    state = _read_managed_ipv6()
    original_addresses = state.get('addresses')
    original_method = state.get('method')

    connection = state.get('connection')
    if not connection:
        connection = _nm_connection_for(interface)
    if not connection:
        logging.warning('No NetworkManager connection for interface %s',
                        interface)
        return False

    if original_addresses is None:
        # No record of the previous state, just drop our address.
        addresses = _nm_ipv6_addresses(connection)
        original_addresses = [item for item in addresses if item != address]
        original_method = _nm_ipv6_method(connection)
        if not original_addresses:
            original_method = 'disabled'
        elif original_method == 'disabled':
            original_method = 'manual'

    process = _run([
        'nmcli', 'connection', 'modify', connection, 'ipv6.method',
        original_method, 'ipv6.addresses', ','.join(original_addresses)
    ])
    if process.returncode != 0:
        return False

    _nm_reapply(interface, connection)
    _wait_for_ipv6(interface, address, False)
    return True


def _remove_managed_ipv6(interface: str, settings: dict,
                         old_settings: dict | None = None):
    """Remove the IPv6 ULA address we previously configured.

    The address is taken out of the NetworkManager profile, which is the
    only way to make it disappear for good: a bare 'ip addr del' is
    undone the next time NetworkManager activates the connection.
    """
    prefix = settings.get('ipv6_prefix') or (
        old_settings or {}).get('ipv6_prefix')
    address = _ipv6_address_from_prefix(prefix) if prefix else None

    state = _read_managed_ipv6()
    if state.get('address'):
        address = state['address']
        interface = state.get('interface') or interface

    if not address:
        return

    _nm_ipv6_remove(interface, address)

    # Also drop the address from the kernel in case it was added
    # manually before this module took ownership of it.  Asking the
    # kernel first avoids a pointless 'address not found' failure in the
    # log when NetworkManager already removed it.
    if address in _kernel_ipv6(interface):
        _run(['ip', '-6', 'addr', 'del', address, 'dev', interface])

    _clear_managed_ipv6()


def _apply(settings: dict, old_settings: dict | None = None):
    """Bring the system in line with *settings*."""
    interface = settings['interface']

    # Stop our own instance first so port 67 is free while NetworkManager
    # reconfigures the interface.
    action_utils.service_disable(SERVICE_NAME)

    if settings['enabled']:
        network = _network_of(settings)
        _write_config(settings)
        _write_rules_script()
        _write_unit()
        _migrate_leases(interface)

        # Only reconfigure NetworkManager when the interface actually changes
        # hands.  Re-running setup for the same interface must not bounce it.
        if _managed_interface() != interface:
            if _managed_interface():
                try:
                    _nm_set_method(_managed_interface(), 'shared')
                except ValueError:
                    logging.warning('Unable to release previous interface')

            _nm_set_method(interface, 'manual')

        # NetworkManager removes its own masquerade and forwarding rules as
        # soon as the interface leaves shared mode, so ours have to go in
        # afterwards.  Drop the rules of a previous network first.
        previous_network = _read_network()
        if previous_network and previous_network != network:
            _remove_nft_rules(previous_network, interface)

        _install_nft_rules(network, interface)
        _remember_network(network)

        _set_managed(interface)
        _ensure_ip_forward()
        _fix_lease_permissions()

        # Bring up the IPv6 ULA address so that clients can reach the
        # gateway after they construct their own addresses from the RA.
        # The address is owned by NetworkManager, otherwise it disappears
        # again as soon as the connection is activated.
        if settings.get('ipv6_enabled') and settings.get('ipv6_prefix'):
            address = _ipv6_address_from_prefix(settings['ipv6_prefix'])
            _nm_ipv6_add(interface, address)
        else:
            _remove_managed_ipv6(interface, settings, old_settings)

        action_utils.service_enable(SERVICE_NAME)
        action_utils.service_start(SERVICE_NAME)
    else:
        # Give the port back to NetworkManager's own dnsmasq, but only if we
        # were the ones who took it away.
        previous = _managed_interface()
        if previous:
            previous_network = _read_network()
            if previous_network:
                _remove_nft_rules(previous_network, previous)

            # Remove the IPv6 ULA address we added.
            _remove_managed_ipv6(previous, settings, old_settings)

            try:
                _nm_set_method(previous, 'shared')
            except ValueError:
                logging.warning('No connection to restore to shared mode')

            _clear_managed()
            try:
                STATE_NETWORK_PATH.unlink()
            except OSError:
                pass


@privileged
def setup():
    """Write configuration and start the service if it is enabled."""
    try:
        settings = read_settings()
        if not settings['interface']:
            # Nothing configured yet.  Detect a sensible default so that the
            # page can present a usable form on first visit.
            settings.update(_detect_defaults())
            _write_settings(settings)

        _apply(settings, None)
    except Exception:
        # Never let a broken network state prevent Plinth from starting.
        logging.exception('Unable to apply DHCP settings during setup')


def _detect_defaults() -> dict:
    """Guess pool, gateway and DNS from the current shared connection."""
    result = {}
    for interface, connection in _nm_connections().items():
        method = _run([
            'nmcli', '--terse', '--fields', 'ipv4.method', 'connection',
            'show', connection
        ]).stdout.strip().partition(':')[2]
        if method != 'shared':
            continue

        address = _interface_address(interface)
        if not address:
            continue

        ip_interface = ipaddress.ip_interface(address)
        network = ip_interface.network
        hosts = list(network.hosts())
        if len(hosts) < 3:
            continue

        result['interface'] = interface
        result['range_start'] = str(hosts[9] if len(hosts) > 10 else hosts[1])
        result['range_end'] = str(hosts[-1])
        result['netmask'] = str(network.netmask)
        result['gateway'] = str(ip_interface.ip)
        result['dns'] = _system_dns_servers()
        break

    return result


def _nm_connections() -> dict[str, str]:
    """Return a mapping of interface to active connection name."""
    process = _run([
        'nmcli', '--terse', '--fields', 'NAME,DEVICE', 'connection', 'show',
        '--active'
    ])
    connections = {}
    for line in process.stdout.splitlines():
        name, _, device = line.rpartition(':')
        if name and device:
            connections[device] = name
    return connections


def _system_dns_servers() -> list[str]:
    """Return the DNS servers currently configured on the system."""
    servers = []
    try:
        for line in pathlib.Path('/etc/resolv.conf').read_text(
                encoding='utf-8').splitlines():
            if line.startswith('nameserver'):
                parts = line.split()
                if len(parts) > 1 and parts[1] not in servers:
                    servers.append(parts[1])
    except OSError:
        pass

    # Never announce the loopback stub resolver to clients.
    servers = [server for server in servers
               if not server.startswith('127.')]
    return servers[:3] or ['223.5.5.5', '119.29.29.29']


@privileged
def get_settings() -> dict:
    """Return current settings."""
    return read_settings()


@privileged
def get_interfaces() -> list[dict]:
    """Return the interfaces that can host a DHCP server."""
    process = _run(['nmcli', '--terse', '--fields', 'type,device', 'device'])
    interfaces = []
    for line in process.stdout.splitlines():
        type_, _, device = line.partition(':')
        if type_ not in ('ethernet', 'wifi') or not device:
            continue

        interfaces.append({
            'name': device,
            'address': _interface_address(device) or '',
            'type': type_,
        })

    return interfaces


@privileged
def get_status() -> dict:
    """Return runtime state for the app page."""
    process = _run([
        'systemctl', 'is-active', '{}.service'.format(SERVICE_NAME)
    ])
    active = process.stdout.strip()

    # Only report the port as listening when it is our own instance holding
    # it.  NetworkManager runs its own dnsmasq on port 67 whenever the
    # interface is in shared mode, which would otherwise look like success.
    listening = False
    if active == 'active':
        sockets = _run(['ss', '-uln'])
        for line in sockets.stdout.splitlines():
            if ':67 ' in line or line.rstrip().endswith(':67'):
                listening = True
                break

    leases = []
    try:
        for line in pathlib.Path(LEASE_PATH).read_text(
                encoding='utf-8').splitlines():
            parts = line.split()
            if len(parts) < 5:
                continue

            try:
                expires = int(parts[0])
            except ValueError:
                continue

            if expires == 0:
                expires_text = '永久'
            else:
                expires_text = datetime.datetime.fromtimestamp(
                    expires).strftime('%Y-%m-%d %H:%M')

            leases.append({
                'expires': expires,
                'expires_text': expires_text,
                'mac': parts[1],
                'address': parts[2],
                'hostname': '' if parts[3] == '*' else parts[3],
                'client_id': parts[4],
            })
    except OSError:
        pass

    leases.sort(key=lambda item: item['address'])

    settings = read_settings()
    interface = settings.get('interface', '')

    # IPv6 neighbours (from SLAAC / RA) and DHCPv6 leases
    ipv6_neighbours = []
    if interface:
        ipv6_neighbours = _read_ipv6_neighbours(interface)
        # Only addresses out of our own prefix belong to this server.  The
        # interface may carry other global addresses, for instance the ULA
        # NetworkManager used while the connection was in shared mode.
        prefix = settings.get('ipv6_prefix', '')
        if prefix:
            try:
                network = _ipv6_network_from_prefix(prefix)
            except ValueError:
                network = None
            if network is not None:
                ipv6_neighbours = [
                    item for item in ipv6_neighbours
                    if ipaddress.IPv6Address(item['address']) in network
                ]
    ipv6_leases = _read_ipv6_leases()

    # Merge neighbours and leases by MAC, preferring lease data when available
    ipv6_by_mac = {}
    for n in ipv6_neighbours:
        ipv6_by_mac[n['mac']] = {
            'mac': n['mac'],
            'address': n['address'],
            'hostname': '',
            'source': 'SLAAC/RA',
            'state': n.get('state', ''),
        }
    for lease in ipv6_leases:
        mac = lease['mac']
        if mac in ipv6_by_mac:
            ipv6_by_mac[mac]['address'] = lease['address']
            ipv6_by_mac[mac]['hostname'] = lease['hostname']
            ipv6_by_mac[mac]['source'] = 'DHCPv6'
            ipv6_by_mac[mac]['expires_text'] = lease['expires_text']
        else:
            ipv6_by_mac[mac] = {
                'mac': mac,
                'address': lease['address'],
                'hostname': lease['hostname'],
                'source': 'DHCPv6',
                'expires_text': lease['expires_text'],
                'state': '',
            }
    ipv6_clients = sorted(ipv6_by_mac.values(), key=lambda x: x['address'])

    return {
        'service_active': active == 'active',
        'listening': listening,
        'leases': leases,
        'static_hosts': settings['static_hosts'],
        'ipv6_enabled': settings.get('ipv6_enabled', False),
        'ipv6_prefix': settings.get('ipv6_prefix', ''),
        'ipv6_static_hosts': settings.get('ipv6_static_hosts', []),
        'ipv6_clients': ipv6_clients,
        'config_path': CONFIG_PATH,
    }


def _pool_context(settings: dict):
    """Return the pool network and gateway, or (None, None) if unusable.

    Used when a binding has to be checked on its own, outside a full settings
    save.  A half configured pool simply skips the address checks instead of
    raising, so that a binding can still be recorded while the service is
    switched off.
    """
    try:
        start = ipaddress.IPv4Address(settings['range_start'])
        netmask = ipaddress.IPv4Address(settings['netmask'])
        gateway = ipaddress.IPv4Address(settings['gateway'])
        network = ipaddress.IPv4Network('{}/{}'.format(start, netmask),
                                        strict=False)
    except (KeyError, ipaddress.AddressValueError,
            ipaddress.NetmaskValueError):
        return None, None

    return network, gateway


def _validate_static_hosts(settings: dict, network=None, gateway=None):
    """Check the IPv4 binding table, optionally against the pool network."""
    seen_macs = {}
    seen_ips = {}
    for host in settings.get('static_hosts', []):
        mac = host['mac']
        try:
            address = ipaddress.IPv4Address(host['ip'])
        except ipaddress.AddressValueError as exception:
            raise ValueError(
                '静态绑定的 IP 地址不合法：{}'.format(host['ip'])) from exception

        if mac in seen_macs:
            raise ValueError(
                'MAC {} 出现了两次（{} 和 {}）'.format(mac, seen_macs[mac],
                                                      host['ip']))
        seen_macs[mac] = host['ip']

        if host['ip'] in seen_ips:
            raise ValueError(
                'IP {} 被分配给了两个 MAC（{} 和 {}）'.format(
                    host['ip'], seen_ips[host['ip']], mac))
        seen_ips[host['ip']] = mac

        if network is None:
            continue

        if address not in network:
            raise ValueError(
                '静态绑定的 IP {} 不在 {} 网段内'.format(address, network))

        if address == gateway:
            raise ValueError('静态绑定的 IP {} 与网关冲突'.format(address))

        if address in (network.network_address, network.broadcast_address):
            raise ValueError(
                '静态绑定的 IP {} 是网络地址或广播地址，不能使用'.format(
                    address))


def _validate(settings: dict):
    """Validate settings and raise ValueError with a readable message."""
    if not settings['enabled']:
        # A disabled server keeps whatever is on the form, so that values are
        # not lost when the service is switched off temporarily.
        return

    interface = settings['interface']
    if not interface:
        raise ValueError('A network interface must be selected')

    try:
        start = ipaddress.IPv4Address(settings['range_start'])
        end = ipaddress.IPv4Address(settings['range_end'])
        gateway = ipaddress.IPv4Address(settings['gateway'])
        netmask = ipaddress.IPv4Address(settings['netmask'])
    except ipaddress.AddressValueError as exception:
        raise ValueError('Invalid address: {}'.format(exception)) from exception

    # Anchor the network on the pool start so that the netmask describes the
    # subnet the pool actually lives in.  Building it from 0.0.0.0 would
    # always yield 0.0.0.0/24 and reject every real address.
    try:
        network = ipaddress.IPv4Network('{}/{}'.format(start, netmask),
                                        strict=False)
    except (ipaddress.AddressValueError, ipaddress.NetmaskValueError) as \
            exception:
        raise ValueError(
            'Invalid netmask: {}'.format(exception)) from exception

    for label, address in (('Pool end', end), ('Gateway', gateway)):
        if address not in network:
            raise ValueError('{} {} is outside network {}'.format(
                label, address, network))

    if int(start) > int(end):
        raise ValueError('Pool start must not be higher than pool end')

    if int(start) <= int(gateway) <= int(end):
        raise ValueError(
            'Gateway must not fall inside the pool range, otherwise the '
            'gateway address may be handed to a client')

    if not settings['dns']:
        raise ValueError('At least one DNS server is required')

    for server in settings['dns']:
        try:
            ipaddress.IPv4Address(server)
        except ipaddress.AddressValueError as exception:
            raise ValueError('Invalid DNS server: {}'.format(
                server)) from exception

    _validate_static_hosts(settings, network, gateway)
    _validate_ipv6(settings)


def _validate_ipv6(settings: dict):
    """Validate IPv6 settings."""
    if not settings.get('ipv6_enabled'):
        return

    prefix = (settings.get('ipv6_prefix') or '').strip()
    if not prefix:
        raise ValueError('启用 IPv6 DHCPv6 前请先填写 ULA 前缀')

    try:
        network = _ipv6_network_from_prefix(prefix)
    except (ipaddress.AddressValueError, ipaddress.NetmaskValueError) as e:
        raise ValueError('IPv6 前缀不合法：{}'.format(e)) from e

    if network.prefixlen != 64:
        raise ValueError('IPv6 前缀必须是 /64，当前为 /{}'.format(
            network.prefixlen))

    if not network.is_private:
        raise ValueError(
            'IPv6 前缀必须是私有地址（建议用 fd00::/8 的 ULA 前缀）')

    # Validate IPv6 static hosts
    seen_macs = {}
    seen_ips = {}
    for host in settings.get('ipv6_static_hosts', []):
        mac = host['mac']
        try:
            address = ipaddress.IPv6Address(host['ip'])
        except ipaddress.AddressValueError as exception:
            raise ValueError(
                'IPv6 静态绑定的地址不合法：{}'.format(host['ip'])) from exception

        if mac in seen_macs:
            raise ValueError(
                'MAC {} 出现了两次（{} 和 {}）'.format(mac, seen_macs[mac],
                                                      host['ip']))
        seen_macs[mac] = host['ip']

        if host['ip'] in seen_ips:
            raise ValueError(
                'IPv6 地址 {} 被分配给了两个 MAC（{} 和 {}）'.format(
                    host['ip'], seen_ips[host['ip']], mac))
        seen_ips[host['ip']] = mac

        if address not in network:
            raise ValueError(
                'IPv6 静态绑定的地址 {} 不在 {} 网段内'.format(address, network))

        if address == ipaddress.IPv6Address(_ipv6_gateway_from_prefix(str(network))):
            raise ValueError('IPv6 静态绑定的地址 {} 与网关冲突'.format(address))

    for server in settings.get('ipv6_dns', []):
        if not server:
            continue
        try:
            ipaddress.IPv6Address(server)
        except ipaddress.AddressValueError as exception:
            raise ValueError('IPv6 DNS 服务器 {} 不合法'.format(
                server)) from exception


@privileged
def set_settings(enabled: bool, interface: str, range_start: str,
                 range_end: str, netmask: str, lease_time: str, gateway: str,
                 dns: str, domain: str, static_hosts: str = '',
                 ipv6_enabled: bool = False, ipv6_prefix: str = '',
                 ipv6_range_start: str = '', ipv6_range_end: str = '',
                 ipv6_lease_time: str = '12h', ipv6_dns: str = '',
                 ipv6_static_hosts: str = '') -> dict:
    """Validate, persist and apply new settings."""
    settings = {
        'enabled': bool(enabled),
        'interface': interface.strip(),
        'range_start': range_start.strip(),
        'range_end': range_end.strip(),
        'netmask': netmask.strip(),
        'lease_time': lease_time.strip() or '12h',
        'gateway': gateway.strip(),
        'dns': [item.strip() for item in dns.split(',') if item.strip()],
        'domain': domain.strip(),
        'static_hosts': parse_static_hosts(static_hosts or ''),
        'ipv6_enabled': bool(ipv6_enabled),
        'ipv6_prefix': ipv6_prefix.strip(),
        'ipv6_range_start': ipv6_range_start.strip(),
        'ipv6_range_end': ipv6_range_end.strip(),
        'ipv6_lease_time': ipv6_lease_time.strip() or '12h',
        'ipv6_dns': [item.strip() for item in ipv6_dns.split(',')
                     if item.strip()],
        'ipv6_static_hosts': parse_static_hosts(ipv6_static_hosts or ''),
    }

    _validate(settings)
    old_settings = read_settings()
    _write_settings(settings)
    _apply(settings, old_settings)
    return settings


def _service_active() -> bool:
    """Return whether our dnsmasq instance is running."""
    process = _run([
        'systemctl', 'is-active', '{}.service'.format(SERVICE_NAME)
    ])
    return process.stdout.strip() == 'active'


def _lease_owner(address: str) -> str:
    """Return the MAC currently holding *address* according to the leases."""
    try:
        lines = pathlib.Path(LEASE_PATH).read_text(
            encoding='utf-8').splitlines()
    except OSError:
        return ''

    for line in lines:
        parts = line.split()
        if len(parts) >= 3 and parts[2] == address:
            return parts[1]

    return ''


def _apply_bindings(settings: dict, previous: dict):
    """Rewrite the configuration and restart dnsmasq to pick it up.

    dnsmasq only reads the configuration file at start up, so a reload is not
    enough for a new 'dhcp-host' line.  Should the new configuration be
    rejected, the previous one is restored and the service restarted again, so
    that a bad binding cannot leave the LAN without DHCP.
    """
    _write_settings(settings)
    _write_config(settings)
    if not settings['enabled']:
        return

    _run(['systemctl', 'restart', SERVICE_NAME])
    if _service_active():
        return

    logging.error('dnsmasq rejected the new configuration, rolling back')
    _write_settings(previous)
    _write_config(previous)
    _run(['systemctl', 'restart', SERVICE_NAME])
    raise ValueError(
        '新的绑定没有通过 dnsmasq 校验，已回滚到修改前的配置，服务仍在运行')


@privileged
def add_static_host(mac: str, ip: str, name: str = '') -> dict:
    """Pin one device to a fixed address.

    Used by the button on the lease table, so that an administrator does not
    have to copy the MAC address out of the page by hand.  An existing binding
    for the same MAC is replaced, which doubles as "move this device to a
    different address".
    """
    settings = read_settings()
    previous = copy.deepcopy(settings)

    normalized = normalize_mac(mac)

    try:
        address = str(ipaddress.IPv4Address((ip or '').strip()))
    except ipaddress.AddressValueError as exception:
        raise ValueError('IP 地址不合法：{}'.format(ip)) from exception

    hosts = [host for host in settings['static_hosts']
             if host['mac'] != normalized]
    hosts.append({
        'mac': normalized,
        'ip': address,
        'name': (name or '').strip(),
    })
    settings['static_hosts'] = hosts

    _validate_static_hosts(settings, *_pool_context(settings))

    # A different device may still be holding the address right now.  The
    # binding takes effect on its next renewal, so say so instead of letting
    # the administrator believe the change is already in force.
    warning = ''
    owner = _lease_owner(address)
    if owner and owner != normalized:
        warning = ('{} 目前仍由 {} 使用，等那台设备下次续租后才会换给 {}。'
                   .format(address, owner, normalized))

    _apply_bindings(settings, previous)
    return {
        'settings': settings,
        'mac': normalized,
        'ip': address,
        'warning': warning,
    }


@privileged
def remove_static_host(mac: str) -> dict:
    """Drop the fixed address assigned to *mac*."""
    settings = read_settings()
    previous = copy.deepcopy(settings)

    normalized = normalize_mac(mac)
    remaining = [host for host in settings['static_hosts']
                 if host['mac'] != normalized]
    if len(remaining) == len(settings['static_hosts']):
        raise ValueError('没有找到 MAC {} 的静态绑定'.format(normalized))

    settings['static_hosts'] = remaining
    _apply_bindings(settings, previous)
    return settings


@privileged
def add_ipv6_static_host(mac: str, ip: str, name: str = '') -> dict:
    """Pin one device to a fixed IPv6 address."""
    settings = read_settings()
    previous = copy.deepcopy(settings)

    normalized = normalize_mac(mac)

    try:
        address = str(ipaddress.IPv6Address((ip or '').strip()))
    except ipaddress.AddressValueError as exception:
        raise ValueError('IPv6 地址不合法：{}'.format(ip)) from exception

    hosts = [host for host in settings.get('ipv6_static_hosts', [])
             if host['mac'] != normalized]
    hosts.append({
        'mac': normalized,
        'ip': address,
        'name': (name or '').strip(),
    })
    settings['ipv6_static_hosts'] = hosts

    _validate_ipv6(settings)

    warning = ''
    owner = _ipv6_lease_owner(address)
    if owner and owner != normalized:
        warning = ('{} 目前仍由 {} 使用，等那台设备下次续租后才会换给 {}。'
                   .format(address, owner, normalized))

    _apply_bindings(settings, previous)
    return {
        'settings': settings,
        'mac': normalized,
        'ip': address,
        'warning': warning,
    }


@privileged
def remove_ipv6_static_host(mac: str) -> dict:
    """Drop the fixed IPv6 address assigned to *mac*."""
    settings = read_settings()
    previous = copy.deepcopy(settings)

    normalized = normalize_mac(mac)
    remaining = [host for host in settings.get('ipv6_static_hosts', [])
                 if host['mac'] != normalized]
    if len(remaining) == len(settings.get('ipv6_static_hosts', [])):
        raise ValueError('没有找到 MAC {} 的 IPv6 静态绑定'.format(normalized))

    settings['ipv6_static_hosts'] = remaining
    _apply_bindings(settings, previous)
    return settings


def _ipv6_lease_owner(address: str) -> str:
    """Return the MAC/DUID currently holding *address* in IPv6 leases."""
    try:
        lines = pathlib.Path(LEASE_PATH).read_text(
            encoding='utf-8').splitlines()
    except OSError:
        return ''

    for line in lines:
        parts = line.split()
        if len(parts) >= 3 and parts[2] == address:
            return _duid_to_mac(parts[1]) or parts[1]

    return ''


@privileged
def uninstall():
    """Stop the service, hand the interface back and remove configuration."""
    action_utils.service_disable(SERVICE_NAME)
    _remove_unit()

    previous = _managed_interface()
    if previous:
        previous_network = _read_network()
        if previous_network:
            _remove_nft_rules(previous_network, previous)

        # Take the IPv6 address out of the NetworkManager profile before
        # the connection is handed back, otherwise it stays configured.
        state = _read_managed_ipv6()
        address = state.get('address')
        if address:
            interface = state.get('interface') or previous
            _nm_ipv6_remove(interface, address)
            if address in _kernel_ipv6(interface):
                _run(['ip', '-6', 'addr', 'del', address, 'dev', interface])
            _clear_managed_ipv6()

        try:
            _nm_set_method(previous, 'shared')
        except ValueError:
            logging.warning('No connection to restore to shared mode')

    try:
        pathlib.Path(RULES_SCRIPT_PATH).unlink()
    except OSError:
        pass

    shutil.rmtree(CONFIG_DIR, ignore_errors=True)
    shutil.rmtree(STATE_DIR, ignore_errors=True)
