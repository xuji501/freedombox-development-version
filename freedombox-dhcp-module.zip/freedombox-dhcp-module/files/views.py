# SPDX-License-Identifier: AGPL-3.0-or-later
"""FreedomBox app for a configurable DHCP server."""

import logging

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect
from django.urls import NoReverseMatch, reverse
from django.views.generic import View

from plinth.views import AppView

from . import privileged
from .forms import DHCPSettingsForm

logger = logging.getLogger(__name__)


def _module_url(name: str, fallback: str) -> str:
    """Resolve a URL of this module, tolerating a missing namespace.

    Plinth mounts every app under its own namespace, but a module that is
    loaded outside of it would raise here, so a plain path is used instead.
    """
    try:
        return reverse('dhcp:{}'.format(name))
    except NoReverseMatch:
        return fallback


def _index_url() -> str:
    """Return the URL of the app page."""
    return _module_url('index', '/plinth/apps/dhcp/')


class DHCPAppView(AppView):
    """Show the DHCP app page with its configuration form."""

    app_id = 'dhcp'
    template_name = 'dhcp.html'
    form_class = DHCPSettingsForm

    def get_initial(self):
        """Populate the form with the settings currently in effect."""
        initial = super().get_initial()
        try:
            settings = privileged.get_settings()
        except Exception:
            logger.exception('Unable to read DHCP settings')
            return initial

        initial.update({
            'enabled': settings['enabled'],
            'interface': settings['interface'],
            'range_start': settings['range_start'],
            'range_end': settings['range_end'],
            'netmask': settings['netmask'],
            'lease_time': settings['lease_time'],
            'gateway': settings['gateway'],
            'dns': ', '.join(settings['dns']),
            'domain': settings['domain'],
            'static_hosts':
                privileged.format_static_hosts(settings['static_hosts']),
            'ipv6_enabled': settings.get('ipv6_enabled', False),
            'ipv6_prefix': settings.get('ipv6_prefix', ''),
            'ipv6_range_start': settings.get('ipv6_range_start', ''),
            'ipv6_range_end': settings.get('ipv6_range_end', ''),
            'ipv6_lease_time': settings.get('ipv6_lease_time', '12h'),
            'ipv6_dns': ', '.join(settings.get('ipv6_dns', [])),
            'ipv6_static_hosts': privileged.format_static_hosts(
                settings.get('ipv6_static_hosts', [])),
        })
        return initial

    def get_context_data(self, **kwargs):
        """Expose the runtime status and current leases to the template."""
        context = super().get_context_data(**kwargs)
        try:
            context['dhcp_status'] = privileged.get_status()
        except Exception:
            logger.exception('Unable to read DHCP status')
            context['dhcp_status'] = None

        status = context.get('dhcp_status') or {}
        context['bound_macs'] = {
            host['mac']
            for host in status.get('static_hosts', [])
        }
        context['bound_ipv6_macs'] = {
            host['mac']
            for host in status.get('ipv6_static_hosts', [])
        }
        context['binding_url'] = _module_url('binding',
                                             '/plinth/apps/dhcp/binding/')
        return context

    def form_valid(self, form):
        """Persist the settings and apply them."""
        data = form.cleaned_data
        try:
            privileged.set_settings(
                bool(data.get('enabled')), data.get('interface') or '',
                data.get('range_start') or '', data.get('range_end') or '',
                data.get('netmask') or '255.255.255.0',
                data.get('lease_time') or '12h', data.get('gateway') or '',
                data.get('dns') or '', data.get('domain') or '',
                data.get('static_hosts') or '',
                bool(data.get('ipv6_enabled')),
                data.get('ipv6_prefix') or '',
                data.get('ipv6_range_start') or '',
                data.get('ipv6_range_end') or '',
                data.get('ipv6_lease_time') or '12h',
                data.get('ipv6_dns') or '',
                data.get('ipv6_static_hosts') or '')
        except Exception as exception:
            logger.exception('Unable to apply DHCP settings')
            messages.error(
                self.request,
                '保存失败：{}'.format(exception))
            return self.form_invalid(form)

        if data.get('enabled'):
            v6_msg = ''
            if data.get('ipv6_enabled'):
                v6_msg = ' IPv6 DHCPv6/RA 已同时启用。'
            messages.success(self.request,
                             'DHCP 服务已启用，配置已生效。{}'.format(v6_msg))
        else:
            messages.success(
                self.request,
                'DHCP 服务已停用，网卡已交还 NetworkManager。')

        return super().form_valid(form)


class BindingActionView(LoginRequiredMixin, View):
    """Pin a lease to a fixed address, or drop an existing binding.

    Kept as a separate endpoint instead of another field on the settings form
    so that the buttons in the lease table work without re-submitting the
    whole form, which would also apply whatever else was edited but not saved.
    """

    def post(self, request):
        """Handle a pin or unpin request from the tables on the page."""
        action = request.POST.get('action', '')
        mac = (request.POST.get('mac') or '').strip()
        ip = (request.POST.get('ip') or '').strip()
        name = (request.POST.get('name') or '').strip()
        family = (request.POST.get('family') or '').strip()

        try:
            if action == 'pin':
                if family == 'ipv6':
                    result = privileged.add_ipv6_static_host(mac, ip, name)
                    messages.success(
                        request,
                        '已把 {} 的 IPv6 地址固定到 {}。'
                        .format(result['mac'], result['ip']))
                else:
                    result = privileged.add_static_host(mac, ip, name)
                    messages.success(
                        request,
                        '已把 {} 固定到 {}，之后每次续租都会拿到这个地址。'
                        .format(result['mac'], result['ip']))
                if result.get('warning'):
                    messages.warning(request, result['warning'])
            elif action == 'unpin':
                if family == 'ipv6':
                    privileged.remove_ipv6_static_host(mac)
                    messages.success(
                        request, '已解除 {} 的 IPv6 静态绑定。'.format(mac))
                else:
                    privileged.remove_static_host(mac)
                    messages.success(
                        request, '已解除 {} 的静态绑定。'.format(mac))
            else:
                messages.error(request, '无法识别的操作。')
        except Exception as exception:
            logger.exception('Unable to change the static bindings')
            messages.error(request, '操作失败：{}'.format(exception))

        return redirect(_index_url())

    def get(self, request):
        """Only POST is meaningful, so send the browser back to the page."""
        return redirect(_index_url())
