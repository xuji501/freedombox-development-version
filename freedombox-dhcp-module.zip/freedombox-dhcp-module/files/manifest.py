# SPDX-License-Identifier: AGPL-3.0-or-later
"""
Application manifest for dhcp.
"""

from django.utils.translation import gettext_lazy as _

tags = [_('网络'), _('局域网'), _('DHCP')]
