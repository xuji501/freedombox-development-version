# SPDX-License-Identifier: AGPL-3.0-or-later
"""Django form for configuring the DHCP server."""

import ipaddress
import logging

from django import forms

from . import privileged

logger = logging.getLogger(__name__)

NETMASK_CHOICES = [
    ('255.255.255.128', '255.255.255.128  (/25, 126 台设备)'),
    ('255.255.255.192', '255.255.255.192  (/26, 62 台设备)'),
    ('255.255.255.0', '255.255.255.0  (/24, 254 台设备)'),
    ('255.255.254.0', '255.255.254.0  (/23, 510 台设备)'),
    ('255.255.0.0', '255.255.0.0  (/16, 65534 台设备)'),
]

LEASE_CHOICES = [
    ('1h', '1 小时'),
    ('6h', '6 小时'),
    ('12h', '12 小时'),
    ('24h', '24 小时'),
    ('7d', '7 天'),
    ('infinite', '永不过期'),
]

IPV6_PREFIX_HELP = (
    'ULA 前缀，必须是 /64，建议在 fd00::/8 范围内，例如 '
    'fd12:3456:7890::/64。dnsmasq 会基于此前缀发送路由通告并分配 DHCPv6 地址。'
)


class DHCPSettingsForm(forms.Form):
    """Address pool, gateway and DNS servers handed to clients."""

    enabled = forms.BooleanField(
        label='启用 DHCP 服务', required=False,
        help_text='启用后本机会接管所选网卡的地址分配，'
                  'NetworkManager 自带的 DHCP 会同时关闭。')

    interface = forms.ChoiceField(
        label='监听网卡', required=False,
        help_text='只在这个网卡上提供 DHCP 服务，其它网卡不受影响。')

    range_start = forms.GenericIPAddressField(
        label='地址池起始', required=False, protocol='IPv4',
        widget=forms.TextInput(attrs={'placeholder': '例如 192.168.1.10'}))

    range_end = forms.GenericIPAddressField(
        label='地址池结束', required=False, protocol='IPv4',
        widget=forms.TextInput(attrs={'placeholder': '例如 192.168.1.200'}))

    netmask = forms.ChoiceField(
        label='子网掩码', required=False, choices=NETMASK_CHOICES,
        help_text='必须与网卡自身的地址掩码一致。')

    lease_time = forms.ChoiceField(
        label='租约时长', required=False, choices=LEASE_CHOICES,
        help_text='客户端多久需要续租一次。')

    gateway = forms.GenericIPAddressField(
        label='默认网关', required=False, protocol='IPv4',
        help_text='通常就是本机在该网段的地址。不能落在地址池范围内。')

    dns = forms.CharField(
        label='DNS 服务器', required=False,
        help_text='多个地址用英文逗号分隔，例如 223.5.5.5,119.29.29.29。'
                  '最多填写 3 个。')

    domain = forms.CharField(
        label='域名后缀（可选）', required=False,
        help_text='例如 lan 或 home.arpa，会作为搜索域下发给客户端。')

    static_hosts = forms.CharField(
        label='静态地址绑定', required=False,
        widget=forms.Textarea(attrs={'rows': 8}),
        help_text='每行一条，格式为「MAC 地址 IP 地址 主机名」，主机名可省略。'
                  'MAC 与 IP 之间用空格或逗号分隔均可，'
                  '支持 aa:bb:cc:dd:ee:ff、aa-bb-cc-dd-ee-ff、'
                  'aabb.ccdd.eeff 三种写法。'
                  '以 # 开头的行会被忽略。'
                  '绑定的设备每次都会拿到同一个 IP，建议放在地址池之外；'
                  '即使写在地址池范围内，这个地址也不会再分配给其它设备。'
                  '也可以直接在下方租约表里点「固定此地址」自动添加。')

    # IPv6
    ipv6_enabled = forms.BooleanField(
        label='启用 IPv6 DHCPv6 / RA', required=False,
        help_text='开启后 dnsmasq 会同时发送 IPv6 路由通告（RA）并提供 '
                  '有状态 DHCPv6 地址分配。需要填写 ULA 前缀。')

    ipv6_prefix = forms.CharField(
        label='ULA 前缀', required=False,
        widget=forms.TextInput(attrs={'placeholder': '例如 fd12:3456:7890::/64'}),
        help_text=IPV6_PREFIX_HELP)

    ipv6_range_start = forms.CharField(
        label='IPv6 地址池起始', required=False,
        widget=forms.TextInput(attrs={'placeholder': '例如 ::100'}),
        help_text='可只写后缀（如 ::100），会自动拼接前缀。')

    ipv6_range_end = forms.CharField(
        label='IPv6 地址池结束', required=False,
        widget=forms.TextInput(attrs={'placeholder': '例如 ::1ff'}),
        help_text='可只写后缀（如 ::1ff），会自动拼接前缀。')

    ipv6_lease_time = forms.ChoiceField(
        label='IPv6 租约时长', required=False, choices=LEASE_CHOICES,
        help_text='客户端多久需要续租一次。')

    ipv6_dns = forms.CharField(
        label='IPv6 DNS 服务器（可选）', required=False,
        help_text='多个地址用英文逗号分隔，例如 240c::6666,240c::6644。'
                  '最多填写 3 个。留空则使用前缀::1。')

    ipv6_static_hosts = forms.CharField(
        label='IPv6 静态地址绑定', required=False,
        widget=forms.Textarea(attrs={'rows': 6}),
        help_text='每行一条，格式为「MAC 地址 IPv6 地址 主机名」，主机名可省略。'
                  'MAC 与 IP 之间用空格或逗号分隔均可。'
                  '以 # 开头的行会被忽略。'
                  '也可以直接在下方 IPv6 设备表里点「固定此地址」自动添加。')

    def __init__(self, *args, **kwargs):
        """Populate the interface list from the live system."""
        super().__init__(*args, **kwargs)
        self.fields['interface'].choices = self._interface_choices()

    @staticmethod
    def _interface_choices():
        """Return selectable interfaces as (value, label) pairs."""
        try:
            interfaces = privileged.get_interfaces()
        except Exception:
            logger.exception('Unable to list network interfaces')
            interfaces = []

        choices = []
        for item in interfaces:
            name = item.get('name', '')
            address = item.get('address', '')
            label = f'{name}（{address}）' if address else name
            choices.append((name, label))

        return choices or [('', '未检测到可用网卡')]

    def clean_static_hosts(self):
        """Parse the IPv4 binding table and return it in normalised form."""
        text = self.cleaned_data.get('static_hosts') or ''
        try:
            hosts = privileged.parse_static_hosts(text)
        except ValueError as exception:
            raise forms.ValidationError(str(exception)) from exception

        self._parsed_hosts = hosts
        return privileged.format_static_hosts(hosts)

    def clean_ipv6_static_hosts(self):
        """Parse the IPv6 binding table and return it in normalised form."""
        text = self.cleaned_data.get('ipv6_static_hosts') or ''
        try:
            hosts = privileged.parse_static_hosts(text)
        except ValueError as exception:
            raise forms.ValidationError(str(exception)) from exception

        self._parsed_ipv6_hosts = hosts
        return privileged.format_static_hosts(hosts)

    def clean(self):
        """Cross-field validation for the address pool."""
        cleaned = super().clean()
        if not cleaned.get('enabled'):
            # Disabling does not require a usable configuration.  Whatever is
            # on the form is stored as is so the values are not lost.
            return cleaned

        missing = [
            field for field in ('interface', 'range_start', 'range_end',
                                'netmask', 'lease_time', 'gateway', 'dns')
            if not cleaned.get(field)
        ]
        if missing:
            raise forms.ValidationError(
                '启用 DHCP 前请先填写完整的配置：{}。'.format(
                    '、'.join(self.fields[field].label for field in missing)))

        try:
            start = ipaddress.IPv4Address(cleaned['range_start'])
            end = ipaddress.IPv4Address(cleaned['range_end'])
            gateway = ipaddress.IPv4Address(cleaned['gateway'])
            netmask = ipaddress.IPv4Address(cleaned['netmask'])
        except ipaddress.AddressValueError as exception:
            raise forms.ValidationError(
                '地址格式不正确：{}。'.format(exception)) from exception

        # 以地址池起始地址为锚点推导网段，否则 0.0.0.0/掩码 永远得到
        # 0.0.0.0/24，任何真实地址都会被判为越界。
        try:
            network = ipaddress.IPv4Network('{}/{}'.format(start, netmask),
                                            strict=False)
        except (ipaddress.AddressValueError,
                ipaddress.NetmaskValueError) as exception:
            raise forms.ValidationError(
                '子网掩码不正确：{}。'.format(exception)) from exception

        for label, address in (('地址池结束', end), ('网关', gateway)):
            if address not in network:
                raise forms.ValidationError(
                    '{} {} 不在 {} 网段内。'.format(label, address, network))

        if int(start) > int(end):
            raise forms.ValidationError('地址池起始地址不能大于结束地址。')

        if int(start) <= int(gateway) <= int(end):
            raise forms.ValidationError(
                '网关 {} 落在地址池范围内，可能被分配给客户端，'
                '请把网关放在地址池之外。'.format(gateway))

        servers = [item.strip() for item in cleaned['dns'].split(',')
                   if item.strip()]
        if len(servers) > 3:
            raise forms.ValidationError('DNS 服务器最多填写 3 个。')

        for server in servers:
            try:
                ipaddress.IPv4Address(server)
            except ipaddress.AddressValueError as exception:
                raise forms.ValidationError(
                    'DNS 服务器 {} 不是合法的 IPv4 地址。'.format(
                        server)) from exception

        hosts = getattr(self, '_parsed_hosts', [])
        seen_macs = {}
        seen_ips = {}
        for host in hosts:
            address = ipaddress.IPv4Address(host['ip'])

            if host['mac'] in seen_macs:
                raise forms.ValidationError(
                    'MAC {} 出现了两次（{} 和 {}）。'.format(
                        host['mac'], seen_macs[host['mac']], host['ip']))
            seen_macs[host['mac']] = host['ip']

            if host['ip'] in seen_ips:
                raise forms.ValidationError(
                    'IP {} 被分配给了两个 MAC（{} 和 {}）。'.format(
                        host['ip'], seen_ips[host['ip']], host['mac']))
            seen_ips[host['ip']] = host['mac']

            if address not in network:
                raise forms.ValidationError(
                    '静态绑定的 IP {} 不在 {} 网段内。'.format(
                        address, network))

            if address == gateway:
                raise forms.ValidationError(
                    '静态绑定的 IP {} 与网关冲突。'.format(address))

            if address in (network.network_address,
                           network.broadcast_address):
                raise forms.ValidationError(
                    '静态绑定的 IP {} 是网络地址或广播地址，不能使用。'.format(
                        address))

        # IPv6 validation
        if cleaned.get('ipv6_enabled'):
            prefix = (cleaned.get('ipv6_prefix') or '').strip()
            if not prefix:
                raise forms.ValidationError(
                    '启用 IPv6 DHCPv6 前请先填写 ULA 前缀。')

            try:
                v6_network = ipaddress.IPv6Network(
                    prefix if '/' in prefix else prefix + '/64',
                    strict=False)
            except (ipaddress.AddressValueError,
                    ipaddress.NetmaskValueError) as exception:
                raise forms.ValidationError(
                    'IPv6 前缀不合法：{}。'.format(exception)) from exception

            if v6_network.prefixlen != 64:
                raise forms.ValidationError(
                    'IPv6 前缀必须是 /64，当前为 /{}。'.format(
                        v6_network.prefixlen))

            if not v6_network.is_private:
                raise forms.ValidationError(
                    'IPv6 前缀必须是私有地址（建议用 fd00::/8 的 ULA 前缀）。')

            ipv6_hosts = getattr(self, '_parsed_ipv6_hosts', [])
            seen_v6_macs = {}
            seen_v6_ips = {}
            for host in ipv6_hosts:
                try:
                    v6_addr = ipaddress.IPv6Address(host['ip'])
                except ipaddress.AddressValueError as exception:
                    raise forms.ValidationError(
                        'IPv6 静态绑定的地址 {} 不合法：{}'.format(
                            host['ip'], exception)) from exception

                if host['mac'] in seen_v6_macs:
                    raise forms.ValidationError(
                        'MAC {} 在 IPv6 静态绑定中出现了两次。'.format(
                            host['mac']))
                seen_v6_macs[host['mac']] = host['ip']

                if host['ip'] in seen_v6_ips:
                    raise forms.ValidationError(
                        'IPv6 地址 {} 被分配给了两个 MAC。'.format(host['ip']))
                seen_v6_ips[host['ip']] = host['mac']

                if v6_addr not in v6_network:
                    raise forms.ValidationError(
                        'IPv6 静态绑定的地址 {} 不在 {} 网段内。'.format(
                            v6_addr, v6_network))

            ipv6_servers = [item.strip()
                            for item in (cleaned.get('ipv6_dns') or '').split(',')
                            if item.strip()]
            if len(ipv6_servers) > 3:
                raise forms.ValidationError('IPv6 DNS 服务器最多填写 3 个。')
            for server in ipv6_servers:
                try:
                    ipaddress.IPv6Address(server)
                except ipaddress.AddressValueError as exception:
                    raise forms.ValidationError(
                        'IPv6 DNS 服务器 {} 不合法。'.format(
                            server)) from exception

        return cleaned
