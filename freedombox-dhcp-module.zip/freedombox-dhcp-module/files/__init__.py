# SPDX-License-Identifier: AGPL-3.0-or-later
"""FreedomBox app to run a configurable DHCP server."""

from django.utils.translation import gettext_lazy as _

from plinth import app as app_module
from plinth import menu
from plinth.modules.firewall.components import Firewall
from plinth.package import Packages

from . import manifest, privileged

_description = [
    _('DHCP 服务器负责向本地网络中的设备分配 IP 地址，并告知它们应该使用'
      '哪个网关和哪些 DNS 服务器。'),
    _('FreedomBox 默认由 NetworkManager 以 shared（共享）模式提供 DHCP，'
      '地址池由系统自动计算，网关和 DNS 也只能指向本机。本应用改用独立的 '
      'DHCP 服务，地址池、网关、DNS 都可以自由配置。'),
    _('启用后，所选网卡将退出 NetworkManager 的 shared 模式。地址转换与'
      '转发功能保持不变，但网卡会在重新配置的瞬间短暂中断。'),
]


class DHCPApp(app_module.App):
    """FreedomBox app for a configurable DHCP server."""

    app_id = 'dhcp'

    _version = 1

    def __init__(self) -> None:
        """Create components for the app."""
        super().__init__()

        info = app_module.Info(app_id=self.app_id, version=self._version,
                               name=_('DHCP 服务器'), icon='fa-exchange',
                               description=_description, tags=manifest.tags)
        self.add(info)

        menu_item = menu.Menu('menu-dhcp', info.name, info.icon, info.tags,
                              'dhcp:index', parent_url_name='apps', order=60)
        self.add(menu_item)

        packages = Packages('packages-dhcp', ['dnsmasq-base'])
        self.add(packages)

        firewall = Firewall('firewall-dhcp', info.name, ports=['dhcp'],
                            is_external=False)
        self.add(firewall)

    def setup(self, old_version):
        """Install and configure the app."""
        super().setup(old_version)
        privileged.setup()
        if not old_version:
            self.enable()

    def uninstall(self):
        """De-configure and uninstall the app."""
        super().uninstall()
        privileged.uninstall()
