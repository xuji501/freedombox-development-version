"""Local logic tests for the DHCP module with plinth stubbed out."""

import sys
import types
import pathlib

# --- Stub out the plinth package so privileged.py can be imported -----------
plinth = types.ModuleType('plinth')
action_utils = types.ModuleType('plinth.action_utils')
for name in ('service_enable', 'service_disable', 'service_start',
             'service_stop', 'service_restart', 'service_daemon_reload'):
    setattr(action_utils, name, lambda *a, **k: None)
actions = types.ModuleType('plinth.actions')
actions.privileged = lambda func: func
plinth.action_utils = action_utils
plinth.actions = actions
sys.modules['plinth'] = plinth
sys.modules['plinth.action_utils'] = action_utils
sys.modules['plinth.actions'] = actions

# pwd/grp are Unix-only; stub them so the module imports on Windows too.
for name in ('pwd', 'grp'):
    stub = types.ModuleType(name)
    stub.getpwnam = lambda _name: types.SimpleNamespace(pw_uid=65534)
    stub.getgrnam = lambda _name: types.SimpleNamespace(gr_gid=65534)
    sys.modules[name] = stub

sys.path.insert(0, str(pathlib.Path(__file__).parent / 'files'))
import privileged  # noqa: E402

print('=' * 60)
print('测试 1：render_config 生成 dnsmasq 配置')
print('=' * 60)
settings = {
    'enabled': True,
    'interface': 'ens34',
    'range_start': '172.16.19.10',
    'range_end': '172.16.19.254',
    'netmask': '255.255.255.0',
    'lease_time': '12h',
    'gateway': '172.16.19.1',
    'dns': ['223.5.5.5', '119.29.29.29'],
    'domain': 'lan',
}
config = privileged.render_config(settings)
print(config)
assert 'port=53' in config, '必须继续提供 DNS，否则老客户端解析会失效'
assert 'listen-address=172.16.19.1' in config
assert 'no-resolv' in config
assert 'server=223.5.5.5' in config
assert 'server=119.29.29.29' in config
assert 'interface=ens34' in config
assert 'bind-interfaces' in config
assert 'dhcp-range=172.16.19.10,172.16.19.254,255.255.255.0,12h' in config
assert 'dhcp-option=1,255.255.255.0' in config
assert 'dhcp-option=3,172.16.19.1' in config
assert 'dhcp-option=6,223.5.5.5,119.29.29.29' in config
assert 'dhcp-option=15,lan' in config
assert 'dhcp-authoritative' in config
assert 'dhcp-leasefile=/var/lib/freedombox-dhcp/dnsmasq.leases' in config
print('[通过] 关键指令齐全')

print()
print('=' * 60)
print('测试 2：domain 为空时不应输出 option 15')
print('=' * 60)
settings['domain'] = ''
config2 = privileged.render_config(settings)
assert 'dhcp-option=15' not in config2
print('[通过] 空域名被正确省略')

print()
print('=' * 60)
print('测试 3：_validate 合法配置')
print('=' * 60)
privileged._validate(settings)
print('[通过] 172.16.19.10-254 / 网关 .1 / DNS 223.5.5.5 通过校验')

print()
print('=' * 60)
print('测试 4：_validate 拒绝非法配置')
print('=' * 60)
cases = [
    ('网关落在池内', dict(settings, gateway='172.16.19.100')),
    ('起始大于结束', dict(settings, range_start='172.16.19.200',
                         range_end='172.16.19.10')),
    ('越出子网', dict(settings, range_end='172.16.20.50')),
    ('DNS 非法', dict(settings, dns=['not-an-ip'])),
    ('DNS 为空', dict(settings, dns=[])),
    ('未选网卡', dict(settings, interface='')),
]
for label, case in cases:
    try:
        privileged._validate(case)
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label} 本应被拒绝但没有')

print()
print('=' * 60)
print('测试 5：禁用时跳过校验（允许保存半成品）')
print('=' * 60)
privileged._validate(dict(settings, enabled=False, gateway='', dns=[]))
print('[通过] enabled=False 时不做强校验')

print()
print('=' * 60)
print('测试 6：_detect_defaults 从 shared 连接推导默认值')
print('=' * 60)
privileged._nm_connections = lambda: {'ens34': 'lan-static'}
privileged._interface_address = lambda iface: '172.16.19.1/24'
privileged._run = lambda args: types.SimpleNamespace(
    stdout='ipv4.method:shared\n', returncode=0, stderr='')
privileged._system_dns_servers = lambda: ['223.5.5.5', '119.29.29.29']

defaults = privileged._detect_defaults()
print(defaults)
assert defaults['interface'] == 'ens34'
assert defaults['gateway'] == '172.16.19.1'
assert defaults['range_start'] == '172.16.19.10'
assert defaults['range_end'] == '172.16.19.254'
assert defaults['netmask'] == '255.255.255.0'
assert defaults['dns'] == ['223.5.5.5', '119.29.29.29']

# 推导出来的默认值本身必须能通过校验
privileged._validate(dict(settings, **defaults))
print('[通过] 探测出的默认值合法且与现网 NM 一致')

print()
print('=' * 60)
print('测试 7：租约解析')
print('=' * 60)
import os
import tempfile
handle, temp_path = tempfile.mkstemp()
os.close(handle)
lease_file = pathlib.Path(temp_path)
lease_file.write_text(
    '1793082246 92:19:a9:5a:98:aa 172.16.19.85 CLS-AL30 01:92:19:a9:5a:98:aa\n'
    '1793084853 00:0c:29:fc:d4:3e 172.16.19.26 * 01:00:0c:29:fc:d4:3e\n',
    encoding='utf-8')
privileged.LEASE_PATH = str(lease_file)
privileged._run = lambda args: types.SimpleNamespace(
    stdout='inactive\n', returncode=3, stderr='')
status = privileged.get_status()
for lease in status['leases']:
    print(' ', lease)
assert len(status['leases']) == 2
by_address = {lease['address']: lease for lease in status['leases']}
assert by_address['172.16.19.85']['hostname'] == 'CLS-AL30'
assert by_address['172.16.19.26']['hostname'] == ''
assert status['service_active'] is False
lease_file.unlink()
print('[通过] 租约解析正确，主机名 * 转为空')

print()
print('=' * 60)
print('测试 8：_network_of 与开机规则脚本')
print('=' * 60)
assert privileged._network_of(settings) == '172.16.19.0/24'
print('  网段推导:', privileged._network_of(settings))

assert 'masquerade' in privileged.RULES_SCRIPT
assert 'iifname' in privileged.RULES_SCRIPT
assert 'established,related' in privileged.RULES_SCRIPT
compile(privileged.RULES_SCRIPT, 'apply-rules.py', 'exec')
print('[通过] 网段推导正确，开机脚本语法有效')

print()
print('=' * 60)
print('测试 9：systemd 单元必须带 ExecStartPre 恢复规则')
print('=' * 60)
print(privileged.UNIT_CONTENT)
assert 'ExecStartPre=/usr/bin/python3 /usr/lib/freedombox-dhcp/apply-rules.py' \
    in privileged.UNIT_CONTENT
assert '--conf-file=/etc/freedombox-dhcp/dnsmasq.conf' in \
    privileged.UNIT_CONTENT
print('[通过] 单元文件会在启动前恢复 NAT 规则')

print()
print('=' * 60)
print('测试 10：MAC 地址规范化')
print('=' * 60)
mac_cases = [
    ('AA:BB:CC:DD:EE:FF', 'aa:bb:cc:dd:ee:ff'),
    ('aa-bb-cc-dd-ee-ff', 'aa:bb:cc:dd:ee:ff'),
    ('aabb.ccdd.eeff', 'aa:bb:cc:dd:ee:ff'),
    ('aabbccddeeff', 'aa:bb:cc:dd:ee:ff'),
    (' 00:0C:29:FC:D4:3E ', '00:0c:29:fc:d4:3e'),
]
for raw, expected in mac_cases:
    result = privileged.normalize_mac(raw)
    assert result == expected, f'{raw} -> {result}, 期望 {expected}'
    print(f'  {raw:24s} -> {result}')
for bad in ('aa:bb:cc:dd:ee', 'zz:bb:cc:dd:ee:ff', 'aabbccdd', 'not-a-mac'):
    try:
        privileged.normalize_mac(bad)
    except ValueError:
        print(f'  [拒绝] {bad}')
    else:
        raise AssertionError(f'{bad} 本应被拒绝')
print('[通过] 四种常见写法都能识别，非法值被拒绝')

print()
print('=' * 60)
print('测试 11：静态绑定文本解析')
print('=' * 60)
text = '''
# 打印机
00:0c:29:fc:d4:3e 172.16.19.20 printer
AA-BB-CC-DD-EE-01,172.16.19.21,nas

aabb.ccdd.ee02\t172.16.19.22\tcamera
'''
hosts = privileged.parse_static_hosts(text)
for host in hosts:
    print(' ', host)
assert len(hosts) == 3, f'期望 3 条，实际 {len(hosts)}'
assert hosts[0] == {'mac': '00:0c:29:fc:d4:3e', 'ip': '172.16.19.20',
                    'name': 'printer'}
assert hosts[1]['mac'] == 'aa:bb:cc:dd:ee:01'
assert hosts[2]['mac'] == 'aa:bb:cc:dd:ee:02'
assert hosts[2]['name'] == 'camera'

roundtrip = privileged.parse_static_hosts(
    privileged.format_static_hosts(hosts))
assert roundtrip == hosts, '格式化后重新解析应得到相同结果'
print('[通过] 空格/逗号/Tab 混用、注释行、四种 MAC 写法均正确')

print()
print('=' * 60)
print('测试 12：非法绑定行应报出具体行号')
print('=' * 60)
bad_inputs = [
    ('00:0c:29:fc:d4:3e', '缺 IP'),
    ('00:0c:29:fc:d4:3e 172.16.19.999', 'IP 非法'),
    ('zz:zz:zz:zz:zz:zz 172.16.19.20', 'MAC 非法'),
]
for raw, label in bad_inputs:
    try:
        privileged.parse_static_hosts(raw)
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label} 本应被拒绝')
print('[通过] 错误信息带行号，便于定位')

print()
print('=' * 60)
print('测试 13：dhcp-host 指令生成')
print('=' * 60)
with_hosts = dict(settings, static_hosts=hosts)
config3 = privileged.render_config(with_hosts)
for line in config3.splitlines():
    if 'dhcp-host' in line:
        print(' ', line)
assert 'dhcp-host=00:0c:29:fc:d4:3e,172.16.19.20,printer' in config3
assert 'dhcp-host=aa:bb:cc:dd:ee:01,172.16.19.21,nas' in config3
assert 'dhcp-host=aa:bb:cc:dd:ee:02,172.16.19.22,camera' in config3
# dhcp-host 必须出现在 dhcp-range 之后
assert config3.index('dhcp-range=') < config3.index('dhcp-host=')

no_hosts = privileged.render_config(dict(settings, static_hosts=[]))
assert 'dhcp-host' not in no_hosts
print('[通过] 有绑定则生成指令，无绑定则完全不出现')

print()
print('=' * 60)
print('测试 14：_validate 校验静态绑定')
print('=' * 60)
privileged._validate(with_hosts)
print('  [通过] 3 条合法绑定')

invalid_hosts = [
    ('MAC 重复', [
        {'mac': 'aa:bb:cc:dd:ee:ff', 'ip': '172.16.19.20', 'name': ''},
        {'mac': 'aa:bb:cc:dd:ee:ff', 'ip': '172.16.19.21', 'name': ''},
    ]),
    ('IP 重复', [
        {'mac': 'aa:bb:cc:dd:ee:01', 'ip': '172.16.19.20', 'name': ''},
        {'mac': 'aa:bb:cc:dd:ee:02', 'ip': '172.16.19.20', 'name': ''},
    ]),
    ('IP 越界', [
        {'mac': 'aa:bb:cc:dd:ee:01', 'ip': '10.0.0.5', 'name': ''},
    ]),
    ('IP 与网关冲突', [
        {'mac': 'aa:bb:cc:dd:ee:01', 'ip': '172.16.19.1', 'name': ''},
    ]),
    ('IP 是广播地址', [
        {'mac': 'aa:bb:cc:dd:ee:01', 'ip': '172.16.19.255', 'name': ''},
    ]),
]
for label, entries in invalid_hosts:
    try:
        privileged._validate(dict(settings, static_hosts=entries))
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label} 本应被拒绝')
print('[通过] 五类冲突全部拦截')

print()
print('=' * 60)
print('测试 15：静态 IP 允许落在地址池内')
print('=' * 60)
inside_pool = [{'mac': 'aa:bb:cc:dd:ee:09', 'ip': '172.16.19.100',
                'name': 'in-pool'}]
privileged._validate(dict(settings, static_hosts=inside_pool))
print('[通过] 池内固定分配被接受（dnsmasq 会自动从动态池中排除）')

print()
print('=' * 60)
print('测试 16：add_static_host 一键固定租约地址')
print('=' * 60)
import copy

base_settings = dict(settings, static_hosts=[])
saved = {}


def fake_read_settings():
    """Return a fresh copy of the base settings on every call."""
    return copy.deepcopy(base_settings)


def fake_write_settings(value):
    """Record the written settings and keep the fake state in sync."""
    saved['settings'] = copy.deepcopy(value)
    base_settings.update(copy.deepcopy(value))


def fake_write_config(value):
    """Record the rendered dnsmasq configuration."""
    saved['config'] = privileged.render_config(value)


privileged.read_settings = fake_read_settings
privileged._write_settings = fake_write_settings
privileged._write_config = fake_write_config
privileged._run = lambda args: types.SimpleNamespace(
    stdout='active\n', returncode=0, stderr='')
privileged._service_active = lambda: True
privileged._lease_owner = lambda address: '00:0c:29:fc:d4:3e'

result = privileged.add_static_host('AA-BB-CC-DD-EE-09', '172.16.19.100', '')
print('  返回:', result)
assert result['mac'] == 'aa:bb:cc:dd:ee:09', 'MAC 应被规范化为小写冒号形式'
assert result['ip'] == '172.16.19.100'
assert result['warning'], '地址仍被别的设备占用时应当给出提示'
assert 'dhcp-host=aa:bb:cc:dd:ee:09,172.16.19.100' in saved['config']
assert len(saved['settings']['static_hosts']) == 1
print('[通过] MAC 规范化、dhcp-host 生成、占用冲突提示均正确')

print()
print('=' * 60)
print('测试 17：同一 MAC 换地址应替换而不是重复')
print('=' * 60)
privileged.add_static_host('aa:bb:cc:dd:ee:09', '172.16.19.150', 'nas')
hosts_now = saved['settings']['static_hosts']
print('  绑定表:', hosts_now)
assert len(hosts_now) == 1, f'期望 1 条，实际 {len(hosts_now)}'
assert hosts_now[0]['ip'] == '172.16.19.150'
assert hosts_now[0]['name'] == 'nas'
print('[通过] 同一设备改地址时原地更新，不会留下两条记录')

print()
print('=' * 60)
print('测试 18：add_static_host 拒绝冲突与非法输入')
print('=' * 60)
privileged.add_static_host('aa:bb:cc:dd:ee:0a', '172.16.19.101')

pin_rejections = [
    ('IP 已被别的 MAC 绑定',
     lambda: privileged.add_static_host('aa:bb:cc:dd:ee:0b', '172.16.19.101')),
    ('IP 非法',
     lambda: privileged.add_static_host('aa:bb:cc:dd:ee:0d', 'not-an-ip')),
    ('IP 与网关冲突',
     lambda: privileged.add_static_host('aa:bb:cc:dd:ee:0e', '172.16.19.1')),
    ('IP 不在网段内',
     lambda: privileged.add_static_host('aa:bb:cc:dd:ee:0f', '10.0.0.5')),
    ('MAC 非法',
     lambda: privileged.add_static_host('zz:zz:zz:zz:zz:zz', '172.16.19.102')),
]
for label, call in pin_rejections:
    try:
        call()
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label} 本应被拒绝')
print('[通过] 五类非法绑定全部拦截，错误信息可直接展示给用户')

print()
print('=' * 60)
print('测试 19：remove_static_host 解除绑定')
print('=' * 60)
privileged.remove_static_host('AA:BB:CC:DD:EE:0A')
remaining = saved['settings']['static_hosts']
print('  绑定表:', remaining)
assert all(host['mac'] != 'aa:bb:cc:dd:ee:0a' for host in remaining)
assert 'dhcp-host=aa:bb:cc:dd:ee:0a' not in saved['config']
try:
    privileged.remove_static_host('aa:bb:cc:dd:ee:0a')
except ValueError as error:
    print('  [拒绝] 重复解除:', error)
else:
    raise AssertionError('解除不存在的绑定本应报错')
print('[通过] 解除后配置同步移除，重复解除有明确提示')

print()
print('=' * 60)
print('测试 20：新配置被 dnsmasq 拒绝时自动回滚')
print('=' * 60)
snapshot = copy.deepcopy(saved['settings'])
privileged._service_active = lambda: False
try:
    privileged.add_static_host('aa:bb:cc:dd:ee:0c', '172.16.19.60')
except ValueError as error:
    print('  [回滚]', error)
else:
    raise AssertionError('服务起不来时应当回滚并报错')

assert saved['settings']['static_hosts'] == snapshot['static_hosts'], \
    '回滚后绑定表必须与修改前一致'
assert 'dhcp-host=aa:bb:cc:dd:ee:0c' not in saved['config'], \
    '回滚后配置文件不能残留新绑定'
print('[通过] 服务无法启动时回滚到修改前的配置，不会把内网 DHCP 弄挂')

print()
print('全部测试通过')
