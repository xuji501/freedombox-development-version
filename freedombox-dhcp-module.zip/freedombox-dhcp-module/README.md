# FreedomBox DHCP 服务模块

在 FreedomBox（Plinth）中新增一个可配置的 DHCP 服务器应用，替代 NetworkManager
shared 模式自动计算、不可调整的地址分配。

## 为什么需要它

FreedomBox 默认让 NetworkManager 以 `ipv4.method=shared` 提供 DHCP。这个模式：

- 地址池由系统按子网自动计算，无法指定起止地址
- 网关固定指向本机，不能改
- 下发的 DNS 固定指向本机，不能改

本模块用独立的 dnsmasq 实例接管地址分配，三项都可以自由配置。

## 页面功能

访问 `https://<本机地址>/plinth/apps/dhcp/`，在「应用」菜单里显示为 **DHCP 服务器**。

| 配置项 | 说明 |
|---|---|
| 启用 DHCP 服务 | 开关。开启后接管所选网卡的地址分配 |
| 监听网卡 | 从系统实际网卡中选择，只在该网卡上提供服务 |
| 地址池起始 / 结束 | 可分配的 IP 范围 |
| 子网掩码 | 支持 /25 /26 /24 /23 /16 |
| 租约时长 | 1 小时 ~ 7 天，或永不过期 |
| 默认网关 | 下发给客户端的网关，不能落在地址池内 |
| DNS 服务器 | 最多 3 个，逗号分隔，可填任意 IPv4 地址 |
| 域名后缀 | 可选，作为搜索域下发 |
| 静态地址绑定 | MAC 与 IP 的固定对应关系，每行一条 |
| 启用 IPv6 DHCPv6 / RA | 开关。开启后同时发送路由通告并提供 DHCPv6 |
| ULA 前缀 | 必须是 /64 的私有前缀，例如 `fd12:3456:7890::/64` |
| IPv6 地址池起始 / 结束 | 可只写后缀（`::100`），自动拼接前缀 |
| IPv6 租约时长 | 与 IPv4 相同的选项 |
| IPv6 DNS 服务器 | 可选，最多 3 个；留空则使用 `前缀::1` |
| IPv6 静态地址绑定 | MAC 与 IPv6 的固定对应关系，每行一条 |

页面同时显示服务运行状态、67/udp 监听情况、已生效的静态绑定表，以及当前所有租约
（IP、MAC、主机名、到期时间），租约表可直接把某台设备固定到它当前的地址。
启用 IPv6 后还会多出两张表：**IPv6 静态绑定**和**IPv6 在线设备**
（合并内核邻居表里的 SLAAC 地址与 dnsmasq 的 DHCPv6 租约，标注来源与邻居状态）。

## 静态地址绑定

在「静态地址绑定」文本框中每行写一条：

```
00:0c:29:fc:d4:3e 172.16.19.20 printer
aa-bb-cc-dd-ee-01,172.16.19.21,nas
aabb.ccdd.ee02	172.16.19.22	camera
```

- 格式为 `MAC IP [主机名]`，主机名可省略
- MAC 与 IP 之间用空格、逗号、分号或 Tab 分隔都行，直接从客户端列表复制粘贴即可
- MAC 支持 `aa:bb:cc:dd:ee:ff`、`aa-bb-cc-dd-ee-ff`、`aabb.ccdd.eeff`、
  `aabbccddeeff` 四种写法，保存时统一规范化为冒号小写形式
- 以 `#` 开头的行会被忽略，可以写注释
- 保存时逐行校验：MAC 格式、IP 格式、IP 是否在网段内、是否与网关冲突、
  是否是网络/广播地址、MAC 是否重复、IP 是否重复。出错会指出具体行号

绑定的设备每次请求都会拿到同一个 IP。静态 IP 可以放在地址池之外（推荐），
也可以放在池内 —— 放在池内时 dnsmasq 会自动把它从动态分配中排除。

### 从租约一键固定

不必手工抄 MAC。页面下方「当前租约」表每行都有一个 **固定此地址** 按钮：

- 点一下就把该设备当前的 IP 写进静态绑定，之后每次续租都拿到同一个地址
- 已经固定的设备显示为「已固定」，不会重复添加
- 「已生效的静态绑定」表里每行有 **解除绑定** 按钮，点一下即恢复动态分配
- 若该 IP 此刻仍被另一台设备占用，会提示「等那台设备下次续租后才会换给 …」

这两个按钮走独立的 `apps/dhcp/binding/` 接口，不会顺带提交表单里尚未保存的改动。

## IPv6：DHCPv6 与路由通告

开启后 dnsmasq 同时承担 IPv6 路由通告（RA）与 DHCPv6：

```
enable-ra
dhcp-range=fd12:3456:7890::100,fd12:3456:7890::1ff,slaac,12h
dhcp-option=option6:dns-server,[fd12:3456:7890::1]
```

`slaac` 表示客户端用 RA 里的前缀自己构造地址，DHCPv6 只补充 DNS 等选项；
填了静态绑定时会额外生成 `dhcp-host=id:<MAC>,[<IPv6>]`。

### 网关地址由 NetworkManager 持有

RA 必须有一个本机地址作为源地址，所以开启时模块会把 `前缀::1/64` 加到网卡上。
**这个地址不能只用 `ip addr add` 添加** —— NetworkManager 每次激活连接都会按
profile 重写接口地址，并清除所有不在 profile 中的地址，手动加的地址在下一次
`nmcli connection up` 后就消失了，客户端随之拿不到可用的默认网关。

因此地址写进 NetworkManager 连接本身：

```bash
nmcli connection modify <连接> ipv6.method manual \
    ipv6.addresses <原有地址>,<前缀::1/64>
nmcli device reapply <网卡>        # 不中断链路
```

关闭时按 `/var/lib/freedombox-dhcp/managed-ipv6` 里记录的快照**精确还原**原来的
地址列表与 `ipv6.method`，不留痕迹。重复保存不会把自己的地址误记成"原始状态"。
开机时 `apply-rules.py`（服务单元的 `ExecStartPre`）做同样的事，所以重启后地址
依然存在。

## 修改绑定的安全性

单条增删走的是「写配置 → 重启 dnsmasq → 检查是否真的起来了」的流程。
如果新配置被 dnsmasq 拒绝导致服务起不来，会自动回滚到修改前的配置并再次重启，
最后向页面返回一条错误提示 —— 不会因为一次误操作让整个内网拿不到地址。

## 工作原理

启用时模块会做这些事：

1. 生成 `/etc/freedombox-dhcp/dnsmasq.conf`
2. 把对应 NetworkManager 连接从 `shared` 改为 `manual`，保留静态地址
3. **接管 NAT 与转发规则**：NetworkManager 在 shared 模式下会动态添加三条 nftables
   规则，切走后会被它移除。模块在切换后重新安装这些规则：
   - `ip saddr <网段> ip daddr != <网段> masquerade`
   - `ip saddr <网段> iifname "<网卡>" accept`
   - `ip daddr <网段> oifname "<网卡>" ct state established,related accept`
4. 迁移 NetworkManager 已有的租约文件，客户端保留原有 IP
5. 若开启了 IPv6，把 `前缀::1/64` 写进 NetworkManager 连接并 `reapply`
   （见下文「网关地址由 NetworkManager 持有」）
6. 启动 `freedombox-dhcp.service`

dnsmasq 同时做两件事：

- **67/udp**：地址分配，下发配置的网关与 DNS
- **53/udp**：在网关地址上继续提供 DNS 转发，保证老客户端仍指向本机时解析正常

静态绑定会生成 `dhcp-host=<MAC>,<IP>,<主机名>` 指令。由于本机也提供 DNS，
绑定的主机名可以直接解析到对应 IP。

关闭时按相反顺序还原，网卡交还 NetworkManager 的 shared 模式。

## 文件位置

```
/usr/lib/python3/dist-packages/plinth/modules/dhcp/   模块代码
/etc/freedombox/modules-enabled/dhcp                  启用标记
/etc/freedombox-dhcp/settings.json                    当前配置
/etc/freedombox-dhcp/dnsmasq.conf                     生成的 dnsmasq 配置
/etc/systemd/system/freedombox-dhcp.service           服务单元
/usr/lib/freedombox-dhcp/apply-rules.py               开机恢复 NAT 规则
/var/lib/freedombox-dhcp/dnsmasq.leases               租约文件
/var/lib/freedombox-dhcp/managed-ipv6                 IPv6 地址快照（用于关闭时还原）
```

## 常用命令

```bash
systemctl status freedombox-dhcp        # 服务状态
journalctl -u freedombox-dhcp -f        # 实时日志（含每次地址分配）
cat /var/lib/freedombox-dhcp/dnsmasq.leases   # 当前租约
```

## 安装与回滚

```bash
sudo bash install.sh                    # 安装或重装（幂等）
sudo bash rollback.sh                   # 卸载并交还网卡
sudo bash rollback.sh <备份目录>         # 卸载并还原到指定备份
```

安装脚本会先备份到 `/root/freedombox-dhcp-module-backup/<时间戳>/`，
任何一步失败自动回滚。

## 升级注意

模块文件位于 `plinth` 包目录内，但**不在 freedombox deb 包的文件清单里**，
所以 `apt upgrade freedombox` 不会覆盖它。如果升级后页面异常，重跑一次
`install.sh` 即可。

## 常见问题

### 应用出现在「已禁用」列表里

Plinth 只在 `plinth` 服务启动时计算一次每个应用的启用状态，并把它保存在进程内存中。
如果模块文件是在服务运行期间替换的（手工覆盖、只重传 `privileged.py` 等），
或者应用是在进程启动之后才完成首次 setup 的，列表里就会保留旧状态。

```bash
sudo systemctl restart plinth
```

重启后应用会回到「已启用」列表，页面本身一直是可用的，DHCP 服务也不受影响。

### IPv6 在线设备表是空的

设备表由两部分合并而来：内核邻居表（SLAAC/RA 地址）和 dnsmasq 的 DHCPv6 租约。
两者都只统计**落在当前配置前缀内**的地址，所以：

- 客户端需要先收到 RA 并自行构造地址，通常几十秒内出现
- 邻居表项长时间无流量会变成 `STALE` 甚至被回收，属正常现象
- 如果客户端还持有 NetworkManager 共享模式时代的旧 ULA 地址，那不会显示在这里

## 已知边界

- 一个实例只服务一个网卡
- 静态绑定只按 MAC 识别，不支持按 client-id 或主机名匹配
- 静态绑定的设备如果更换网卡，需要同步修改绑定表
- 若目标网段原本没有 NAT 规则，启用后会补上；原本有的网段规则不受影响
- IPv6 只支持单个 /64 ULA 前缀，不做前缀委派（PD），也不下发公网 IPv6
- IPv6 邻居表只展示落在配置前缀内的设备，其它前缀的邻居不算本服务的客户端
- NAT 只对 IPv4 生效；IPv6 流量依赖客户端与上游路由器的原生转发
