#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 为 FreedomBox 安装可配置的 DHCP 服务模块。
#
# 用法：sudo bash install.sh
#
# 安装内容：
#   /usr/lib/python3/dist-packages/plinth/modules/dhcp/   模块代码
#   /etc/freedombox/modules-enabled/dhcp                  启用标记
#
# 任何一步失败都会自动回滚到安装前的状态。

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/dhcp
ENABLED_DIR=/etc/freedombox/modules-enabled
BACKUP_ROOT=/root/freedombox-dhcp-module-backup
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
SOURCE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

rollback() {
    echo "正在回滚..." >&2
    rm -f "$ENABLED_DIR/dhcp"

    if [ -d "$BACKUP_DIR/module" ]; then
        rm -rf "$MODULE_DIR"
        cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
        echo "已恢复原有模块目录" >&2
    else
        rm -rf "$MODULE_DIR"
        echo "已移除新模块目录" >&2
    fi

    if [ -f "$BACKUP_DIR/enabled-dhcp" ]; then
        cp -a "$BACKUP_DIR/enabled-dhcp" "$ENABLED_DIR/dhcp"
    fi

    systemctl restart plinth 2>/dev/null || true
    echo "回滚完成" >&2
}

echo "=============================================="
echo " FreedomBox DHCP 服务模块安装"
echo "=============================================="

echo ""
echo "== 1/8 环境检查 =="
[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"
[ -f "$SOURCE_DIR/files/__init__.py" ] || fail "在 $SOURCE_DIR/files 下找不到模块源文件"
dpkg -s freedombox >/dev/null 2>&1 || fail "未检测到 freedombox 软件包"
echo "freedombox 版本：$(dpkg-query -W -f='${Version}' freedombox)"
[ -x /usr/sbin/dnsmasq ] || fail "未找到 /usr/sbin/dnsmasq，请先安装 dnsmasq-base"
echo "dnsmasq：$(dnsmasq --version 2>/dev/null | head -1)"
command -v nmcli >/dev/null || fail "未找到 nmcli，本模块依赖 NetworkManager"

echo ""
echo "== 2/8 备份现有状态 =="
mkdir -p "$BACKUP_DIR"
if [ -d "$MODULE_DIR" ]; then
    cp -a "$MODULE_DIR" "$BACKUP_DIR/module"
    echo "已备份现有模块目录"
fi
if [ -f "$ENABLED_DIR/dhcp" ]; then
    cp -a "$ENABLED_DIR/dhcp" "$BACKUP_DIR/enabled-dhcp"
    echo "已备份现有启用标记"
fi
nmcli -t -f NAME,DEVICE,UUID,ACTIVE connection show \
    > "$BACKUP_DIR/nm-connections.txt" 2>/dev/null || true
ip -o -4 addr show > "$BACKUP_DIR/ip-addr.txt" 2>/dev/null || true
cp -a /etc/NetworkManager/system-connections \
    "$BACKUP_DIR/nm-system-connections" 2>/dev/null || true
echo "备份目录：$BACKUP_DIR"

echo ""
echo "== 3/8 部署模块文件 =="
mkdir -p "$MODULE_DIR/templates"
install -m 644 "$SOURCE_DIR/files/__init__.py"          "$MODULE_DIR/__init__.py"     || fail "复制 __init__.py 失败"
install -m 644 "$SOURCE_DIR/files/manifest.py"          "$MODULE_DIR/manifest.py"     || fail "复制 manifest.py 失败"
install -m 644 "$SOURCE_DIR/files/forms.py"             "$MODULE_DIR/forms.py"        || fail "复制 forms.py 失败"
install -m 644 "$SOURCE_DIR/files/views.py"             "$MODULE_DIR/views.py"        || fail "复制 views.py 失败"
install -m 644 "$SOURCE_DIR/files/urls.py"              "$MODULE_DIR/urls.py"         || fail "复制 urls.py 失败"
install -m 644 "$SOURCE_DIR/files/privileged.py"        "$MODULE_DIR/privileged.py"   || fail "复制 privileged.py 失败"
install -m 644 "$SOURCE_DIR/files/templates/dhcp.html"  "$MODULE_DIR/templates/dhcp.html" || fail "复制模板失败"
chown -R root:root "$MODULE_DIR"
chmod 755 "$MODULE_DIR"
echo "已部署到 $MODULE_DIR"

echo ""
echo "== 4/8 语法检查 =="
for file in "$MODULE_DIR"/*.py; do
    if ! python3 -m py_compile "$file"; then
        fail "语法错误：$file"
    fi
done
echo "全部 Python 文件语法正确"

echo ""
echo "== 5/8 启用模块 =="
mkdir -p "$ENABLED_DIR"
echo "plinth.modules.dhcp" > "$ENABLED_DIR/dhcp"
chmod 644 "$ENABLED_DIR/dhcp"
echo "已写入 $ENABLED_DIR/dhcp"

echo ""
echo "== 6/8 导入与表单检查 =="
CHECK_SCRIPT=$(mktemp /tmp/dhcp-check-XXXXXX.py)
cat > "$CHECK_SCRIPT" <<'PYEOF'
# web_framework.init() configures Django itself, so django.setup() must not
# be called beforehand.
from plinth import web_framework

web_framework.init()

from plinth.modules.dhcp import forms, privileged, views  # noqa: E402

assert views.DHCPAppView.app_id == 'dhcp'
assert views.DHCPAppView.form_class is forms.DHCPSettingsForm

form = forms.DHCPSettingsForm()
for field in ('enabled', 'interface', 'range_start', 'range_end', 'netmask',
              'lease_time', 'gateway', 'dns', 'domain'):
    assert field in form.fields, f'缺少表单字段 {field}'

from django.template.loader import get_template  # noqa: E402
template = get_template('dhcp.html')
print('模板来源：', template.origin.name)
print('模块导入、表单字段与模板加载全部正常')
PYEOF

if ! python3 "$CHECK_SCRIPT"; then
    rm -f "$CHECK_SCRIPT"
    rollback
    fail "导入检查未通过，已回滚"
fi
rm -f "$CHECK_SCRIPT"

echo ""
echo "== 7/8 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if ! systemctl is-active --quiet plinth; then
    rollback
    fail "Plinth 未能启动，已回滚"
fi
echo "Plinth 运行正常"

echo ""
echo "== 8/8 首次初始化 =="
# Plinth only re-runs setup for apps that already have a version recorded, or
# for essential apps.  A brand new non-essential app has to be set up once
# explicitly, otherwise it never gets a configuration file.
if [ -f /etc/freedombox-dhcp/settings.json ]; then
    echo "设置文件已存在，跳过首次初始化"
else
    echo "执行首次 setup（会自动探测当前网络参数）..."
    systemctl stop plinth
    (cd /usr/lib/python3/dist-packages && \
        timeout 120 python3 "$SOURCE_DIR/setup_once.py")
    SETUP_RC=$?
    systemctl start plinth
    sleep 4

    if [ "$SETUP_RC" -ne 0 ] || \
       [ ! -f /etc/freedombox-dhcp/settings.json ]; then
        rollback
        fail "首次初始化失败（退出码 $SETUP_RC），已回滚"
    fi

    if ! systemctl is-active --quiet plinth; then
        rollback
        fail "初始化后 Plinth 未能启动，已回滚"
    fi
    echo "初始化完成"
fi

sleep 3
CODE=$(curl -sk -o /dev/null -w '%{http_code}' https://127.0.0.1/plinth/apps/dhcp/ 2>/dev/null || echo 000)
echo "DHCP 页面返回 HTTP $CODE（302 表示需要登录，属正常）"

echo ""
echo "== 安装结果 =="
if [ -f /etc/freedombox-dhcp/settings.json ]; then
    echo "设置文件已生成："
    cat /etc/freedombox-dhcp/settings.json
else
    echo "提示：设置文件尚未生成，打开页面后会自动探测当前网络参数。"
fi

echo ""
echo "DHCP 服务状态：$(systemctl is-active freedombox-dhcp 2>/dev/null || echo 未启用)"
echo ""
echo "访问 https://<本机地址>/plinth/apps/dhcp/ 进行配置。"
echo "回滚命令：sudo bash $SOURCE_DIR/rollback.sh $BACKUP_DIR"
echo "=============================================="
