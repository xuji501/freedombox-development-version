#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 卸载 FreedomBox DHCP 服务模块，并把网卡交还 NetworkManager。
#
# 用法：
#   sudo bash rollback.sh                       # 卸载，网卡恢复 shared 模式
#   sudo bash rollback.sh /root/xxx-backup/时间戳 # 卸载并还原到指定备份

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/dhcp
ENABLED_DIR=/etc/freedombox/modules-enabled
CONFIG_DIR=/etc/freedombox-dhcp
STATE_DIR=/var/lib/freedombox-dhcp
UNIT_PATH=/etc/systemd/system/freedombox-dhcp.service
MANAGED_PATH="$STATE_DIR/managed-interface"

BACKUP_DIR="${1:-}"

fail() {
    echo "" >&2
    echo "[错误] $*" >&2
    exit 1
}

echo "=============================================="
echo " FreedomBox DHCP 服务模块卸载"
echo "=============================================="

[ "$(id -u)" -eq 0 ] || fail "必须以 root 权限运行"

echo ""
echo "== 1/6 停止 DHCP 服务 =="
systemctl disable --now freedombox-dhcp 2>/dev/null && echo "服务已停止" || echo "服务本来就没在运行"

echo ""
echo "== 2/6 清理 nftables 规则 =="
NETWORK_FILE="$STATE_DIR/nft-network"
if [ -f "$NETWORK_FILE" ]; then
    NETWORK=$(cat "$NETWORK_FILE")
    echo "移除 $NETWORK 的 NAT 与转发规则"

    for handle in $(nft -a list table inet nat 2>/dev/null \
        | grep "$NETWORK" | sed 's/.*handle //'); do
        nft delete rule inet nat postrouting handle "$handle" 2>/dev/null || true
    done

    for handle in $(nft -a list table inet filter 2>/dev/null \
        | grep "$NETWORK" | sed 's/.*handle //'); do
        nft delete rule inet filter forward handle "$handle" 2>/dev/null || true
    done
else
    echo "没有规则记录，跳过"
fi

echo ""
echo "== 3/6 交还网卡给 NetworkManager =="
if [ -f "$MANAGED_PATH" ]; then
    INTERFACE=$(cat "$MANAGED_PATH")
    echo "被接管的网卡：$INTERFACE"

    CONNECTION=$(nmcli --terse --fields NAME,DEVICE connection show --active 2>/dev/null \
        | awk -F: -v dev="$INTERFACE" '$NF == dev { print substr($0, 1, length($0) - length(dev) - 1) }')

    if [ -n "$CONNECTION" ]; then
        echo "连接名：$CONNECTION"
        nmcli connection modify "$CONNECTION" ipv4.method shared && echo "已切回 shared 模式"
        nmcli connection up "$CONNECTION" && echo "连接已重新激活"
    else
        echo "警告：未找到 $INTERFACE 对应的活动连接，请手动检查 nmcli 状态" >&2
    fi
else
    echo "没有接管记录，网卡保持原样"
fi

echo ""
echo "== 4/6 移除启用标记 =="
rm -f "$ENABLED_DIR/dhcp"
echo "已移除 $ENABLED_DIR/dhcp"

echo ""
echo "== 5/6 清理模块与配置文件 =="
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/module" ]; then
    rm -rf "$MODULE_DIR"
    cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
    echo "已从备份还原模块目录"
else
    rm -rf "$MODULE_DIR"
    echo "已删除模块目录"
fi

rm -f "$UNIT_PATH"
systemctl daemon-reload
rm -rf "$CONFIG_DIR" "$STATE_DIR"
echo "已清理配置与状态目录"

echo ""
echo "== 6/6 重启 Plinth =="
systemctl restart plinth
for _ in $(seq 1 25); do
    sleep 1
    if systemctl is-active --quiet plinth; then
        break
    fi
done

if systemctl is-active --quiet plinth; then
    echo "Plinth 运行正常"
else
    fail "Plinth 未能启动，请执行 journalctl -u plinth -n 50 查看原因"
fi

echo ""
echo "卸载完成。"
echo "当前 67 端口："
ss -uln 2>/dev/null | grep ':67 ' || echo "  无进程监听（NetworkManager 未运行 DHCP）"
echo "=============================================="
