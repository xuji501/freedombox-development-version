# SPDX-License-Identifier: AGPL-3.0-or-later
"""Configure OpenVPN server.

Modified for FreedomBox 25.9.3 to support username/password authentication
and a configurable listen port. The upstream module hard-codes both the port
(1194) and a certificate-only setup; this version reads them from
/etc/openvpn/server/freedombox-settings.json instead.
"""

import datetime
import hashlib
import json
import os
import pathlib
import re
import secrets
import shutil
import subprocess
import time

import augeas

from plinth import action_utils
from plinth.actions import privileged, secret_str

KEYS_DIRECTORY = pathlib.Path('/etc/openvpn/freedombox-keys')
CA_CERTIFICATE_PATH = KEYS_DIRECTORY / 'pki' / 'ca.crt'
USER_CERTIFICATE_PATH = KEYS_DIRECTORY / 'pki' / 'issued' / '{username}.crt'
USER_KEY_PATH = KEYS_DIRECTORY / 'pki' / 'private' / '{username}.key'
ATTR_FILE = KEYS_DIRECTORY / 'pki' / 'index.txt.attr'

SERVER_CONFIGURATION_PATH = '/etc/openvpn/server/freedombox.conf'
SETTINGS_PATH = '/etc/openvpn/server/freedombox-settings.json'

SERVICE_NAME = 'openvpn-server@freedombox'

AUTH_MODES = ('cert', 'cert+pw')

# FreedomBox keeps its own account file.  RouteWeb (the other VPN instance on
# this box, port 1194) owns /etc/openvpn/auth/users.json and rewrites it
# whenever it saves, so sharing that file would silently drop accounts added
# here.  The legacy file is only read once, to seed this one.
AUTH_DIRECTORY = pathlib.Path('/etc/openvpn/freedombox-auth')
AUTH_STORE_PATH = AUTH_DIRECTORY / 'users.json'
LEGACY_AUTH_STORE = '/etc/openvpn/auth/users.json'

AUTH_SCRIPT_PATH = '/usr/lib/freedombox-openvpn/ovpn-auth.py'
LEGACY_AUTH_SCRIPT = '/opt/routeweb/ovpn_auth.py'

PBKDF2_ROUNDS = 200000
SALT_BYTES = 16
MIN_PASSWORD_LENGTH = 8
MAX_PASSWORD_LENGTH = 128

USERNAME_PATTERN = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,31}$')
RESERVED_USERNAMES = ('ca', 'server')

DEFAULT_SETTINGS = {
    'port': 1194,
    'auth_mode': 'cert',
    'auth_script': AUTH_SCRIPT_PATH,
}

SERVER_CONFIGURATION = '''
port {port}
proto udp
proto udp6
dev tun

client-to-client

ca /etc/openvpn/freedombox-keys/pki/ca.crt
cert /etc/openvpn/freedombox-keys/pki/issued/server.crt
key /etc/openvpn/freedombox-keys/pki/private/server.key

dh none

server 10.91.0.0 255.255.255.0
keepalive 10 120
verb 3

tls-server
tls-version-min 1.2
cipher AES-256-CBC
script-security 2
{auth_extra}'''

CLIENT_CONFIGURATION = '''
client
remote {remote} {port}
proto udp
proto udp6
dev tun
nobind
remote-cert-tls server
cipher AES-256-CBC
redirect-gateway
verb 3
{auth_client}<ca>
{ca}</ca>
<cert>
{cert}</cert>
<key>
{key}</key>'''

# Standalone credential checker, installed as AUTH_SCRIPT_PATH and invoked by
# OpenVPN itself.  It deliberately does not import anything from Plinth: it has
# to keep working while the service is restarting or after an upgrade.
AUTH_SCRIPT = '''#!/usr/bin/python3
"""Verify an OpenVPN username and password for FreedomBox.

OpenVPN calls this as::

    ovpn-auth.py <credentials-file>

The file holds the username on the first line and the password on the second
(with 'via-file').  Exit status 0 accepts the connection, anything else
rejects it.  Every attempt is appended to a log so that a user who cannot
connect can be told why.
"""

import hashlib
import hmac
import json
import os
import sys
import time

STORE_PATH = '/etc/openvpn/freedombox-auth/users.json'
LOG_PATH = '/var/log/freedombox-ovpn-auth.log'
LOG_LIMIT = 512 * 1024
ROUNDS = 200000


def log(message):
    """Append one line to the audit log, ignoring any failure."""
    try:
        if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > LOG_LIMIT:
            os.replace(LOG_PATH, LOG_PATH + '.1')
        with open(LOG_PATH, 'a', encoding='utf-8') as handle:
            handle.write('%s %s\\n'
                         % (time.strftime('%Y-%m-%d %H:%M:%S'), message))
    except OSError:
        pass


def read_credentials(path):
    """Return the username and password OpenVPN prepared for us."""
    with open(path, encoding='utf-8', errors='replace') as handle:
        lines = handle.read().split('\\n')
    if len(lines) < 2:
        return '', ''
    return lines[0].strip(), lines[1].rstrip('\\r')


def main(argv):
    """Check the credentials and return the exit status for OpenVPN."""
    if len(argv) < 2:
        log('FAIL - no credentials file')
        return 1

    try:
        username, password = read_credentials(argv[1])
    except OSError:
        log('FAIL - credentials unreadable')
        return 1

    if not username:
        log('FAIL - empty username')
        return 1

    safe_name = username.replace('\\n', '_').replace(' ', '_')[:64]

    try:
        with open(STORE_PATH, encoding='utf-8') as handle:
            store = json.load(handle)
    except (OSError, ValueError):
        log('FAIL %s store-unreadable' % safe_name)
        return 1

    for entry in store.get('users') or []:
        if not isinstance(entry, dict) or entry.get('user') != username:
            continue
        if entry.get('disabled'):
            log('FAIL %s disabled' % safe_name)
            return 1
        salt = entry.get('salt') or ''
        expected = str(entry.get('hash') or '')
        try:
            actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                                         salt.encode('utf-8'), ROUNDS).hex()
        except (ValueError, TypeError):
            log('FAIL %s derive-error' % safe_name)
            return 1
        if hmac.compare_digest(actual, expected):
            log('OK   %s' % safe_name)
            return 0
        log('FAIL %s bad-password' % safe_name)
        return 1

    log('FAIL %s no-such-user' % safe_name)
    return 1


if __name__ == '__main__':
    sys.exit(main(sys.argv))
'''

_EASY_RSA_CONFIGURATION = {
    'EASYRSA_ALGO': 'ec',  # Use Elliptic Curve Cryptography by default
    'EASYRSA_BATCH': '1',  # Prevent prompting
    'EASYRSA_DIGEST': 'sha512',
    'EASYRSA_CA_EXPIRE': '3650',  # 10 years expiry for CA root certificate
    'EASYRSA_CERT_EXPIRE': '3650',  # 10 years expiry for server/client certs
    'EASYRSA_CERT_RENEW': '1095',  # Renew cert if expiry less than 3 years
    'EASYRSA_REQ_COUNTRY': 'US',
    'EASYRSA_REQ_PROVINCE': 'NY',
    'EASYRSA_REQ_CITY': 'New York',
    'EASYRSA_REQ_ORG': 'FreedomBox',
    'EASYRSA_REQ_EMAIL': 'me@freedombox',
    'EASYRSA_REQ_OU': 'Home',
}


@privileged
def setup():
    """Setup configuration, CA and certificates."""
    _migrate_users()
    _write_auth_script()
    _migrate_auth_script_setting()
    _write_server_config()
    _create_certificates()
    _setup_firewall()
    action_utils.service_try_restart(SERVICE_NAME)


def read_settings() -> dict:
    """Return current settings merged over defaults.

    Safe to call from unprivileged code: the file is world-readable and any
    malformed value falls back to the default instead of raising.
    """
    settings = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_PATH, encoding='utf-8') as file_handle:
            data = json.load(file_handle)
    except (OSError, ValueError):
        return settings

    if not isinstance(data, dict):
        return settings

    port = data.get('port')
    if isinstance(port, int) and not isinstance(port, bool) \
       and 1 <= port <= 65535:
        settings['port'] = port

    if data.get('auth_mode') in AUTH_MODES:
        settings['auth_mode'] = data['auth_mode']

    script = data.get('auth_script')
    if isinstance(script, str) and script.startswith('/'):
        settings['auth_script'] = script

    return settings


def _write_settings(settings: dict):
    """Persist settings atomically."""
    path = pathlib.Path(SETTINGS_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.json.tmp')
    with temporary.open('w', encoding='utf-8') as file_handle:
        json.dump(settings, file_handle, ensure_ascii=False, indent=2)
        file_handle.write('\n')
    temporary.replace(path)


def _read_store() -> dict:
    """Return the account file, tolerating a missing or damaged file."""
    try:
        with open(AUTH_STORE_PATH, encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return {'version': 1, 'users': []}

    if not isinstance(data, dict):
        return {'version': 1, 'users': []}

    users = [
        entry for entry in data.get('users') or []
        if isinstance(entry, dict) and isinstance(entry.get('user'), str)
        and isinstance(entry.get('salt'), str)
        and isinstance(entry.get('hash'), str)
    ]
    return {'version': 1, 'users': users}


def _write_store(store: dict):
    """Persist the account file atomically, readable by root only.

    The file holds password hashes, so it is not world readable.  OpenVPN
    runs as root on this box (no 'user' directive in the server config), so
    the verification script can still read it.
    """
    AUTH_DIRECTORY.mkdir(parents=True, exist_ok=True)
    AUTH_DIRECTORY.chmod(0o700)
    path = pathlib.Path(AUTH_STORE_PATH)
    temporary = path.with_suffix('.json.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        json.dump(store, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def _hash_password(password: str, salt: str) -> str:
    """Return the hex PBKDF2-SHA256 digest of *password* with *salt*."""
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                               salt.encode('utf-8'), PBKDF2_ROUNDS).hex()


def _validate_username(username: str) -> str:
    """Return a normalised user name or raise ValueError."""
    name = (username or '').strip()
    if not USERNAME_PATTERN.match(name):
        raise ValueError(
            '用户名只能由字母、数字、下划线、点和短横线组成，'
            '需以字母或数字开头，长度 1-32：{}'.format(username or '(空)'))

    if name.lower() in RESERVED_USERNAMES:
        raise ValueError('用户名 {} 是保留名称，请换一个'.format(name))

    return name


def _validate_password(password: str) -> str:
    """Return the password or raise ValueError if it is unusable."""
    if not isinstance(password, str):
        raise ValueError('密码格式不正确')

    if len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(
            '密码至少需要 {} 个字符'.format(MIN_PASSWORD_LENGTH))

    if len(password) > MAX_PASSWORD_LENGTH:
        raise ValueError(
            '密码不能超过 {} 个字符'.format(MAX_PASSWORD_LENGTH))

    return password


def _find_user(store: dict, username: str) -> dict:
    """Return the account entry for *username* or raise ValueError."""
    for entry in store['users']:
        if entry['user'] == username:
            return entry

    raise ValueError('没有找到账号 {}'.format(username))


def _public_users(store: dict) -> list[dict]:
    """Return the accounts without any password material."""
    users = [{
        'user': entry['user'],
        'disabled': bool(entry.get('disabled')),
        'created': entry.get('created') or 0,
        'updated': entry.get('updated') or 0,
    } for entry in store['users']]
    users.sort(key=lambda item: item['user'].lower())
    return users


def _migrate_users():
    """Seed the account file from the legacy shared one on first setup.

    Both VPN instances on this box used to share /etc/openvpn/auth/users.json.
    Copying the entries over with their hashes intact means existing clients
    keep working without having to change their password.
    """
    if pathlib.Path(AUTH_STORE_PATH).exists():
        return

    now = int(time.time())
    users = []
    try:
        with open(LEGACY_AUTH_STORE, encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        data = {}

    for entry in data.get('users') or []:
        if not isinstance(entry, dict):
            continue
        name = entry.get('user')
        salt = entry.get('salt')
        digest = entry.get('hash')
        if not isinstance(name, str) or not isinstance(salt, str) \
           or not isinstance(digest, str) or not name or not salt:
            continue
        users.append({
            'user': name,
            'salt': salt,
            'hash': digest,
            'disabled': bool(entry.get('disabled')),
            'created': now,
            'updated': now,
        })

    _write_store({'version': 1, 'users': users})


def _write_auth_script():
    """Install the standalone credential checker OpenVPN calls."""
    path = pathlib.Path(AUTH_SCRIPT_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(AUTH_SCRIPT, encoding='utf-8')
    path.chmod(0o755)


def _migrate_auth_script_setting():
    """Point the stored setting at our own checker instead of RouteWeb's."""
    settings = read_settings()
    if settings['auth_script'] == AUTH_SCRIPT_PATH:
        return

    settings['auth_script'] = AUTH_SCRIPT_PATH
    _write_settings(settings)


def _write_server_config():
    """Write server configuration, honouring current settings."""
    settings = read_settings()
    auth_extra = ''
    if settings['auth_mode'] == 'cert+pw':
        auth_extra = 'auth-user-pass-verify {} via-file\n'.format(
            settings['auth_script'])

    content = SERVER_CONFIGURATION.format(port=settings['port'],
                                          auth_extra=auth_extra)
    with open(SERVER_CONFIGURATION_PATH, 'w', encoding='utf-8') as file_handle:
        file_handle.write(content)


@privileged
def get_settings() -> dict:
    """Return current settings."""
    return read_settings()


@privileged
def set_settings(port: int, auth_mode: str) -> dict:
    """Validate, persist and apply new settings."""
    if not isinstance(port, int) or isinstance(port, bool) \
       or not 1 <= port <= 65535:
        raise ValueError('Port must be an integer between 1 and 65535')

    if auth_mode not in AUTH_MODES:
        raise ValueError('Unsupported authentication mode')

    settings = read_settings()
    settings['port'] = port
    settings['auth_mode'] = auth_mode
    _write_settings(settings)
    _write_server_config()
    action_utils.service_try_restart(SERVICE_NAME)
    return settings


@privileged
def get_users() -> list[dict]:
    """Return the VPN accounts, without any password material."""
    return _public_users(_read_store())


@privileged
def add_user(username: str, password: secret_str) -> dict:
    """Create a VPN account.

    Only the account file changes, so the running server does not need to be
    restarted: OpenVPN reads the file again on every connection attempt.
    """
    name = _validate_username(username)
    secret = _validate_password(password)

    store = _read_store()
    if any(entry['user'] == name for entry in store['users']):
        raise ValueError('账号 {} 已存在'.format(name))

    salt = secrets.token_hex(SALT_BYTES)
    now = int(time.time())
    store['users'].append({
        'user': name,
        'salt': salt,
        'hash': _hash_password(secret, salt),
        'disabled': False,
        'created': now,
        'updated': now,
    })
    _write_store(store)
    return {'user': name}


@privileged
def set_user_password(username: str, password: secret_str) -> dict:
    """Replace the password of an existing account."""
    name = _validate_username(username)
    secret = _validate_password(password)

    store = _read_store()
    entry = _find_user(store, name)
    salt = secrets.token_hex(SALT_BYTES)
    entry['salt'] = salt
    entry['hash'] = _hash_password(secret, salt)
    entry['updated'] = int(time.time())
    _write_store(store)
    return {'user': name}


@privileged
def set_user_disabled(username: str, disabled: bool) -> dict:
    """Enable or disable an account without touching its password."""
    name = _validate_username(username)

    store = _read_store()
    entry = _find_user(store, name)
    entry['disabled'] = bool(disabled)
    entry['updated'] = int(time.time())
    _write_store(store)
    return {'user': name, 'disabled': entry['disabled']}


@privileged
def delete_user(username: str) -> dict:
    """Remove an account.  Existing tunnels are not torn down."""
    name = _validate_username(username)

    store = _read_store()
    entry = _find_user(store, name)
    store['users'] = [item for item in store['users'] if item is not entry]
    _write_store(store)
    return {'user': name}


@privileged
def get_account_profile(username: str, remote_server: str) -> str:
    """Return a ready to use client profile for a VPN account.

    Unlike the page's own profile download this works for any account, so an
    administrator can hand a working .ovpn to someone who has no Plinth login.
    """
    name = _validate_username(username)
    if not any(entry['user'] == name for entry in _read_store()['users']):
        raise ValueError('没有找到账号 {}'.format(name))

    return _build_profile(name, remote_server)


def _setup_firewall():
    """Add TUN device to internal zone in firewalld."""

    def _configure_interface(interface, operation):
        """Add or remove an interface into internal zone."""
        command = [
            'firewall-cmd', '--zone', 'internal',
            '--{}-interface'.format(operation), interface
        ]
        subprocess.call(command)
        subprocess.call(command + ['--permanent'])

    def _is_tunplus_enabled():
        """Return whether tun+ interface is already added."""
        try:
            process = subprocess.run(
                ['firewall-cmd', '--zone', 'internal', '--list-interfaces'],
                stdout=subprocess.PIPE, check=True)
            return 'tun+' in process.stdout.decode().strip().split()
        except subprocess.CalledProcessError:
            return True  # Safer

    # XXX: Due to https://bugs.debian.org/919517 when tun+ interface is added,
    # firewalld is unable to handle it in nftables backend causing firewalld to
    # break while applying rules. This makes the entire system unreachable.
    # Hack around the problem by adding a few tun interfaces into the internal
    # zone. Hopefully, OpenVPN setting 'dev tun' will end up using one of those
    # if the tun devices are not used by other services. When the issue is
    # fixed, use tun+ instead.
    is_tunplus_set = _is_tunplus_enabled()
    _configure_interface('tun+', 'remove')
    for index in range(8):
        _configure_interface('tun{}'.format(index), 'add')

    if is_tunplus_set:
        action_utils.service_restart('firewalld')


def _run_easy_rsa(args):
    """Execute easy-rsa command with some default arguments."""
    return subprocess.run(['/usr/share/easy-rsa/easyrsa'] + args,
                          cwd=KEYS_DIRECTORY, check=True)


def _write_easy_rsa_config():
    """Write easy-rsa 'vars' file."""
    with (KEYS_DIRECTORY / 'pki' / 'vars').open('w') as file_handle:
        for key, value in _EASY_RSA_CONFIGURATION.items():
            file_handle.write(f'set_var {key} "{value}"\n')


def _is_renewable(cert_name):
    """Return whether a certificate is within configured renewable days.

    'easy-rsa renewable' command could be used to perform the check. However,
    the script fetches the expiry date of the certificate from the index.txt
    file. When this file has multiple entries for the same certificate base
    name, the results of the command are undesirable. Multiple entries for the
    same certificate base name can occur in the index.txt file in some unusual
    cases. For example, earlier versions of FreedomBox ran build-server-full
    followed by gen-req/sign-req. This approach created such entries. So,
    determine expiry here without using easy-rsa script.
    """
    cert_path = KEYS_DIRECTORY / 'pki' / 'issued' / (cert_name + '.crt')
    if not cert_path.exists():
        return False

    process = subprocess.run(
        ['openssl', 'x509', '-noout', '-enddate', '-in',
         str(cert_path)], check=True, stdout=subprocess.PIPE)
    date_string = process.stdout.decode().strip().partition('=')[2]
    cert_expiry_time = datetime.datetime.strptime(date_string,
                                                  '%b %d %H:%M:%S %Y GMT')
    cert_expiry_time = cert_expiry_time.replace(tzinfo=datetime.timezone.utc)

    now = datetime.datetime.now(tz=datetime.timezone.utc)
    renew_period = datetime.timedelta(
        days=int(_EASY_RSA_CONFIGURATION['EASYRSA_CERT_RENEW']))
    return (cert_expiry_time - now) < renew_period


def _renew(cert_name):
    """Renew a certificate and revoke the old certificate.

    Without revoking the old certificate, another renewal is not possible due
    to safety checks in easy-rsa script.
    """
    _run_easy_rsa(['renew', cert_name, 'nopass'])

    # Remove the old certificate so that more renewals can work
    _run_easy_rsa(['revoke-renewed', cert_name])


def _create_certificates():
    """Generate CA and server certificates."""
    KEYS_DIRECTORY.mkdir(mode=0o700, exist_ok=True)

    # Don't re-initialize PKI if it already exists. This will lead to wiping of
    # all existing certificates and downloaded profiles.
    if not (KEYS_DIRECTORY / 'pki').is_dir():
        _run_easy_rsa(['init-pki'])

    _write_easy_rsa_config()

    # Don't reinitialize the CA certificates. This will invalidate all existing
    # server/client certificates and downloaded client profiles.
    if not CA_CERTIFICATE_PATH.exists():
        _run_easy_rsa(['build-ca', 'nopass'])

    # Renew server certificate if already exists. Already downloaded profiles
    # don't change.
    server_cert = KEYS_DIRECTORY / 'pki' / 'issued' / 'server.crt'
    if not server_cert.exists():
        _run_easy_rsa(['build-server-full', 'server', 'nopass'])
    elif _is_renewable('server'):
        _renew('server')


@privileged
def get_profile(username: str, remote_server: str) -> str:
    """Return the profile for a user."""
    return _build_profile(username, remote_server)


def _build_profile(username: str, remote_server: str) -> str:
    """Build the client profile for *username*.

    Kept separate from the privileged wrapper so that other actions in this
    module can reuse it without spawning a nested privileged call.
    """
    if username == 'ca' or username == 'server':
        raise ValueError('Invalid username')

    user_certificate = str(USER_CERTIFICATE_PATH).format(username=username)
    user_key = str(USER_KEY_PATH).format(username=username)

    if not _is_non_empty_file(user_certificate) or \
       not _is_non_empty_file(user_key):
        set_unique_subject('no')  # Set unique subject in attribute file to no
        _run_easy_rsa(['build-client-full', username, 'nopass'])
    elif _is_renewable(username):
        _renew(username)

    user_certificate_string = _read_file(user_certificate)
    user_key_string = _read_file(user_key)
    ca_string = _read_file(CA_CERTIFICATE_PATH)

    settings = read_settings()
    auth_client = 'auth-user-pass\n' \
        if settings['auth_mode'] == 'cert+pw' else ''

    return CLIENT_CONFIGURATION.format(ca=ca_string,
                                       cert=user_certificate_string,
                                       key=user_key_string,
                                       remote=remote_server,
                                       port=settings['port'],
                                       auth_client=auth_client)


def set_unique_subject(value):
    """Set the unique_subject value to a particular value."""
    aug = load_augeas()
    aug.set('/files' + str(ATTR_FILE) + '/unique_subject', value)
    aug.save()


def _read_file(filename):
    """Return the entire contents of a file as string."""
    with open(filename, 'r', encoding='utf-8') as file_handle:
        return ''.join(file_handle.readlines())


def _is_non_empty_file(filepath):
    """Return whether a file exists and is not zero size."""
    return os.path.isfile(filepath) and os.path.getsize(filepath) > 0


def load_augeas():
    """Initialize Augeas."""
    aug = augeas.Augeas(flags=augeas.Augeas.NO_LOAD +
                        augeas.Augeas.NO_MODL_AUTOLOAD)

    # shell-script config file lens
    aug.set('/augeas/load/Simplevars/lens', 'Simplevars.lns')
    aug.set('/augeas/load/Simplevars/incl[last() + 1]', str(ATTR_FILE))
    aug.load()
    return aug


@privileged
def uninstall():
    """Remove configuration directory for OpenVPN."""
    shutil.rmtree('/etc/openvpn', ignore_errors=True)
