# SPDX-License-Identifier: AGPL-3.0-or-later
"""FreedomBox app for configuring OpenVPN server."""

import datetime
import logging
import socket

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse
from django.shortcuts import redirect
from django.urls import NoReverseMatch, reverse
from django.utils.translation import gettext as _
from django.views.generic import View

from plinth.modules.names.components import DomainName
from plinth.views import AppView

from . import privileged
from .forms import OpenVPNSettingsForm, VPNUserAddForm, VPNUserPasswordForm

logger = logging.getLogger(__name__)


def _primary_address() -> str:
    """Return the local address the box uses for outbound traffic.

    Connecting a UDP socket does not send anything, it only asks the kernel
    which source address would be used, so this is safe to call on a live box.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(('8.8.8.8', 53))
        return sock.getsockname()[0]
    except OSError:
        return ''
    finally:
        sock.close()


def _guess_remote() -> str:
    """Return a server address to put into a client profile.

    A box with no domain name configured has an empty DomainName list, which
    used to raise IndexError and turn the download into an error page.  Fall
    back to the outbound address so that a profile is always produced; the
    administrator can edit the 'remote' line if the box sits behind NAT.
    """
    try:
        names = DomainName.list_names()
    except Exception:
        logger.exception('Unable to list domain names')
        names = []

    if names:
        return names[0]

    return _primary_address() or socket.gethostname() or 'CHANGE-ME'


def _module_url(name: str, fallback: str, **kwargs) -> str:
    """Resolve a URL of this module, tolerating a missing namespace."""
    try:
        return reverse('openvpn:{}'.format(name), kwargs=kwargs or None)
    except NoReverseMatch:
        return fallback


def _index_url() -> str:
    """Return the URL of the app page."""
    return _module_url('index', '/plinth/apps/openvpn/')


def _first_error(form) -> str:
    """Return the first error of a form as a plain sentence."""
    for errors in form.errors.values():
        for error in errors:
            return str(error)

    return '输入不正确。'


def _format_timestamp(value) -> str:
    """Render a stored unix timestamp for the table."""
    try:
        moment = datetime.datetime.fromtimestamp(int(value))
    except (TypeError, ValueError, OSError, OverflowError):
        return '—'

    if moment.year < 2000:
        return '—'

    return moment.strftime('%Y-%m-%d %H:%M')


class OpenVPNAppView(AppView):
    """Show OpenVPN app main page."""

    app_id = 'openvpn'
    template_name = 'openvpn.html'
    form_class = OpenVPNSettingsForm

    def get_initial(self):
        """Populate the form with the settings currently in effect."""
        initial = super().get_initial()
        try:
            settings = privileged.get_settings()
            initial['port'] = settings['port']
            initial['auth_mode'] = settings['auth_mode']
        except Exception:
            # Never let a settings read failure break the page.
            logger.exception('Unable to read OpenVPN settings')
            initial.setdefault('port', 1194)
            initial.setdefault('auth_mode', 'cert')

        return initial

    def get_context_data(self, **kwargs):
        """Expose the VPN accounts and their links to the template."""
        context = super().get_context_data(**kwargs)

        try:
            settings = privileged.get_settings()
            context['password_enabled'] = settings['auth_mode'] == 'cert+pw'
        except Exception:
            logger.exception('Unable to read OpenVPN settings')
            context['password_enabled'] = False

        try:
            users = privileged.get_users()
        except Exception:
            logger.exception('Unable to list VPN accounts')
            users = []

        for user in users:
            user['updated_text'] = _format_timestamp(user.get('updated'))
            user['profile_url'] = _module_url(
                'user-profile',
                '/plinth/apps/openvpn/users/{}/profile/'.format(user['user']),
                username=user['user'])

        context['vpn_users'] = users
        context['user_action_url'] = _module_url(
            'user-action', '/plinth/apps/openvpn/users/action/')
        return context

    def form_valid(self, form):
        """Persist settings and restart the service."""
        try:
            privileged.set_settings(form.cleaned_data['port'],
                                    form.cleaned_data['auth_mode'])
        except Exception as exception:
            logger.exception('Unable to apply OpenVPN settings')
            messages.error(
                self.request,
                _('Could not apply the new configuration: {error}').format(
                    error=exception))
            return self.form_invalid(form)

        messages.success(self.request, _('Configuration updated.'))
        return super().form_valid(form)


class VPNUserActionView(LoginRequiredMixin, View):
    """Create, modify, disable or delete a VPN account.

    Kept as a separate endpoint so that the buttons in the account table do
    not resubmit the server settings form, which would also apply whatever
    else happened to be edited but not saved.
    """

    def post(self, request):
        """Handle one account action and return to the app page."""
        action = request.POST.get('action', '')
        username = (request.POST.get('username') or '').strip()

        try:
            if action == 'add':
                form = VPNUserAddForm(request.POST)
                if not form.is_valid():
                    raise ValueError(_first_error(form))

                result = privileged.add_user(
                    form.cleaned_data['username'],
                    form.cleaned_data['password'])
                messages.success(
                    request, '已添加账号 {}。'.format(result['user']))

            elif action == 'password':
                form = VPNUserPasswordForm(request.POST)
                if not form.is_valid():
                    raise ValueError(_first_error(form))

                privileged.set_user_password(username,
                                             form.cleaned_data['password'])
                messages.success(
                    request, '已更新账号 {} 的密码。'.format(username))

            elif action == 'toggle':
                disable = request.POST.get('disabled') == '1'
                result = privileged.set_user_disabled(username, disable)
                if result['disabled']:
                    messages.success(
                        request,
                        '已禁用账号 {}，该账号将无法再连接。'.format(username))
                else:
                    messages.success(
                        request, '已启用账号 {}。'.format(username))

            elif action == 'delete':
                privileged.delete_user(username)
                messages.success(request, '已删除账号 {}。'.format(username))

            else:
                messages.error(request, '无法识别的操作。')

        except Exception as exception:
            logger.exception('Unable to change the VPN accounts')
            messages.error(request, '操作失败：{}'.format(exception))

        return redirect(_index_url())

    def get(self, request):
        """Only POST is meaningful, so send the browser back to the page."""
        return redirect(_index_url())


class VPNUserProfileView(LoginRequiredMixin, View):
    """Download a ready to use client profile for one VPN account."""

    def get(self, request, username):
        """Build and return the .ovpn file."""
        remote = _guess_remote()

        try:
            profile_text = privileged.get_account_profile(username, remote)
        except Exception as exception:
            logger.exception('Unable to build the profile for %s', username)
            messages.error(request, '生成配置失败：{}'.format(exception))
            return redirect(_index_url())

        response = HttpResponse(profile_text,
                                content_type='application/x-openvpn-profile')
        response['Content-Disposition'] = \
            'attachment; filename={}.ovpn'.format(username)
        return response


def profile(request):
    """Provide the user's profile for download."""
    username = request.user.username
    profile_string = privileged.get_profile(username, _guess_remote())

    response = HttpResponse(profile_string,
                            content_type='application/x-openvpn-profile')
    response['Content-Disposition'] = \
        'attachment; filename={username}.ovpn'.format(username=username)

    return response
