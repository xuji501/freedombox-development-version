"""First-time setup of the OpenVPN account manager on a fresh machine.

Used by install.sh when ``/etc/openvpn/server/freedombox.conf`` does not
exist yet, i.e. the stock FreedomBox OpenVPN app was never configured on this
box.  In that case the module has to do everything the app's own setup() does
-- generate the CA and the server certificate, write the server configuration
and open the firewall -- otherwise ``openvpn-server@freedombox`` has nothing
to start with.

On a machine where OpenVPN is already configured, install.sh calls
``init_once.py`` instead, which deliberately touches neither the PKI nor the
firewall.
"""

from plinth import web_framework

web_framework.init()

from plinth import app as app_module  # noqa: E402
from plinth import module_loader  # noqa: E402
from plinth.modules.openvpn import privileged  # noqa: E402

module_loader.load_modules()
app_module.apps_init()

app = app_module.App.get('openvpn')
print('当前 setup 版本:', app.get_setup_version(), '/ 目标:', app.info.version)
print('现有设置:', privileged.read_settings())

# 生成 CA/服务端证书、写服务端配置、放行防火墙、重启服务。
# _create_certificates() 对已存在的 PKI 是幂等的，不会覆盖已有证书。
privileged.setup()

# 记录版本，避免 Plinth 下次启动时又跑一遍 setup 覆盖我们写好的配置。
app.set_setup_version(app.info.version)
app.enable()

print('setup 完成，版本:', app.get_setup_version())
print('应用已启用:', app.is_enabled())

users = privileged._public_users(privileged._read_store())
print('账号数:', len(users))
