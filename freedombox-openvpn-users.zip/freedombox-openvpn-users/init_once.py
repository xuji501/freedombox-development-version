"""One-off initialisation for the OpenVPN account manager.

Called by install.sh.  Only does what this patch needs: migrate the accounts
from the shared legacy file, install the standalone credential checker, point
the server configuration at it and restart OpenVPN.

Deliberately does not call the app's own setup(): that would regenerate
certificates and rewrite the firewall zones, which are already in place and
carry real risk on a live box.
"""

from plinth import web_framework

web_framework.init()

from plinth import action_utils  # noqa: E402
from plinth.modules.openvpn import privileged  # noqa: E402

privileged._migrate_users()
privileged._write_auth_script()
privileged._migrate_auth_script_setting()
privileged._write_server_config()

settings = privileged.read_settings()
print('auth_mode  :', settings['auth_mode'])
print('port       :', settings['port'])
print('auth_script:', settings['auth_script'])

users = privileged._public_users(privileged._read_store())
print('accounts   :', [(user['user'], user['disabled']) for user in users])

action_utils.service_try_restart(privileged.SERVICE_NAME)
print('service restarted')
