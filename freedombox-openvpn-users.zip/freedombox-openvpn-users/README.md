# FreedomBox OpenVPN 账号管理

在 FreedomBox（Plinth）的 OpenVPN 页面增加用户名/密码账号管理，支持**添加、
修改密码、禁用/启用、删除**，以及为任意账号**下载客户端配置**。

## 为什么需要它

FreedomBox 原生的 OpenVPN 只做证书认证：证书签给 Plinth 用户，没有"账号"这个概念。
之前的补丁虽然打开了 `auth-user-pass-verify`，但账号只能手工改 JSON 文件，
既没有界面，也不安全（密码哈希文件对所有用户可读）。

本模块把账号管理搬进页面，并给 FreedomBox 一套**独立的账号库**。

## 为什么用独立账号库

这台机器上有两套 OpenVPN：

| 实例 | 端口 | 配置 | 账号库 |
|---|---|---|---|
| RouteWeb | 1194 | `/etc/openvpn/server.conf` | `/etc/openvpn/auth/users.json` |
| FreedomBox | 1198 | `/etc/openvpn/server/freedombox.conf` | `/etc/openvpn/freedombox-auth/users.json` |

两者原先**共用**同一个 `users.json`。问题在于那个文件归 RouteWeb 所有，
它每次保存都会整个重写，Plinth 里新加的账号会悄无声息地消失。

所以本模块让 FreedomBox 使用自己的账号库和校验脚本：

- 完全不写 `/etc/openvpn/auth/users.json`，RouteWeb 的行为不受影响
- 首次安装时把旧库里的账号**连同密码哈希一起复制**过来，用户不用改密码
- 账号库权限 `0600 root:root`（旧的是 0644，哈希对所有用户可读）
- 校验脚本 `/usr/lib/freedombox-openvpn/ovpn-auth.py` 独立于 Plinth，
  Plinth 重启或升级期间也能正常工作

代价是 1194 和 1198 需要分别建账号。如果需要统一账号，把
`AUTH_STORE_PATH` 指回旧文件即可，但要接受被覆盖的风险。

## 页面功能

访问 `https://<本机地址>/plinth/apps/openvpn/`，在「VPN 账号」区域：

| 操作 | 说明 |
|---|---|
| 添加账号 | 用户名 + 密码 + 确认密码，密码至少 8 位 |
| 改密码 | 每行「改密码」展开内联表单，两次输入需一致 |
| 禁用 / 启用 | 禁用后即使密码正确也拒绝连接，密码保持不变 |
| 删除 | 移除账号，已建立的连接不会被立即断开 |
| 下载配置 | 为该账号签发客户端证书并下载 `.ovpn`，内含 `auth-user-pass` |

账号相关的操作**不重启服务** —— OpenVPN 每次连接都会重新读账号库。

当认证方式还是「仅证书」时，页面顶部会显示黄色警告，提示账号不会生效。

## 密码与安全

- PBKDF2-SHA256，200000 轮，16 字节随机盐，与原有账号库算法一致
- 比对使用 `hmac.compare_digest`，避免时序侧信道
- 密码参数标注为 `secret_str`，Plinth 不会把它写进日志
- 每次认证尝试追加到 `/var/log/freedombox-ovpn-auth.log`，
  超过 512 KB 自动轮转为 `.log.1`
- 账号库无法解析时**默认拒绝**，不会因为文件损坏而放行

排查连不上时先看这个日志，里面会写明 `bad-password`、`disabled`、
`no-such-user` 还是 `store-unreadable`。

## 已知边界

- 认证方式仍是「证书 + 用户名密码」，客户端必须持有有效证书。
  证书由「下载配置」签发，与账号名同名
- 未启用 `username-as-common-name`，因此证书 CN 与账号名不强制一致。
  如果要求严格绑定，加上该指令即可，但已有客户端需要重新下载配置
- 本机没有配置域名时，生成的 `.ovpn` 里服务器地址填的是出口 IP，
  在 NAT 后面的场景需要手工改成公网地址
- 删除账号不会吊销它的客户端证书，证书仍能通过证书校验，
  只是拿不到密码。要彻底失效请同时禁用账号

## 文件位置

```
/usr/lib/python3/dist-packages/plinth/modules/openvpn/   模块代码
/usr/lib/freedombox-openvpn/ovpn-auth.py                凭据校验脚本
/etc/openvpn/freedombox-auth/users.json                 账号库（0600）
/etc/openvpn/server/freedombox.conf                     服务端配置
/etc/openvpn/server/freedombox-settings.json            端口与认证方式
/var/log/freedombox-ovpn-auth.log                       认证审计日志
```

## 安装与回滚

```bash
sudo bash install.sh                    # 安装或重装（幂等）
sudo bash rollback.sh                   # 用最近一次备份回滚
sudo bash rollback.sh <备份目录>         # 指定备份回滚
```

安装会备份模块目录、服务端配置和现有账号库到
`/root/freedombox-openvpn-users-backup/<时间戳>/`，任何一步失败自动回滚。
重装时若账号库已存在，会先备份再原样保留，不会丢掉已创建的账号。

安装过程会重启 `openvpn-server@freedombox`，已连接的客户端需要重连。

### 两种部署场景

脚本会自己判断，不需要额外参数：

| 场景 | 判定条件 | 行为 |
|---|---|---|
| `upgrade` | 已有 `/etc/openvpn/server/freedombox.conf` | 只做增量改造：账号库、校验脚本、服务端配置。**不碰证书和防火墙** |
| `fresh` | 没有该文件（官方 OpenVPN 从未启用过） | 走 `bootstrap.py`，完整初始化：生成 CA 与服务端证书、写服务端配置、放行防火墙，等价于官方「安装 OpenVPN 应用」 |

`fresh` 场景需要 `easy-rsa`（`/usr/share/easy-rsa/easyrsa`），缺了会在第 1 步直接报错。

### 可选环境变量

| 变量 | 默认 | 说明 |
|---|---|---|
| `FBX_OVPN_PORT` | 沿用现有端口，否则 1194 | 仅在 `freedombox-settings.json` 不存在时生效 |
| `FBX_OVPN_AUTH_MODE` | `cert` | `cert` 或 `cert+pw`，同样仅在设置文件不存在时生效 |

```bash
sudo FBX_OVPN_PORT=1198 FBX_OVPN_AUTH_MODE=cert+pw bash install.sh
```

设置文件已存在时这两个变量会被忽略 —— 端口与认证方式的后续变更走页面。

## 升级注意

`privileged.py`、`views.py`、`urls.py`、`__init__.py`、`templates/openvpn.html`
都在 freedombox deb 包的文件清单里，`apt upgrade freedombox` 会**把它们还原成官方版本**
（只有 `forms.py` 是新增文件，不受影响）。升级后重跑一次 `install.sh` 即可恢复，
账号库与设置文件不会被改动。

`__init__.py` 里的 `_version = 6` 是模块版本号，决定 Plinth 是否会重跑 setup。
全新机器上必须一并部署，否则账号功能不会被初始化 —— `install.sh` 已经处理了这一点。
