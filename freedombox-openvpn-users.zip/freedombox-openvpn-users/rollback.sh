#!/bin/bash
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# 回滚 OpenVPN 账号管理模块。
#
# 用法：
#   sudo bash rollback.sh                       # 使用最近一次备份
#   sudo bash rollback.sh /root/freedombox-openvpn-users-backup/20261027-150000

set -uo pipefail

MODULE_DIR=/usr/lib/python3/dist-packages/plinth/modules/openvpn
AUTH_SCRIPT_DIR=/usr/lib/freedombox-openvpn
AUTH_STORE_DIR=/etc/openvpn/freedombox-auth
OPENVPN_CONFIG=/etc/openvpn/server/freedombox.conf
OPENVPN_SETTINGS=/etc/openvpn/server/freedombox-settings.json
BACKUP_ROOT=/root/freedombox-openvpn-users-backup

if [ $# -ge 1 ]; then
    BACKUP_DIR=$1
else
    BACKUP_DIR=$(ls -1d "$BACKUP_ROOT"/*/ 2>/dev/null | sort | tail -1)
fi

echo "=============================================="
echo " OpenVPN 账号管理模块回滚"
echo "=============================================="

[ "$(id -u)" -eq 0 ] || { echo "[错误] 必须以 root 权限运行" >&2; exit 1; }
[ -n "${BACKUP_DIR:-}" ] && [ -d "$BACKUP_DIR" ] \
    || { echo "[错误] 找不到备份目录：${BACKUP_DIR:-<空>}" >&2; exit 1; }

echo "使用备份：$BACKUP_DIR"

echo ""
echo "== 1/5 恢复模块代码 =="
if [ -d "$BACKUP_DIR/module" ]; then
    rm -rf "$MODULE_DIR"
    cp -a "$BACKUP_DIR/module" "$MODULE_DIR"
    rm -rf "$MODULE_DIR/__pycache__"
    echo "已恢复原有模块目录"
else
    echo "[警告] 备份中没有模块目录，保持当前代码不变" >&2
fi

echo ""
echo "== 2/5 恢复 OpenVPN 服务端配置 =="
if [ -f "$BACKUP_DIR/freedombox.conf" ]; then
    cp -a "$BACKUP_DIR/freedombox.conf" "$OPENVPN_CONFIG"
    echo "已恢复 $OPENVPN_CONFIG"
fi
if [ -f "$BACKUP_DIR/freedombox-settings.json" ]; then
    cp -a "$BACKUP_DIR/freedombox-settings.json" "$OPENVPN_SETTINGS"
    echo "已恢复 $OPENVPN_SETTINGS"
else
    rm -f "$OPENVPN_SETTINGS"
    echo "已移除 $OPENVPN_SETTINGS（安装前不存在）"
fi

echo ""
echo "== 3/5 移除独立账号库与校验脚本 =="
rm -rf "$AUTH_STORE_DIR"
rm -rf "$AUTH_SCRIPT_DIR"
echo "已移除 $AUTH_STORE_DIR 与 $AUTH_SCRIPT_DIR"
echo "（RouteWeb 的 /etc/openvpn/auth/users.json 全程未被修改）"

echo ""
echo "== 4/5 重启服务 =="
systemctl restart plinth 2>/dev/null || true
systemctl try-restart openvpn-server@freedombox 2>/dev/null || true
sleep 3
echo "plinth：$(systemctl is-active plinth 2>/dev/null || echo unknown)"
echo "openvpn：$(systemctl is-active openvpn-server@freedombox 2>/dev/null || echo unknown)"

echo ""
echo "== 5/5 结果 =="
grep -q 'auth-user-pass-verify' "$OPENVPN_CONFIG" \
    && echo "当前认证配置：$(grep 'auth-user-pass-verify' "$OPENVPN_CONFIG")" \
    || echo "当前认证配置：仅证书（未启用用户名密码）"

echo ""
echo "回滚完成。"
echo "=============================================="
