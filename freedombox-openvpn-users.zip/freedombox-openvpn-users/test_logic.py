"""Local logic tests for the OpenVPN account manager.

Plinth, augeas and the OpenVPN binaries are not available on the development
machine, so they are stubbed out.  The credential checker itself is written to
a temporary file and executed for real, because that script is what decides
whether a client is let in.
"""

import json
import os
import pathlib
import subprocess
import sys
import tempfile
import types

# --- Stub out plinth and augeas so privileged.py can be imported -----------
plinth = types.ModuleType('plinth')
action_utils = types.ModuleType('plinth.action_utils')
for name in ('service_enable', 'service_disable', 'service_start',
             'service_stop', 'service_try_restart', 'service_restart',
             'service_daemon_reload'):
    setattr(action_utils, name, lambda *a, **k: None)
actions = types.ModuleType('plinth.actions')
actions.privileged = lambda func: func


class secret_str(str):
    """Marker type Plinth uses for values that must not be logged."""


actions.secret_str = secret_str
plinth.action_utils = action_utils
plinth.actions = actions
sys.modules['plinth'] = plinth
sys.modules['plinth.action_utils'] = action_utils
sys.modules['plinth.actions'] = actions

augeas = types.ModuleType('augeas')


class _FakeAugeas:
    """Minimal stand-in for the augeas handle."""

    NO_LOAD = 1
    NO_MODL_AUTOLOAD = 2

    def __init__(self, flags=0):
        self.values = {}

    def set(self, path, value):
        """Record a value."""
        self.values[path] = value

    def save(self):
        """Pretend to persist."""

    def load(self):
        """Pretend to load."""


augeas.Augeas = _FakeAugeas
sys.modules['augeas'] = augeas

sys.path.insert(0, str(pathlib.Path(__file__).parent / 'files'))
import privileged  # noqa: E402

WORK = pathlib.Path(tempfile.mkdtemp(prefix='fbx-ovpn-'))
STORE = WORK / 'users.json'
LEGACY = WORK / 'legacy-users.json'

privileged.AUTH_DIRECTORY = WORK
privileged.AUTH_STORE_PATH = STORE
privileged.LEGACY_AUTH_STORE = str(LEGACY)
privileged.SETTINGS_PATH = str(WORK / 'settings.json')

print('=' * 60)
print('测试 1：账号库读写')
print('=' * 60)
assert privileged._read_store() == {'version': 1, 'users': []}, \
    '缺失的账号库应返回空列表而不是抛错'
privileged._write_store({'version': 1, 'users': []})
assert STORE.exists()
if os.name == 'posix':
    assert oct(STORE.stat().st_mode)[-3:] == '600', \
        '账号库含密码哈希，必须是 0600'
    print('[通过] 缺失时返回空库，写入后权限为 0600')
else:
    print('[通过] 缺失时返回空库（Windows 上不校验文件权限）')

print()
print('=' * 60)
print('测试 2：用户名与密码校验')
print('=' * 60)
good_names = ['xj', 'alice', 'vpn-01', 'user.name', 'A1_b2']
for name in good_names:
    assert privileged._validate_username(name) == name
    print(f'  [接受] {name}')

bad_names = [
    ('', '空'),
    ('-abc', '以符号开头'),
    ('a b', '含空格'),
    ('a' * 33, '超长'),
    ('ca', '保留名'),
    ('server', '保留名'),
    ('用户', '非 ASCII'),
]
for name, label in bad_names:
    try:
        privileged._validate_username(name)
    except ValueError as error:
        print(f'  [拒绝] {label}: {error}')
    else:
        raise AssertionError(f'{label} 本应被拒绝')

assert privileged._validate_password('12345678') == '12345678'
for bad in ('1234567', '', 'x' * 129):
    try:
        privileged._validate_password(bad)
    except ValueError as error:
        print(f'  [拒绝] 密码长度 {len(bad)}: {error}')
    else:
        raise AssertionError('长度不合规的密码本应被拒绝')
print('[通过] 用户名与密码规则符合预期')

print()
print('=' * 60)
print('测试 3：密码哈希与 RouteWeb 兼容')
print('=' * 60)
import hashlib  # noqa: E402

salt = 'a' * 32
expected = hashlib.pbkdf2_hmac('sha256', b'secret123',
                               salt.encode('utf-8'), 200000).hex()
assert privileged._hash_password('secret123', salt) == expected
# 同一密码两次加盐结果必须不同
a = privileged._hash_password('secret123', 'salt-a')
b = privileged._hash_password('secret123', 'salt-b')
assert a != b
print('  pbkdf2 结果与标准库一致，不同盐产生不同哈希')
print('[通过] 20 万轮 PBKDF2-SHA256，与现有账号库算法相同')

print()
print('=' * 60)
print('测试 4：新增、改密、禁用、删除')
print('=' * 60)
privileged.add_user('alice', 'alicepass1')
privileged.add_user('bob', 'bobpass123')
users = privileged.get_users()
print('  账号:', [u['user'] for u in users])
assert [u['user'] for u in users] == ['alice', 'bob']
assert all(not u['disabled'] for u in users)

# 返回值里不能带任何密码材料
assert all('hash' not in u and 'salt' not in u for u in users), \
    '对外返回的账号信息不能包含哈希或盐'

try:
    privileged.add_user('alice', 'anotherpass')
except ValueError as error:
    print(f'  [拒绝] 重名: {error}')
else:
    raise AssertionError('重复用户名本应被拒绝')

privileged.set_user_password('alice', 'newalicepass')
store = json.loads(STORE.read_text(encoding='utf-8'))
alice = [u for u in store['users'] if u['user'] == 'alice'][0]
assert alice['hash'] == privileged._hash_password('newalicepass',
                                                  alice['salt'])
print('  改密后哈希与盐同步更新')

privileged.set_user_disabled('bob', True)
bob = [u for u in privileged.get_users() if u['user'] == 'bob'][0]
assert bob['disabled'] is True
privileged.set_user_disabled('bob', False)
bob = [u for u in privileged.get_users() if u['user'] == 'bob'][0]
assert bob['disabled'] is False
print('  禁用与启用可来回切换')

privileged.delete_user('bob')
assert [u['user'] for u in privileged.get_users()] == ['alice']
try:
    privileged.delete_user('bob')
except ValueError as error:
    print(f'  [拒绝] 删除不存在的账号: {error}')
else:
    raise AssertionError('删除不存在的账号本应报错')
print('[通过] 增删改禁用全部生效，重复操作有明确提示')

print()
print('=' * 60)
print('测试 5：首次安装时迁移旧账号库')
print('=' * 60)
STORE.unlink()
legacy_hash = hashlib.pbkdf2_hmac('sha256', b'legacypw',
                                  b'legacysalt', 200000).hex()
LEGACY.write_text(json.dumps({
    'mode': 'cert+pw',
    'users': [
        {'user': 'xj', 'salt': 'legacysalt', 'hash': legacy_hash,
         'disabled': False},
        {'user': 'old', 'salt': 'legacysalt', 'hash': legacy_hash,
         'disabled': True},
        {'user': 'broken'},
    ],
}), encoding='utf-8')

privileged._migrate_users()
migrated = privileged.get_users()
print('  迁移结果:', migrated)
assert [u['user'] for u in migrated] == ['old', 'xj'], \
    '不完整的条目应被丢弃，其余账号应保留'
assert [u for u in migrated if u['user'] == 'old'][0]['disabled'] is True, \
    '禁用状态必须一并保留'

# 迁移过来的账号，原密码必须还能用
store = json.loads(STORE.read_text(encoding='utf-8'))
entry = [u for u in store['users'] if u['user'] == 'xj'][0]
assert entry['hash'] == legacy_hash and entry['salt'] == 'legacysalt'
print('[通过] 旧账号连同密码哈希与禁用状态一起迁移，用户无需改密码')

print()
print('=' * 60)
print('测试 6：再次运行 setup 不会覆盖已有账号库')
print('=' * 60)
privileged.add_user('carol', 'carolpass1')
before = privileged.get_users()
privileged._migrate_users()
after = privileged.get_users()
assert before == after, '账号库已存在时不应重新迁移'
print('[通过] 迁移只在账号库不存在时执行，可重复安装')

print()
print('=' * 60)
print('测试 7：校验脚本语法与权限')
print('=' * 60)
compile(privileged.AUTH_SCRIPT, 'ovpn-auth.py', 'exec')
assert 'pbkdf2_hmac' in privileged.AUTH_SCRIPT
assert 'compare_digest' in privileged.AUTH_SCRIPT
assert '/etc/openvpn/freedombox-auth/users.json' in privileged.AUTH_SCRIPT
assert 'routeweb' not in privileged.AUTH_SCRIPT.lower(), \
    '校验脚本不能依赖 RouteWeb 的文件'
print('[通过] 脚本语法有效，且只读 FreedomBox 自己的账号库')

print()
print('=' * 60)
print('测试 8：真正运行校验脚本')
print('=' * 60)
script_path = WORK / 'ovpn-auth.py'
script_text = privileged.AUTH_SCRIPT.replace(
    "'/etc/openvpn/freedombox-auth/users.json'", repr(str(STORE)))
script_text = script_text.replace(
    "'/var/log/freedombox-ovpn-auth.log'", repr(str(WORK / 'auth.log')))
script_path.write_text(script_text, encoding='utf-8')

privileged.add_user('dave', 'davepass123')
privileged.add_user('erin', 'erinpass123')
privileged.set_user_disabled('erin', True)


def run_auth(user, password):
    """Run the checker exactly the way OpenVPN does and return its status."""
    credentials = WORK / 'credentials.txt'
    credentials.write_text('{}\n{}\n'.format(user, password),
                           encoding='utf-8')
    process = subprocess.run(
        [sys.executable, str(script_path), str(credentials)],
        capture_output=True, text=True, timeout=60)
    return process.returncode


cases = [
    ('dave', 'davepass123', 0, '正确密码应通过'),
    ('dave', 'wrongpass', 1, '错误密码应拒绝'),
    ('dave', 'DAVEPASS123', 1, '密码区分大小写'),
    ('erin', 'erinpass123', 1, '已禁用账号应拒绝'),
    ('nobody', 'whatever', 1, '不存在的账号应拒绝'),
    ('', 'whatever', 1, '空用户名应拒绝'),
]
for user, password, expected, label in cases:
    actual = run_auth(user, password)
    print(f'  {label}: exit={actual}（期望 {expected}）')
    assert actual == expected, f'{label}: 得到 {actual}'

log_text = (WORK / 'auth.log').read_text(encoding='utf-8')
assert 'OK   dave' in log_text
assert 'FAIL dave bad-password' in log_text
assert 'FAIL erin disabled' in log_text
assert 'FAIL nobody no-such-user' in log_text
print('[通过] 六种情形全部符合预期，且每次尝试都留下审计日志')

print()
print('=' * 60)
print('测试 9：账号库损坏时拒绝所有人')
print('=' * 60)
STORE.write_text('{ this is not json', encoding='utf-8')
assert run_auth('dave', 'davepass123') == 1, '账号库损坏时必须拒绝而不是放行'
print('[通过] 账号库无法解析时默认拒绝，不会误放行')

print()
print('全部测试通过')
